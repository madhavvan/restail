"""Where Folio keeps its own files (never next to the user's PDFs)."""

import json
import os
import sys
import threading

_lock = threading.Lock()


def data_dir() -> str:
    base = os.environ.get("FOLIO_DATA_DIR")
    if not base:
        local = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
        base = os.path.join(local, "Folio")
    os.makedirs(base, exist_ok=True)
    return base


def sub(name: str) -> str:
    path = os.path.join(data_dir(), name)
    os.makedirs(path, exist_ok=True)
    return path


def cache_dir() -> str:
    return sub("cache")


def signatures_dir() -> str:
    return sub("signatures")


def backups_dir() -> str:
    return sub("backups")


def logs_dir() -> str:
    return sub("logs")


def resource_path(*parts: str) -> str:
    """Path to a bundled resource, both from source and from a PyInstaller build."""
    root = getattr(sys, "_MEIPASS", None) or os.path.dirname(os.path.abspath(__file__))
    if getattr(sys, "_MEIPASS", None):
        return os.path.join(root, "folio", *parts)
    return os.path.join(root, *parts)


_SETTINGS_DEFAULTS = {
    "recent": [],          # [{path, name, opened}]
    "theme": "system",     # system | light | dark
    "zoom": "fit-width",
    "show_thumbs": True,
}


def _settings_path() -> str:
    return os.path.join(data_dir(), "settings.json")


def load_settings() -> dict:
    with _lock:
        try:
            with open(_settings_path(), "r", encoding="utf-8") as f:
                data = json.load(f)
        except (OSError, ValueError):
            data = {}
    out = dict(_SETTINGS_DEFAULTS)
    out.update({k: v for k, v in data.items() if k in _SETTINGS_DEFAULTS})
    return out


def save_settings(settings: dict) -> None:
    with _lock:
        tmp = _settings_path() + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(settings, f, indent=1)
        os.replace(tmp, _settings_path())


def add_recent(path: str) -> None:
    s = load_settings()
    path = os.path.abspath(path)
    items = [r for r in s.get("recent", []) if os.path.normcase(r.get("path", "")) != os.path.normcase(path)]
    import time
    items.insert(0, {"path": path, "name": os.path.basename(path), "opened": int(time.time())})
    s["recent"] = items[:20]
    save_settings(s)

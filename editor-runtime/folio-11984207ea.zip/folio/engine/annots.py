"""Standard PDF annotations: highlight / underline / strike-out marks and sticky notes.

These stay as real annotations (not page content) because that is what they mean: every
viewer lists them as comments, and anyone can remove them.
"""

from __future__ import annotations

import pymupdf as fitz

from . import geom
from .objects import _rgb

MARKUP = {"highlight": "add_highlight_annot", "underline": "add_underline_annot",
          "strike": "add_strikeout_annot", "squiggly": "add_squiggly_annot"}
DEFAULT_COLORS = {"highlight": "#ffe14d", "underline": "#2f6bff", "strike": "#e5484d", "squiggly": "#e5484d"}
SKIP = {fitz.PDF_ANNOT_WIDGET, fitz.PDF_ANNOT_POPUP, fitz.PDF_ANNOT_LINK}


def add_markup(doc, page, kind: str, rects_disp: list, color: str | None = None) -> int:
    fn = MARKUP.get(kind)
    if fn is None:
        raise ValueError(f"unknown markup {kind}")
    quads = []
    for r in rects_disp:
        ru = geom.rect_from_disp(page, r)
        if ru.is_empty:
            continue
        quads.append(ru.quad)
    if not quads:
        raise ValueError("nothing selected")
    annot = getattr(page, fn)(quads=quads)
    annot.set_colors(stroke=_rgb(color or DEFAULT_COLORS[kind]))
    annot.update()
    return annot.xref


def add_note(doc, page, point_disp, text: str, color: str | None = None) -> int:
    p = geom.pt_from_disp(page, point_disp)
    annot = page.add_text_annot(p, text or "", icon="Comment")
    annot.set_colors(stroke=_rgb(color or "#ffd23f"))
    annot.update()
    return annot.xref


def list_annots(doc, page) -> list[dict]:
    out = []
    for a in page.annots() or []:
        if a.type[0] in SKIP or a.type[0] == fitz.PDF_ANNOT_REDACT:
            continue
        stroke = a.colors.get("stroke") if a.colors else None
        out.append({
            "xref": a.xref, "kind": a.type[1].lower(), "rect": geom.r4(geom.rect_to_disp(page, a.rect)),
            "content": a.info.get("content", ""), "author": a.info.get("title", ""),
            "color": "#%02x%02x%02x" % tuple(int(c * 255) for c in stroke[:3]) if stroke and len(stroke) >= 3 else None,
        })
    return out


def _load(page, xref: int):
    for a in page.annots() or []:
        if a.xref == xref:
            return a
    raise KeyError("annotation not found")


def delete_annot(doc, page, xref: int) -> None:
    page.delete_annot(_load(page, int(xref)))


def update_note(doc, page, xref: int, text: str) -> None:
    a = _load(page, int(xref))
    a.set_info(content=text)
    a.update()


def move_annot(doc, page, xref: int, rect_disp) -> None:
    a = _load(page, int(xref))
    d = fitz.Rect(rect_disp)
    if a.type[0] == fitz.PDF_ANNOT_TEXT and a.flags & fitz.PDF_ANNOT_IS_NO_ROTATE:
        # A sticky note's icon keeps its size and stays upright: readers pin its
        # *unrotated* top-left corner and draw the icon from there. On a rotated page
        # that corner is not the one the user sees, so anchor it at the drop point.
        p = geom.pt_from_disp(page, d.tl)
        cur = fitz.Rect(a.rect)
        a.set_rect(fitz.Rect(p.x, p.y, p.x + cur.width, p.y + cur.height))
    else:
        a.set_rect(geom.rect_from_disp(page, d))
    a.update()

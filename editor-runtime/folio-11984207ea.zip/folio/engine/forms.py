"""Fillable forms (AcroForm fields)."""

from __future__ import annotations

import pymupdf as fitz

from . import geom

TYPES = {
    fitz.PDF_WIDGET_TYPE_TEXT: "text", fitz.PDF_WIDGET_TYPE_CHECKBOX: "checkbox",
    fitz.PDF_WIDGET_TYPE_RADIOBUTTON: "radio", fitz.PDF_WIDGET_TYPE_COMBOBOX: "combo",
    fitz.PDF_WIDGET_TYPE_LISTBOX: "list", fitz.PDF_WIDGET_TYPE_SIGNATURE: "signature",
    fitz.PDF_WIDGET_TYPE_BUTTON: "button",
}


def page_fields(doc, page) -> list[dict]:
    out = []
    for w in page.widgets() or []:
        kind = TYPES.get(w.field_type, "other")
        flags = w.field_flags or 0
        item = {
            "xref": w.xref, "name": w.field_name or "", "label": w.field_label or "", "kind": kind,
            "rect": geom.r4(geom.rect_to_disp(page, w.rect)),
            "readonly": bool(flags & fitz.PDF_FIELD_IS_READ_ONLY),
            "required": bool(flags & fitz.PDF_FIELD_IS_REQUIRED),
            "fontsize": w.text_fontsize or 0,
        }
        if kind == "text":
            item["value"] = w.field_value or ""
            item["multiline"] = bool(flags & fitz.PDF_TX_FIELD_IS_MULTILINE)
            item["maxlen"] = w.text_maxlen or 0
            item["comb"] = bool(flags & fitz.PDF_TX_FIELD_IS_COMB)
            item["password"] = bool(flags & fitz.PDF_TX_FIELD_IS_PASSWORD)
        elif kind in ("checkbox", "radio"):
            on = w.on_state()
            item["on"] = on if isinstance(on, str) else "Yes"
            val = w.field_value
            item["checked"] = bool(val) and val not in ("Off", False, "") and (val is True or val == item["on"] or kind == "checkbox")
        elif kind in ("combo", "list"):
            # [value stored in the file, text shown]: they differ in many forms ("CA" / "Canada")
            item["value"] = w.field_value or ""
            item["options"] = [[c, c] if isinstance(c, str) else [c[0], c[1] if len(c) > 1 else c[0]]
                               for c in (w.choice_values or [])]
        else:
            item["value"] = w.field_value if isinstance(w.field_value, str) else ""
        out.append(item)
    return out


def drop_xfa(doc) -> bool:
    """Remove a form's XFA copy. Hybrid forms (common for government/HR PDFs) keep the
    field values twice; Adobe Reader prefers the XFA copy, which MuPDF doesn't update, so
    after filling it would show stale values. Without XFA every viewer uses the real fields."""
    try:
        cat = doc.pdf_catalog()
        kind, _val = doc.xref_get_key(cat, "AcroForm/XFA")
        if kind != "null":
            doc.xref_set_key(cat, "AcroForm/XFA", "null")
            return True
    except Exception:
        pass
    return False


def set_field(doc, page, xref: int, value) -> list[int]:
    """Fill a field. Returns the other pages that show the same field (MuPDF updates
    every widget of a field, so those pages look different now too)."""
    drop_xfa(doc)
    w = page.load_widget(int(xref))
    if w is None:
        raise KeyError("field not found")
    if w.field_flags & fitz.PDF_FIELD_IS_READ_ONLY:
        raise ValueError("This field is read-only.")
    kind = TYPES.get(w.field_type)
    if kind == "checkbox":
        w.field_value = w.on_state() if value else "Off"
    elif kind == "radio":
        w.field_value = w.on_state() if value else "Off"
    elif kind in ("combo", "list"):
        w.field_value = str(value)
    elif kind == "text":
        v = "" if value is None else str(value)
        if w.text_maxlen and len(v) > w.text_maxlen:
            v = v[: w.text_maxlen]
        w.field_value = v
    else:
        raise ValueError("This kind of field can't be filled here.")
    name = w.field_name
    w.update()
    others = []
    if name:
        for pno in range(doc.page_count):
            if pno != page.number and any(o.field_name == name for o in doc[pno].widgets() or []):
                others.append(pno)
    return others


def flatten(doc) -> None:
    drop_xfa(doc)
    doc.bake(annots=False, widgets=True)


def flatten_all(doc) -> None:
    drop_xfa(doc)
    doc.bake(annots=True, widgets=True)

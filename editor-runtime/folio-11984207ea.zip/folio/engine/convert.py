"""Conversions: images <-> PDF, PDF -> Word, Office -> PDF.

Word/Excel/PowerPoint conversions drive the Office already installed on this PC (through
its COM automation interface, via a short PowerShell script), so the results are as good
as Office's own "Save as PDF" and "Open PDF" — no extra libraries, nothing uploaded.
"""

from __future__ import annotations

import io
import os
import shutil
import subprocess
import tempfile

import pymupdf as fitz

PAGE_SIZES = {"letter": (612, 792), "a4": (595.28, 841.89), "legal": (612, 1008)}
OFFICE_EXTS = {
    ".doc": "word", ".docx": "word", ".rtf": "word", ".odt": "word", ".txt": "word",
    ".xls": "excel", ".xlsx": "excel", ".csv": "excel", ".ods": "excel",
    ".ppt": "powerpoint", ".pptx": "powerpoint", ".odp": "powerpoint",
}

_PS_HEAD = "$ErrorActionPreference='Stop';"


def _ps_quote(s: str) -> str:
    return "'" + s.replace("'", "''") + "'"


def _run_ps(script: str, timeout: int = 240) -> None:
    exe = os.path.join(os.environ.get("SystemRoot", r"C:\Windows"), "System32", "WindowsPowerShell", "v1.0", "powershell.exe")
    if not os.path.exists(exe):
        exe = "powershell"
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    r = subprocess.run([exe, "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", _PS_HEAD + script],
                       capture_output=True, text=True, timeout=timeout, creationflags=flags)
    if r.returncode != 0:
        msg = (r.stderr or r.stdout or "").strip().splitlines()
        msg = next((m for m in msg if m.strip()), "Office automation failed")
        if "80040154" in msg or "Retrieving the COM class factory" in msg or "Cannot create" in msg:
            raise RuntimeError("Microsoft Office isn't available on this PC for this conversion.")
        raise RuntimeError(msg[:300])


def office_available(kind: str = "word") -> bool:
    import winreg
    progid = {"word": "Word.Application", "excel": "Excel.Application", "powerpoint": "PowerPoint.Application"}[kind]
    try:
        winreg.CloseKey(winreg.OpenKey(winreg.HKEY_CLASSES_ROOT, progid))
        return True
    except OSError:
        return False


def office_to_pdf(src: str, dst: str) -> str:
    ext = os.path.splitext(src)[1].lower()
    kind = OFFICE_EXTS.get(ext)
    if not kind:
        raise ValueError(f"Can't convert {ext} files.")
    # Work on a private copy so a file that is open in Office still converts.
    tmpdir = tempfile.mkdtemp(prefix="folio-office-")
    try:
        work = os.path.join(tmpdir, "input" + ext)
        shutil.copy2(src, work)
        out = os.path.join(tmpdir, "output.pdf")
        s, o = _ps_quote(work), _ps_quote(out)
        if kind == "word":
            script = (f"$w=New-Object -ComObject Word.Application;$w.Visible=$false;$w.DisplayAlerts=0;"
                      f"try{{$d=$w.Documents.Open({s},$false,$true,$false);$d.ExportAsFixedFormat({o},17);$d.Close(0)}}"
                      f"finally{{$w.Quit();[void][Runtime.InteropServices.Marshal]::ReleaseComObject($w)}}")
        elif kind == "excel":
            script = (f"$x=New-Object -ComObject Excel.Application;$x.Visible=$false;$x.DisplayAlerts=$false;"
                      f"try{{$b=$x.Workbooks.Open({s},0,$true);$b.ExportAsFixedFormat(0,{o});$b.Close($false)}}"
                      f"finally{{$x.Quit();[void][Runtime.InteropServices.Marshal]::ReleaseComObject($x)}}")
        else:
            script = (f"$p=New-Object -ComObject PowerPoint.Application;"
                      f"try{{$d=$p.Presentations.Open({s},-1,0,0);$d.SaveAs({o},32);$d.Close()}}"
                      f"finally{{$p.Quit();[void][Runtime.InteropServices.Marshal]::ReleaseComObject($p)}}")
        _run_ps(script)
        if not os.path.exists(out):
            raise RuntimeError("Office did not produce a PDF.")
        shutil.move(out, dst)
        return dst
    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)


def pdf_to_word(pdf_bytes: bytes, dst: str) -> str:
    """Word's own PDF reflow ("Open PDF in Word") saved as .docx."""
    tmpdir = tempfile.mkdtemp(prefix="folio-word-")
    try:
        src = os.path.join(tmpdir, "input.pdf")
        with open(src, "wb") as f:
            f.write(pdf_bytes)
        out = os.path.join(tmpdir, "output.docx")
        s, o = _ps_quote(src), _ps_quote(out)
        script = (f"$w=New-Object -ComObject Word.Application;$w.Visible=$false;$w.DisplayAlerts=0;"
                  f"try{{$d=$w.Documents.Open({s},$false,$true,$false);$d.SaveAs2({o},16);$d.Close(0)}}"
                  f"finally{{$w.Quit();[void][Runtime.InteropServices.Marshal]::ReleaseComObject($w)}}")
        _run_ps(script, timeout=600)
        if not os.path.exists(out):
            raise RuntimeError("Word did not produce a document.")
        shutil.move(out, dst)
        return dst
    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)


def _image_bytes(path_or_bytes, name: str = "") -> tuple[bytes, int, int]:
    """Image bytes with EXIF rotation applied, plus pixel size."""
    from PIL import Image, ImageOps
    raw = path_or_bytes if isinstance(path_or_bytes, (bytes, bytearray)) else open(path_or_bytes, "rb").read()
    try:
        im = Image.open(io.BytesIO(raw))
        was_jpeg = im.format == "JPEG"  # exif_transpose returns a copy that has no format
        im = ImageOps.exif_transpose(im)
        fmt = "JPEG" if (was_jpeg or (im.mode == "RGB" and len(raw) > 400_000)) else "PNG"
        if fmt == "JPEG" and im.mode not in ("RGB", "L"):
            im = im.convert("RGB")
        buf = io.BytesIO()
        if fmt == "JPEG":
            im.save(buf, "JPEG", quality=92)
        else:
            im.save(buf, "PNG", optimize=True)
        return buf.getvalue(), im.width, im.height
    except Exception:
        pix = fitz.Pixmap(raw)
        return raw, pix.width, pix.height


def images_to_pdf(items: list, page_size: str = "letter", margin: float = 18) -> fitz.Document:
    """items: file paths or (name, bytes). page_size: letter | a4 | legal | fit."""
    doc = fitz.open()
    for it in items:
        if isinstance(it, (tuple, list)):
            data, w, h = _image_bytes(it[1], it[0])
        else:
            data, w, h = _image_bytes(it)
        if page_size == "fit":
            # page has the image's proportions, long side 11in
            scale = 792 / max(w, h)
            pw, ph = w * scale, h * scale
            m = 0
        else:
            pw, ph = PAGE_SIZES.get(page_size, PAGE_SIZES["letter"])
            if (w > h) != (pw > ph):
                pw, ph = ph, pw
            m = margin
        page = doc.new_page(width=pw, height=ph)
        box = fitz.Rect(m, m, pw - m, ph - m)
        page.insert_image(box, stream=data, keep_proportion=True)
    if doc.page_count == 0:
        raise ValueError("No images to convert.")
    return doc


def pdf_to_images(doc: fitz.Document, pnos: list[int], folder: str, base: str, fmt: str = "png", dpi: int = 150) -> list[str]:
    os.makedirs(folder, exist_ok=True)
    fmt = "jpg" if fmt.lower() in ("jpg", "jpeg") else "png"
    out = []
    width = len(str(doc.page_count))
    for p in pnos:
        pix = doc[p].get_pixmap(dpi=int(dpi), alpha=False)
        name = f"{base}-p{str(p + 1).zfill(width)}.{fmt}"
        path = os.path.join(folder, name)
        n = 2
        while os.path.exists(path):  # never overwrite files already in the folder
            path = os.path.join(folder, f"{base}-p{str(p + 1).zfill(width)} ({n}).{fmt}")
            n += 1
        if fmt == "jpg":
            pix.save(path, jpg_quality=90)
        else:
            pix.save(path)
        out.append(path)
    return out

"""Make PDFs smaller.

Where the bytes go in a typical PDF: images (by far), embedded fonts, then structure.
So: re-sample images that are sharper than the page can show and re-encode them as
JPEG, subset fully-embedded fonts, drop unused objects, and pack the rest with object
streams. Text and vector graphics are never rasterised.
"""

from __future__ import annotations

import pymupdf as fitz

from . import objects

# name: (dpi threshold, dpi target, JPEG quality)
PRESETS = {
    "light": (220, 180, 85),
    "balanced": (160, 130, 72),
    "strong": (120, 100, 58),
    "max": (90, 72, 42),
}
LADDER = ["light", "balanced", "strong", "max"]


def _text_signature(doc: fitz.Document) -> list[str]:
    return [p.get_text("text") for p in doc]


def compress_bytes(data: bytes, preset: str = "balanced", gray: bool = False, fonts: bool = True) -> bytes:
    thr, tgt, q = PRESETS[preset]
    doc = fitz.open("pdf", data)
    # rewrite_images re-writes page content streams; keep Folio's added objects (each a
    # separate, tagged stream) out of it so they stay movable/editable afterwards.
    lifted = objects.lift_all(doc)
    try:
        doc.rewrite_images(dpi_threshold=thr, dpi_target=tgt, quality=q, lossy=True, lossless=True,
                           bitonal=True, color=True, gray=True, set_to_gray=gray)
    except Exception:
        pass
    finally:
        objects.restore_all(doc, lifted)
    if fonts:
        try:
            trial = fitz.open("pdf", doc.tobytes())
            before = _text_signature(trial)
            trial.subset_fonts()
            if _text_signature(trial) == before:
                doc = trial
        except Exception:
            pass
    out = doc.tobytes(garbage=4, deflate=True, deflate_images=True, deflate_fonts=True, use_objstms=1)
    return out


def compress(data: bytes, preset: str = "balanced", gray: bool = False) -> bytes:
    out = compress_bytes(data, preset, gray)
    if len(out) >= len(data):
        # images were already lean; still try a structural clean-up only
        try:
            doc = fitz.open("pdf", data)
            alt = doc.tobytes(garbage=4, deflate=True, use_objstms=1)
            return alt if len(alt) < len(data) else data
        except Exception:
            return data
    return out


def compress_to(data: bytes, target_bytes: int, gray: bool = False) -> tuple[bytes, str, bool]:
    """Smallest preset that gets under target_bytes. Returns (bytes, preset, reached)."""
    best, best_name = data, "none"
    for name in LADDER:
        out = compress(data, name, gray)
        if len(out) < len(best):
            best, best_name = out, name
        if len(out) <= target_bytes:
            return out, name, True
    if not gray:
        out = compress(data, "max", True)
        if len(out) < len(best):
            best, best_name = out, "max+gray"
        if len(out) <= target_bytes:
            return out, "max+gray", True
    return best, best_name, len(best) <= target_bytes

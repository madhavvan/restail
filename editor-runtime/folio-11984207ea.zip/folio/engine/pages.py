"""Page-level operations: rotate, delete, reorder, duplicate, insert, extract, split."""

from __future__ import annotations

import os
import re

import pymupdf as fitz

IMAGE_EXTS = (".png", ".jpg", ".jpeg", ".jfif", ".gif", ".bmp", ".tif", ".tiff", ".webp", ".jxr", ".jpx", ".pnm")


def rotate(doc: fitz.Document, pnos: list[int], delta: int) -> None:
    for p in pnos:
        page = doc[p]
        page.set_rotation((page.rotation + int(delta)) % 360)


def delete(doc: fitz.Document, pnos: list[int]) -> None:
    pnos = sorted(set(int(p) for p in pnos))
    if len(pnos) >= doc.page_count:
        raise ValueError("A PDF needs at least one page — you can't delete them all.")
    doc.delete_pages(pnos)


def reorder(doc: fitz.Document, order: list[int]) -> None:
    order = [int(p) for p in order]
    if sorted(order) != list(range(doc.page_count)):
        raise ValueError("invalid page order")
    if order != list(range(doc.page_count)):
        doc.select(order)


def move(doc: fitz.Document, pnos: list[int], to: int) -> list[int]:
    """Move the given pages so the block starts at index `to` of the final order.
    Returns the new page numbers of the moved pages."""
    pnos = sorted(set(int(p) for p in pnos))
    rest = [p for p in range(doc.page_count) if p not in pnos]
    to = max(0, min(int(to), len(rest)))
    order = rest[:to] + pnos + rest[to:]
    reorder(doc, order)
    return list(range(to, to + len(pnos)))


def duplicate(doc: fitz.Document, pnos: list[int]) -> None:
    # Copied from a snapshot with insert_pdf, which keeps the page's content streams as
    # they are (fullcopy_page merges them, turning added objects into fixed content).
    src = fitz.open("pdf", doc.tobytes())
    for p in sorted(set(int(p) for p in pnos), reverse=True):
        at = p + 1 if p + 1 < doc.page_count else -1
        doc.insert_pdf(src, from_page=p, to_page=p, start_at=at)


def insert_blank(doc: fitz.Document, at: int, like: int | None = None) -> int:
    ref = doc[min(max(0, like if like is not None else at - 1), doc.page_count - 1)]
    mb = fitz.Rect(ref.cropbox)  # the size you see (a cropped page's MediaBox is bigger)
    rot = ref.rotation
    ref = None  # page objects go stale once the page tree changes
    at = max(0, min(int(at), doc.page_count))
    page = doc.new_page(pno=at if at < doc.page_count else -1, width=mb.width, height=mb.height)
    if rot:
        page.set_rotation(rot)
    return at


def open_any(path_or_bytes, name: str = "") -> fitz.Document:
    """Open a PDF, or turn an image / XPS / EPUB etc. into a PDF document."""
    ext = os.path.splitext(name if isinstance(path_or_bytes, (bytes, bytearray)) else path_or_bytes)[1].lower()
    try:
        if isinstance(path_or_bytes, (bytes, bytearray)):
            src = fitz.open(stream=bytes(path_or_bytes), filetype=ext.lstrip(".") or "pdf")
        else:
            src = fitz.open(path_or_bytes)
    except Exception:
        if ext not in IMAGE_EXTS:
            raise
        # an image format MuPDF doesn't read (WebP, ...): through Pillow instead
        from .convert import images_to_pdf
        item = (name, bytes(path_or_bytes)) if isinstance(path_or_bytes, (bytes, bytearray)) else path_or_bytes
        return images_to_pdf([item], "fit")
    if src.is_pdf:
        return src
    pdf_bytes = src.convert_to_pdf()
    return fitz.open("pdf", pdf_bytes)


def insert_doc(doc: fitz.Document, src: fitz.Document, at: int, first: int | None = None, last: int | None = None) -> list[int]:
    if src.needs_pass:
        raise ValueError("That PDF is password protected — open it in Folio first, then save a copy without a password.")
    first = 0 if first is None else max(0, int(first))
    last = src.page_count - 1 if last is None else min(int(last), src.page_count - 1)
    at = max(0, min(int(at), doc.page_count))
    n0 = doc.page_count
    doc.insert_pdf(src, from_page=first, to_page=last, start_at=at if at < n0 else -1)
    added = doc.page_count - n0
    return list(range(at, at + added))


def extract(doc: fitz.Document, pnos: list[int]) -> bytes:
    pnos = [int(p) for p in pnos]
    d2 = fitz.open("pdf", doc.tobytes())
    d2.select(pnos)
    return d2.tobytes(garbage=3, deflate=True)


def parse_ranges(spec: str, n: int) -> list[list[int]]:
    """'1-3, 5, 8-' -> [[0,1,2],[4],[7..n-1]] (1-based input, 0-based output)."""
    groups = []
    for part in re.split(r"[;,]", spec or ""):
        part = part.strip()
        if not part:
            continue
        m = re.fullmatch(r"(\d*)\s*-\s*(\d*)", part)
        if m:
            a = int(m.group(1)) if m.group(1) else 1
            b = int(m.group(2)) if m.group(2) else n
        elif part.isdigit():
            a = b = int(part)
        else:
            raise ValueError(f"Can't read the page range '{part}'. Use something like 1-3, 5, 8-")
        a, b = max(1, a), min(n, b)
        if a > b:
            raise ValueError(f"Page range '{part}' is empty (this file has {n} pages).")
        groups.append(list(range(a - 1, b)))
    if not groups:
        raise ValueError("Enter at least one page range.")
    return groups


def split_every(n: int, k: int) -> list[list[int]]:
    k = max(1, int(k))
    return [list(range(i, min(i + k, n))) for i in range(0, n, k)]

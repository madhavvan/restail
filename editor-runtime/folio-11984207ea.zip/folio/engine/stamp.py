"""Page numbers and watermarks."""

from __future__ import annotations

import math

import pymupdf as fitz

from . import geom, objects
from .fonts import FontIndex, needs_shaping


def page_numbers(doc, pnos: list[int], fmt: str = "Page {n} of {N}", position: str = "bottom-center",
                 size: float = 10, margin: float = 30, start: int = 1, family: str = "Arial",
                 color: str = "#000000") -> None:
    """Each number is an ordinary Folio text object, so it can be moved or deleted later."""
    fi = FontIndex.get()
    total = start + len(pnos) - 1
    for i, p in enumerate(pnos):
        page = doc[p]
        label = fmt.replace("{n}", str(start + i)).replace("{N}", str(total))
        meta = {"type": "text", "text": label, "size": float(size), "font": {"family": family, "bold": False, "italic": False},
                "color": color, "align": "left", "lh": 1.2, "w": None}
        lines, bw, bh, _f = objects.layout_text(meta, fi)
        W, H = page.rect.width, page.rect.height
        vert, horiz = (position.split("-") + ["center"])[:2]
        x = {"left": margin, "center": (W - bw) / 2, "right": W - margin - bw}.get(horiz, (W - bw) / 2)
        y = margin if vert == "top" else H - margin - bh
        meta.update(objects.new_frame(page, (x, y, x + bw, y + bh)))
        meta["role"] = "page-number"
        objects.add_object(doc, page, meta)


def watermark(doc, pnos: list[int], text: str, size: float = 64, color: str = "#888888", opacity: float = 0.22,
              angle: float = 45, family: str = "Arial", bold: bool = True) -> None:
    """Diagonal text across the middle of each page (baked into the page content)."""
    if needs_shaping(text):
        raise ValueError("Watermarks in Arabic, Hebrew or Indic scripts aren't supported yet. "
                         "Add the text as a text box instead.")
    fi = FontIndex.get()
    face = fi.face_for_family(family, bold, False) or fi.generic(bold=bold)
    # characters the face lacks come from a face that has them (never empty boxes)
    if face is not None:
        runs = fi.split_by_coverage(face, text)
        chars: dict[str, set] = {}
        for t, f in runs:
            chars.setdefault(f.key, set()).update(t)
        fonts = {k: fitz.Font(fontbuffer=fi.subset(fi.by_key[k], "".join(v))) for k, v in chars.items()}
        runs = [(t, fonts[f.key]) for t, f in runs]
    else:
        runs = [(text, fitz.Font("helv"))]
    rgb = objects._rgb(color)
    for p in pnos:
        page = doc[p]
        objects.ensure_wrapped(doc, page)
        W, H = page.rect.width, page.rect.height
        tw_len = sum(f.text_length(t, fontsize=size) for t, f in runs)
        a = math.radians(angle)
        ddir = fitz.Point(math.cos(a), -math.sin(a))          # display direction (up-right)
        dn = fitz.Point(math.sin(a), math.cos(a))             # display "down" for the text
        center = fitz.Point(W / 2, H / 2)
        start_d = center - ddir * (tw_len / 2) + dn * (size * 0.35)
        start_u = geom.pt_from_disp(page, start_d)
        du = geom.vec_from_disp(page, ddir)
        tw = fitz.TextWriter(page.rect, color=rgb)
        pos = fitz.Point(start_u)
        for t, f in runs:
            tw.append(pos, t, font=f, fontsize=size)
            pos = fitz.Point(pos.x + f.text_length(t, fontsize=size), pos.y)
        morph = geom.morph_for_dir(start_u, (du.x, du.y))
        tw.write_text(page, morph=morph, opacity=opacity)

"""Existing text: read it as editable lines, search it, and rewrite lines in place.

How an edit works (first principles): a PDF line is a sequence of positioned glyphs in a
font that is usually embedded as a *subset* — only the letters the document already uses.
So an edit is three steps:
  1. diff old vs new text and widen the change to whole words;
  2. remove exactly those glyphs with a thin redaction band through the middle of the
     line (nothing else on the page is touched: no images, no lines, no neighbours);
  3. re-set the new words at the original baseline, size, colour and letter spacing, in
     the best font we can get: the very font object the line uses (when its subset has
     every glyph needed), else the identical installed face, else the nearest installed
     face. Words after the change keep their exact original spacing and simply shift by
     the width difference.
"""

from __future__ import annotations

import logging
import re
import statistics
from dataclasses import dataclass, field

import pymupdf as fitz

from . import fontres, geom, objects
from .fonts import Face, FontIndex, needs_shaping, norm, strip_subset

log = logging.getLogger("folio.text")

EXTRACT_FLAGS = fitz.TEXT_PRESERVE_WHITESPACE | fitz.TEXT_MEDIABOX_CLIP

# Folio re-sets words glyph by glyph without a shaping engine, so editing right-to-left
# or joined scripts in place would scramble them: such lines are left alone.
COMPLEX_MSG = "Folio can't edit right-to-left or joined scripts (such as Arabic, Hebrew or Hindi) in place yet."
F_SUPER, F_ITALIC, F_SERIF, F_MONO, F_BOLD = 1, 2, 4, 8, 16
CF_FILLED, CF_STROKED = 16, 32

BASE14 = {
    "helvetica": "helv", "helvetica-bold": "hebo", "helvetica-oblique": "heit",
    "helvetica-boldoblique": "hebi", "times-roman": "tiro", "times-bold": "tibo",
    "times-italic": "tiit", "times-bolditalic": "tibi", "courier": "cour", "courier-bold": "cobo",
    "courier-oblique": "coit", "courier-boldoblique": "cobi",
}


# ------------------------------------------------------------------ data model
@dataclass
class Span:
    font: str
    size: float
    flags: int
    color: int
    alpha: int
    asc: float
    desc: float

    @property
    def bold(self) -> bool:
        return bool(self.flags & F_BOLD) or "bold" in self.font.lower() or "black" in self.font.lower()

    @property
    def italic(self) -> bool:
        f = self.font.lower()
        return bool(self.flags & F_ITALIC) or "italic" in f or "oblique" in f

    @property
    def serif(self) -> bool:
        return bool(self.flags & F_SERIF)

    @property
    def mono(self) -> bool:
        return bool(self.flags & F_MONO)

    @property
    def rgb(self) -> tuple:
        c = self.color
        return ((c >> 16) & 255) / 255, ((c >> 8) & 255) / 255, (c & 255) / 255


@dataclass
class Char:
    c: str
    bbox: tuple
    o: tuple
    s: int
    synthetic: bool


@dataclass
class Line:
    key: str
    bbox: fitz.Rect
    dir: tuple
    wmode: int
    spans: list
    chars: list
    invisible: bool
    in_object: bool = False

    @property
    def text(self) -> str:
        return "".join(c.c for c in self.chars)


def page_lines(doc: fitz.Document, page: fitz.Page) -> list[Line]:
    raw = objects.content_text(page, EXTRACT_FLAGS)
    obj_rects = [objects.local_rect_to_page(m) for _x, m in objects.object_streams(doc, page)
                 if m.get("type") == "text"]
    lines: list[Line] = []
    for bi, b in enumerate(raw.get("blocks", [])):
        if b.get("type", 0) != 0:
            continue
        for li, ln in enumerate(b.get("lines", [])):
            spans: list[Span] = []
            chars: list[Char] = []
            visible = False
            for s in ln.get("spans", []):
                si = len(spans)
                cf = s.get("char_flags")
                alpha = s.get("alpha", 255)
                if alpha and (cf is None or cf & (CF_FILLED | CF_STROKED)):
                    visible = True
                spans.append(Span(font=s.get("font", ""), size=float(s.get("size", 0)), flags=s.get("flags", 0),
                                  color=s.get("color", 0), alpha=alpha,
                                  asc=s.get("ascender", 0.9), desc=s.get("descender", -0.25)))
                for ch in s.get("chars", []):
                    chars.append(Char(ch["c"], tuple(ch["bbox"]), tuple(ch["origin"]), si,
                                      bool(ch.get("synthetic", False))))
            if not chars:
                continue
            bbox = fitz.Rect(ln["bbox"])
            in_obj = any(r.contains(fitz.Point((bbox.x0 + bbox.x1) / 2, (bbox.y0 + bbox.y1) / 2))
                         for r in obj_rects)
            lines.append(Line(f"{bi}.{li}", bbox, tuple(ln.get("dir", (1, 0))), ln.get("wmode", 0),
                              spans, chars, not visible, in_obj))
    return _merge_fragments(lines)


def _merge_fragments(lines: list[Line]) -> list[Line]:
    """Join pieces of one visual line that the PDF draws separately.

    Many producers emit a line as several text objects (and every edit we make adds
    one), which MuPDF reports as separate lines. Pieces on the same baseline that touch
    or sit a normal word-gap apart become one line again; column gaps stay separate."""
    out: list[Line] = []
    buckets: dict[tuple, list] = {}
    for ln in lines:
        d = geom.axis_dir(ln.dir)
        if d is None or ln.wmode:
            out.append(ln)
            continue
        nrm = (-d[1], d[0])
        O = ln.chars[0].o
        base = O[0] * nrm[0] + O[1] * nrm[1]
        start = min(min(c.bbox[0] * d[0] + c.bbox[1] * d[1], c.bbox[2] * d[0] + c.bbox[3] * d[1]) for c in ln.chars)
        buckets.setdefault(d, []).append((base, start, ln))
    for d, items in buckets.items():
        items.sort(key=lambda it: (round(it[0], 1), it[1]))
        # cluster by baseline
        clusters: list[list] = []
        for it in items:
            size = max((s.size for s in it[2].spans), default=10)
            if clusters and abs(clusters[-1][-1][0] - it[0]) <= max(0.6, 0.12 * size):
                clusters[-1].append(it)
            else:
                clusters.append([it])
        for cl in clusters:
            cl.sort(key=lambda it: it[1])
            cur = cl[0][2]
            for _base, _start, nxt in cl[1:]:
                merged = _try_join(cur, nxt, d)
                if merged is None:
                    out.append(cur)
                    cur = nxt
                else:
                    cur = merged
            out.append(cur)
    return out


def _t_extent(ch: Char, d) -> tuple[float, float]:
    a = ch.bbox[0] * d[0] + ch.bbox[1] * d[1]
    b = ch.bbox[2] * d[0] + ch.bbox[3] * d[1]
    return (a, b) if a <= b else (b, a)


def _try_join(a: Line, b: Line, d) -> Line | None:
    if a.invisible != b.invisible or a.in_object != b.in_object:
        return None
    size = max((s.size for s in a.spans + b.spans), default=10)
    a_end = max(_t_extent(c, d)[1] for c in a.chars)
    b_start = min(_t_extent(c, d)[0] for c in b.chars)
    gap = b_start - a_end
    if gap > 2.2 * size or gap < -0.3 * size:
        return None
    off = len(a.spans)
    chars = list(a.chars)
    last = a.chars[-1]
    if gap > 0.12 * size and not last.c.isspace() and not b.chars[0].c.isspace():
        first = b.chars[0]
        lb, fb = fitz.Rect(last.bbox), fitz.Rect(first.bbox)
        if d == (1, 0):
            sb = (lb.x1, lb.y0, fb.x0, lb.y1)
        elif d == (-1, 0):
            sb = (fb.x1, lb.y0, lb.x0, lb.y1)
        elif d == (0, 1):
            sb = (lb.x0, lb.y1, lb.x1, fb.y0)
        else:
            sb = (lb.x0, fb.y1, lb.x1, lb.y0)
        chars.append(Char(" ", sb, last.o, last.s, True))
    for c in b.chars:
        chars.append(Char(c.c, c.bbox, c.o, c.s + off, c.synthetic))
    return Line(a.key + "+" + b.key, fitz.Rect(a.bbox) | b.bbox, a.dir, a.wmode, a.spans + b.spans, chars,
                a.invisible, a.in_object)


# ------------------------------------------------------------------ fonts on the page
def _page_fonts(doc, page, cache) -> dict:
    """Fonts on the page, findable by the PDF's /BaseFont *and* by the embedded program's
    own name — MuPDF reports text spans under the latter, and the two can differ
    (e.g. BaseFont 'Helvetica' with an embedded 'NimbusSans-Regular')."""
    key = ("pagefonts", page.xref)
    if key not in cache:
        m: dict[str, list] = {}
        for xref, ext, typ, basefont, *_rest in page.get_fonts(full=True):
            entry = (xref, ext, typ, basefont)
            m.setdefault(norm(strip_subset(basefont)), []).append(entry)
            if ext not in ("n/a", ""):
                ef = _embedded_font(doc, xref, cache)
                if ef is not None:
                    pn = norm(strip_subset(ef.name))
                    if pn and entry not in m.get(pn, []):
                        m.setdefault(pn, []).append(entry)
        cache[key] = m
    return cache[key]


def _embedded_font(doc, xref, cache) -> fitz.Font | None:
    return fontres.embedded_program(doc, xref, cache)[0]


@dataclass
class Choice:
    kind: str                    # resource | system | embedded | builtin
    quality: str                 # exact | family | similar | fallback
    label: str
    face: Face | None = None
    font: fitz.Font | None = None
    builtin: str | None = None
    res: fontres.FontRes | None = None          # kind 'resource': the PDF's own font object
    extra: dict = field(default_factory=dict)   # face_key -> fitz.Font for coverage fallbacks

    def length(self, text: str, size: float, font: fitz.Font | None = None) -> float:
        if self.kind == "builtin":
            return fitz.get_text_length(text, fontname=self.builtin, fontsize=size)
        if self.kind == "resource":
            return self.res.length(text, size)
        return (font or self.font).text_length(text, fontsize=size)

    def space(self, size: float) -> float:
        if self.kind == "builtin":
            return fitz.get_text_length(" ", fontname=self.builtin, fontsize=size)
        if self.kind == "resource":
            return self.res.space(size)
        if self.font is not None and self.font.has_glyph(32):
            return self.font.text_length(" ", fontsize=size)
        return 0.25 * size

    @property
    def tracks(self) -> bool:
        """Can text in this choice be written with letter spacing (PDF Tc)?"""
        return self.kind != "builtin"


def _latin1(text: str) -> bool:
    return all(ord(c) < 256 for c in text)


def choose_font(doc, page, span: Span, chars: str, cache: dict, horizontal: bool,
                where: tuple | None = None) -> Choice:
    """`where` = (origin, direction) of the line, for proving a PDF font's mapping."""
    fi = FontIndex.get()
    base = strip_subset(span.font)
    need = "".join(sorted({c for c in chars if not c.isspace()}))
    entries = _page_fonts(doc, page, cache).get(norm(base), [])

    # A. The very font object the line is drawn with (its subset has every glyph, or it
    #    is a standard-14 font every reader has), when its encoding can spell the text.
    b14 = BASE14.get(base.lower())
    if where is not None:
        for xref, ext, _typ, _b in entries:
            if ext in ("n/a", "") and not b14:
                continue
            res = fontres.load(doc, xref, cache)
            if res is None or not res.covers(need):
                continue
            res.prefer_used(need, lambda: fontres.page_glyph_usage(page, cache).get(span.font, {}))
            if fontres.verify(doc, page, res, need):
                label = f"{base} (standard font)" if res.standard else f"{base} (from this PDF)"
                return Choice("resource", "exact", label, res=res)

    # B. Non-embedded standard-14 font through PyMuPDF's own writer. That writer spells
    #    only Latin-1 correctly (a curly quote or a dash comes out as a middle dot).
    if b14 and horizontal and _latin1(need) and any(ext == "n/a" for _x, ext, _t, _b in entries):
        return Choice("builtin", "exact", f"{base} (standard font)", builtin=b14)

    face, quality = fi.match(span.font, span.bold, span.italic, span.serif, span.mono)
    # C. The identical installed face.
    if face is not None and quality == "exact" and fi.covers(face, need):
        return Choice("system", "exact", f"{face.full} (installed)", face=face,
                      font=fitz.Font(fontbuffer=fi.subset(face, need + " ")))
    # D. The font program embedded in the PDF, re-embedded, if it has every glyph we
    #    need. Never a Type 1 program: MuPDF can't re-embed those correctly.
    for xref, ext, _typ, _b in entries:
        if ext in ("n/a", "", "pfa", "pfb"):
            continue
        ef = _embedded_font(doc, xref, cache)
        if ef is not None and need and all(ef.has_glyph(ord(c)) for c in need):
            return Choice("embedded", "exact", f"{base} (from this PDF)", font=ef)
    # E. Nearest installed face (same family / metric-compatible / generic).
    if face is not None:
        return Choice("system", quality, f"{face.full} (installed, replaces {base})", face=face,
                      font=fitz.Font(fontbuffer=fi.subset(face, need + " ")))
    # F. Built-in fonts as the last resort.
    bn = "tiro" if span.serif else "cour" if span.mono else "helv"
    font = fitz.Font(bn)
    return Choice("embedded", "fallback", f"{font.name} (built-in)", font=font)


# ------------------------------------------------------------------ JSON for the UI
def lines_json(doc, page, lines: list[Line]) -> list[dict]:
    fi = FontIndex.get()
    out = []
    css_cache: dict = {}
    for ln in lines:
        db = geom.rect_to_disp(page, ln.bbox)
        dd = geom.vec_to_disp(page, ln.dir)
        horizontal = abs(dd.x - 1) < 0.02 and abs(dd.y) < 0.02
        if not ln.text.strip():
            continue
        complex_script = needs_shaping(ln.text)
        editable = (horizontal and geom.axis_dir(ln.dir) is not None and not ln.invisible
                    and ln.wmode == 0 and not ln.in_object and not complex_script)
        spans = []
        start = 0
        for si, sp in enumerate(ln.spans):
            n = sum(1 for c in ln.chars if c.s == si)
            if n == 0:
                continue
            ck = (sp.font, sp.bold, sp.italic, sp.serif, sp.mono)
            if ck not in css_cache:
                face, q = fi.match(sp.font, sp.bold, sp.italic, sp.serif, sp.mono)
                css = face.css() if face else {"family": "Arial", "weight": 400, "style": "normal", "system": True}
                if face is not None:
                    css["weight"] = 700 if (sp.bold and face.weight < 600 and "bold" not in face.lstyle.lower()) else css["weight"]
                css_cache[ck] = (css, q)
            css, q = css_cache[ck]
            spans.append({"start": start, "end": start + n, "font": strip_subset(sp.font), "size": round(sp.size, 2),
                          "color": "#%06x" % (sp.color & 0xFFFFFF), "bold": sp.bold, "italic": sp.italic,
                          "css": css, "match": q})
            start += n
        item = {"key": ln.key, "text": ln.text, "bbox": geom.r4(db), "editable": editable,
                "invisible": ln.invisible, "object": ln.in_object, "spans": spans}
        if complex_script:
            item["reason"] = COMPLEX_MSG
        if horizontal:
            xs = []
            for c in ln.chars:
                cb = geom.rect_to_disp(page, c.bbox)
                xs.append([round(cb.x0, 2), round(cb.x1, 2)])
            item["xs"] = xs
            item["base"] = round(geom.pt_to_disp(page, ln.chars[0].o).y, 2)
        out.append(item)
    return out


# ------------------------------------------------------------------ locating lines
def _iou(a: fitz.Rect, b: fitz.Rect) -> float:
    inter = fitz.Rect(a) & fitz.Rect(b)
    if inter.is_empty:
        return 0.0
    ia = inter.width * inter.height
    ua = a.width * a.height + b.width * b.height - ia
    return ia / ua if ua > 0 else 0.0


def find_line(page, lines: list[Line], ref: dict) -> Line:
    bbox_u = geom.rect_from_disp(page, ref["bbox"])
    text = ref.get("text")
    best = None
    for ln in lines:
        iou = _iou(ln.bbox, bbox_u)
        if text is not None and ln.text == text and iou > 0.3:
            score = 2 + iou
        elif text is None and iou > 0.6:
            score = iou
        else:
            continue
        if best is None or score > best[0]:
            best = (score, ln)
    if best is None:
        raise LookupError("That line has changed since it was selected — click it again.")
    return best[1]


# ------------------------------------------------------------------ edit planning
@dataclass
class Piece:
    t: float          # position along the line from its origin
    n: float          # baseline offset across the line (superscripts)
    text: str
    style: int        # span index


@dataclass
class Plan:
    line: Line
    origin: fitz.Point
    d: tuple
    bands: list = field(default_factory=list)       # unrotated rects to redact
    pieces: list = field(default_factory=list)
    choices: dict = field(default_factory=dict)     # style -> Choice
    new_text: str = ""
    overflow: bool = False                          # rewritten line runs past the page edge
    tc: float = 0.0                                 # letter spacing the line was set with

    def advance(self, style: int, text: str) -> float:
        """Width of `text` written in a style, letter spacing included."""
        ch = self.choices[style]
        w = ch.length(text, self.line.spans[style].size)
        return w + (self.tc * len(text) if ch.tracks else 0.0)

    def report(self) -> dict:
        fonts, seen = [], set()
        for si in dict.fromkeys(pc.style for pc in self.pieces if pc.text):
            ch = self.choices[si]
            item = (strip_subset(self.line.spans[si].font), ch.label, ch.quality)
            if item not in seen:
                seen.add(item)
                fonts.append({"original": item[0], "used": item[1], "quality": item[2]})
        return {"fonts": fonts, "overflow": self.overflow}


def _proj(char: Char, O: fitz.Point, d, nrm) -> tuple[float, float, float, float]:
    """(t0, t1, c0, c1): extent of a char along the line and across it."""
    x0, y0, x1, y1 = char.bbox
    ts = [(px - O.x) * d[0] + (py - O.y) * d[1] for px, py in ((x0, y0), (x1, y0), (x0, y1), (x1, y1))]
    cs = [(px - O.x) * nrm[0] + (py - O.y) * nrm[1] for px, py in ((x0, y0), (x1, y0), (x0, y1), (x1, y1))]
    return min(ts), max(ts), min(cs), max(cs)


def _origin_t(char: Char, O, d, nrm) -> tuple[float, float]:
    ox, oy = char.o
    return (ox - O.x) * d[0] + (oy - O.y) * d[1], (ox - O.x) * nrm[0] + (oy - O.y) * nrm[1]


def _alignment(page, line: Line, others: list[Line] | None) -> str:
    """'center' / 'right' only when the line is clearly set that way, else 'left'.

    Judged against the lines around it in its own column, not the whole page: a
    justified line in the right-hand column ends at the page's right margin and starts
    far from its left one, yet its neighbours share its left edge, so it is
    left-anchored. Right-aligned text has ragged starts and a shared right edge; centred
    text has its middle on the column's (or page's) axis and shares neither edge."""
    d = geom.axis_dir(line.dir)
    if d is None or not others:
        return "left"
    O = fitz.Point(line.chars[0].o)
    nrm = (-d[1], d[0])

    def t_of(pt):
        return (pt[0] - O.x) * d[0] + (pt[1] - O.y) * d[1]

    def extent(ln):
        v = [c for c in ln.chars if not c.c.isspace()]
        if not v:
            return None
        return (min(t_of(v[0].bbox[:2]), t_of(v[0].bbox[2:])), max(t_of(v[-1].bbox[:2]), t_of(v[-1].bbox[2:])))

    me = extent(line)
    if me is None:
        return "left"
    left, right = me
    size = max((s.size for s in line.spans), default=10) or 10
    every, near = [], []
    for ln in others:
        if ln is line or geom.axis_dir(ln.dir) != d or ln.invisible:
            continue
        ex = extent(ln)
        if ex is None:
            continue
        every.append(ex)
        o = ln.chars[0].o
        across = (o[0] - O.x) * nrm[0] + (o[1] - O.y) * nrm[1]
        if abs(across) <= 6 * size:
            near.append(ex)
    if not every:
        return "left"
    width = right - left

    def overlap(a, b):
        return min(b, right) - max(a, left)

    peers = [(a, b) for a, b in near if overlap(a, b) > 0.6 * max(b - a, width)]
    containers = [(a, b) for a, b in near if (a, b) not in peers and a <= left + 1 and b >= right - 1]
    shares_left = any(abs(a - left) <= 2 for a, _b in peers)
    shares_right = any(abs(b - right) <= 1.5 for _a, b in peers)
    tol = max(2.0, 0.004 * page.rect.width)
    page_mid = t_of(fitz.Point(page.rect.width / 2, page.rect.height / 2) * page.derotation_matrix)
    mid = (left + right) / 2

    # A column of right-aligned figures: several neighbours end where we do, all with
    # different starts (in justified text, lines sharing the right edge share the left).
    flush = [a for a, b in peers if abs(b - right) <= 1.0 and abs(a - left) > 2]
    if len(flush) >= 2 and len({round(a) for a in flush} | {round(left)}) == len(flush) + 1:
        return "right"
    if shares_left:
        return "left"
    col = peers + containers
    if col:
        c_left = min([left] + [a for a, _b in col])
        c_right = max([right] + [b for _a, b in col])
    else:
        c_left = min([left] + [a for a, _b in every])
        c_right = max([right] + [b for _a, b in every])
    if left - c_left > 6 or (peers and not containers):
        on_axis = abs(mid - (c_left + c_right) / 2) <= tol or abs(mid - page_mid) <= tol
        if on_axis and not shares_right and all(abs((a + b) / 2 - mid) <= tol for a, b in peers):
            return "center"
    if left - c_left > 6 and abs(right - c_right) <= 1.5:
        ragged = [a for a, b in peers if abs(b - right) <= 1.5 and a - c_left > 6 and abs(a - left) > 2]
        if left - c_left > 0.35 * (c_right - c_left) or ragged:
            return "right"
    return "left"


def _cell_end(line: Line, others, geo, e: int, q: int, O, d, nrm, size0: float) -> int:
    """In a table row, words after the edit belong to other cells: they sit after a wide
    gap and line up with words in the rows above or below. Shifting them would push them
    out of their columns, so the words that follow the edit stop at the first such cell."""
    if q <= e or not others:
        return q
    chars = line.chars
    starts, ends = [], []
    for ln in others:
        if ln is line or geom.axis_dir(ln.dir) != geom.axis_dir(line.dir) or ln.invisible:
            continue
        o = ln.chars[0].o
        if abs((o[0] - O.x) * nrm[0] + (o[1] - O.y) * nrm[1]) > 4.5 * size0:
            continue
        prev_space = True
        for i, c in enumerate(ln.chars):
            if c.c.isspace():
                prev_space = True
                continue
            t0, t1, _c0, _c1 = _proj(c, O, d, nrm)
            if prev_space:
                starts.append(t0)
            if i + 1 == len(ln.chars) or ln.chars[i + 1].c.isspace():
                ends.append(t1)
            prev_space = False
    if not starts:
        return q
    k, last_ns = e, e - 1
    while k < q:
        if chars[k].c.isspace():
            k += 1
            continue
        j = k
        while j < q and not chars[j].c.isspace():
            j += 1
        gap = geo[k][0] - geo[last_ns][1] if last_ns >= 0 else 0
        if gap >= 0.9 * size0 and (any(abs(geo[k][0] - s) <= 1.0 for s in starts)
                                   or any(abs(geo[j - 1][1] - x) <= 1.0 for x in ends)):
            return k
        last_ns = j - 1
        k = j
    return q


def _tracking(line: Line, choices: dict, ot: list) -> float:
    """Letter spacing (PDF Tc) the line was set with: the median gap between where each
    glyph starts and where its predecessor's advance ends. Kerned pairs are outliers the
    median ignores; with a substitute font this also absorbs the average width
    difference, so a re-set word keeps about the width of the one it replaces."""
    chars = line.chars
    diffs = []
    exact = True
    for k in range(len(chars) - 1):
        c0, c1 = chars[k], chars[k + 1]
        if c0.c.isspace() or c1.c.isspace() or c0.synthetic or c1.synthetic or c0.s != c1.s:
            continue
        ch = choices.get(c0.s)
        if ch is None or not ch.tracks:
            continue
        exact = exact and ch.quality == "exact"
        diffs.append(ot[k + 1] - ot[k] - ch.length(c0.c, line.spans[c0.s].size))
    if len(diffs) < 3:
        return 0.0
    tc = statistics.median(diffs)
    size = max((s.size for s in line.spans), default=10) or 10
    if abs(tc) < 0.003 * size:
        return 0.0
    # Same font: this is the document's real letter spacing (Word's "expanded by 1 pt"
    # is 0.1 em at 10 pt). Substitute: it also evens out the width difference, which
    # is only worth a modest squeeze before the letters start to touch.
    lim = 0.5 * size if exact else (0.12 if any(s.mono for s in line.spans) else 0.06) * size
    return max(-lim, min(tc, lim))


def plan_line_edit(doc, page, line: Line, new: str, cache: dict, others: list[Line] | None = None) -> Plan | None:
    old = line.text
    if new == old:
        return None
    d = geom.axis_dir(line.dir)
    if d is None or line.wmode != 0:
        raise ValueError("This line is set at an angle; Folio can only edit straight lines.")
    if line.invisible:
        raise ValueError("This is hidden (OCR) text and cannot be edited.")
    if needs_shaping(old) or needs_shaping(new):
        raise ValueError(COMPLEX_MSG)
    nrm = (-d[1], d[0])
    O = fitz.Point(line.chars[0].o)
    chars = line.chars
    n_old, n_new = len(old), len(new)
    align = _alignment(page, line, others)

    p = 0
    while p < min(n_old, n_new) and old[p] == new[p]:
        p += 1
    s = 0
    while s < min(n_old, n_new) - p and old[n_old - 1 - s] == new[n_new - 1 - s]:
        s += 1
    a, b = p, n_old - s
    na, nb = p, n_new - s
    # Text added or removed together with a space at a word boundary belongs to the word
    # before it ("A| deluxe 2", not "A |deluxe 2"): otherwise the next word (in a table,
    # the next cell) would be re-set and pulled along with the change.
    if a > 0 and old[a - 1].isspace() and (b == a or old[b - 1] == old[a - 1])             and (nb == na or new[nb - 1] == old[a - 1]):
        a, b, na, nb = a - 1, b - 1, na - 1, nb - 1

    r = a
    while r > 0 and not old[r - 1].isspace():
        r -= 1
    e = b
    while e < n_old and not old[e].isspace():
        e += 1
    if align != "left":
        # a centred / right-aligned line is re-set whole so it can stay centred / flush right
        r, e = 0, n_old
    chunk = new[r:nb + (e - b)]

    # style + baseline for every character of the rewritten chunk
    if b > a:
        anchor = a
    elif a > 0 and not old[a - 1].isspace():
        anchor = a - 1
    elif a < n_old:
        anchor = a
    else:
        anchor = n_old - 1
    styles = []
    for k in range(r, a):
        styles.append(chars[k].s)
    styles.extend([chars[anchor].s] * (nb - na))
    for k in range(b, e):
        styles.append(chars[k].s)
    base_n = {}
    for k in range(n_old):
        base_n.setdefault(chars[k].s, _origin_t(chars[k], O, d, nrm)[1])

    geo = [_proj(c, O, d, nrm) for c in chars]
    ot = [_origin_t(c, O, d, nrm)[0] for c in chars]

    # Where the chunk starts along the line.
    if r < n_old:
        t_start = ot[r]
    else:
        t_start = geo[n_old - 1][1]

    plan = Plan(line=line, origin=O, d=d, new_text=new)
    horizontal_page = True

    # Words after the chunk that may need to shift (up to a column gap).
    size0 = line.spans[chars[anchor].s].size or 10
    q = e
    if e < n_old:
        last_ns = e - 1
        k = e
        while k < n_old:
            if not old[k].isspace():
                if last_ns >= 0 and geo[k][0] - geo[last_ns][1] > max(2.2 * size0, 0.0):
                    break
                last_ns = k
            k += 1
        q = k

    # Fonts: one choice per style that draws glyphs, plus the anchor's (for spacing).
    # A style holding only spaces draws nothing, so it gets no font of its own.
    needed: dict[int, set] = {chars[anchor].s: set()}
    for ch, st in zip(chunk, styles):
        if not ch.isspace():
            needed.setdefault(st, set()).add(ch)
    q = _cell_end(line, others, geo, e, q, O, d, nrm, size0)
    for k in range(e, q):
        if not old[k].isspace():
            needed.setdefault(chars[k].s, set()).add(old[k])
    for st, cs in needed.items():
        plan.choices[st] = choose_font(doc, page, line.spans[st], "".join(cs), cache,
                                       horizontal_page and d == (1, 0), where=(O, d))
    plan.tc = _tracking(line, plan.choices, ot)

    def tc_of(st):
        ch = plan.choices.get(st)
        return plan.tc if (ch is not None and ch.tracks) else 0.0

    def space_style(k):
        """Style whose space width measures a gap that follows char k-1."""
        st = chars[k - 1].s if k > 0 else chars[anchor].s
        return st if st in plan.choices else chars[anchor].s

    # Typical extra spacing between words on this line (justified text etc.).
    extras = []
    k = 0
    while k < n_old:
        if old[k].isspace():
            j = k
            while j < n_old and old[j].isspace():
                j += 1
            if k > 0 and j < n_old and not old[k - 1].isspace():
                st = space_style(k)
                gap = geo[j][0] - (geo[k - 1][1] + tc_of(chars[k - 1].s))
                nat = plan.choices[st].space(line.spans[st].size) * (j - k)
                if gap < 2.2 * size0:
                    extras.append((gap - nat) / (j - k))
            k = j
        else:
            k += 1
    extra = statistics.median(extras) if extras else 0.0
    extra = max(-0.2 * size0, min(extra, 1.0 * size0))

    # Lay the chunk out word by word from t_start.
    t = t_start
    ink_end = t_start
    prev_st = space_style(r)
    i = 0
    L = len(chunk)
    while i < L:
        if chunk[i].isspace():
            t += plan.choices[prev_st].space(line.spans[prev_st].size) + extra
            i += 1
            continue
        j = i
        while j < L and not chunk[j].isspace():
            j += 1
        # split the word into style runs
        k = i
        while k < j:
            m = k
            while m < j and styles[m] == styles[k]:
                m += 1
            st = styles[k]
            run = chunk[k:m]
            plan.pieces.append(Piece(t, base_n.get(st, 0.0), run, st))
            t += plan.advance(st, run)
            ink_end = t - tc_of(st)
            prev_st = st
            k = m
        i = j
    t_end_old = (geo[e - 1][1] + tc_of(chars[e - 1].s)) if e > r else t_start
    shift = t - t_end_old
    if align != "left":
        vis = [kk for kk in range(n_old) if not old[kk].isspace()]
        old_ink_end = geo[vis[-1]][1] if vis else t_end_old
        delta = ink_end - old_ink_end
        offset = -delta / 2 if align == "center" else -delta
        for pc in plan.pieces:
            pc.t += offset

    if q > e and abs(shift) > 0.25:
        k = e
        while k < q:
            if old[k].isspace():
                k += 1
                continue
            j = k
            while j < q and not old[j].isspace():
                j += 1
            tt = ot[k] + shift
            m = k
            while m < j:
                n2 = m
                while n2 < j and chars[n2].s == chars[m].s:
                    n2 += 1
                st = chars[m].s
                run = old[m:n2]
                plan.pieces.append(Piece(tt, _origin_t(chars[m], O, d, nrm)[1], run, st))
                tt += plan.advance(st, run)
                m = n2
            k = j
        red_end = q
    else:
        red_end = e

    # Redaction bands: one per style run in [r, red_end), through the middle of the glyphs.
    k = r
    while k < red_end:
        m = k
        while m < red_end and chars[m].s == chars[k].s:
            m += 1
        seg = [kk for kk in range(k, m) if not chars[kk].synthetic]
        if seg:
            t0 = geo[seg[0]][0] + 0.25 * (geo[seg[0]][1] - geo[seg[0]][0])
            t1 = geo[seg[-1]][1] - 0.25 * (geo[seg[-1]][1] - geo[seg[-1]][0])
            c0 = min(geo[kk][2] for kk in seg)
            c1 = max(geo[kk][3] for kk in seg)
            h = c1 - c0
            c0, c1 = c0 + 0.36 * h, c1 - 0.36 * h
            if t1 <= t0:
                t1 = t0 + 0.01
            pts = [fitz.Point(O.x + tt * d[0] + cc * nrm[0], O.y + tt * d[1] + cc * nrm[1])
                   for tt in (t0, t1) for cc in (c0, c1)]
            rect = fitz.Rect(pts[0], pts[0])
            for pt in pts[1:]:
                rect |= pt
            plan.bands.append(rect)
        k = m

    # Does the rewritten text now run past the edge of the page? (Lines don't reflow, so
    # typing more than fits would silently fall off the page; the UI warns instead.)
    if plan.pieces:
        ends = []
        for pc in plan.pieces:
            ends.extend((pc.t, pc.t + plan.advance(pc.style, pc.text) - tc_of(pc.style)))
        visible = fitz.Rect(page.rect) * page.derotation_matrix
        for tt in (min(ends), max(ends)):
            pt = fitz.Point(O.x + tt * d[0], O.y + tt * d[1])
            if not (visible.x0 - 1 <= pt.x <= visible.x1 + 1 and visible.y0 - 1 <= pt.y <= visible.y1 + 1):
                plan.overflow = True
    return plan


# ------------------------------------------------------------------ applying plans
def _stash_foreign_redactions(page) -> list:
    saved = []
    for annot in list(page.annots(types=[fitz.PDF_ANNOT_REDACT]) or []):
        info = annot.info
        saved.append({"rect": fitz.Rect(annot.rect), "fill": annot.colors.get("fill"),
                      "stroke": annot.colors.get("stroke"), "content": info.get("content", "")})
        page.delete_annot(annot)
    return saved


def _restore_foreign_redactions(page, saved) -> None:
    for s in saved:
        a = page.add_redact_annot(s["rect"], fill=s["fill"] if s["fill"] else None)
        if s.get("stroke"):
            a.set_colors(stroke=s["stroke"])
        if s.get("content"):
            a.set_info(content=s["content"])
        a.update()


_REF_RX = re.compile(r"(\d+)\s+0\s+R")


def _annot_refs(doc, page) -> list[int]:
    """Object numbers in the page's /Annots array, read from the PDF itself (PyMuPDF's
    page objects cache their link list, which goes stale within one operation)."""
    kind, val = doc.xref_get_key(page.xref, "Annots")
    if kind == "xref":
        val = doc.xref_object(int(val.split()[0]))
    elif kind != "array":
        return []
    return [int(x) for x in _REF_RX.findall(val or "")]


def _link_refs(doc, page) -> list[int]:
    return [x for x in _annot_refs(doc, page) if doc.xref_get_key(x, "Subtype")[1] == "/Link"]


def _restore_links(doc, page, links: list[int]) -> None:
    """Put back link annotations a redaction band took off the page (the link objects
    themselves are untouched, only unlisted)."""
    cur = _annot_refs(doc, page)
    missing = [x for x in links if x not in cur and doc.xref_get_key(x, "Subtype")[1] == "/Link"]
    if missing:
        doc.xref_set_key(page.xref, "Annots", "[" + " ".join(f"{x} 0 R" for x in cur + missing) + "]")


def apply_plans(doc, page, plans: list[Plan]) -> None:
    plans = [p for p in plans if p is not None]
    if not plans:
        return
    objects.ensure_wrapped(doc, page)
    saved = _stash_foreign_redactions(page)
    links_before = _link_refs(doc, page)  # redaction unlists links under a band; an edit must not
    any_band = False
    for plan in plans:
        for band in plan.bands:
            page.add_redact_annot(band, fill=False, cross_out=False)
            any_band = True
    if any_band:
        objects.redact_preserving_objects(doc, page, images=fitz.PDF_REDACT_IMAGE_NONE,
                                          graphics=fitz.PDF_REDACT_LINE_ART_NONE,
                                          text=fitz.PDF_REDACT_TEXT_REMOVE)
        _restore_links(doc, page, links_before)
    objects.ensure_wrapped(doc, page)
    fi = FontIndex.get()
    for plan in plans:
        _write_plan(doc, page, plan, fi)
    if saved:
        _restore_foreign_redactions(page, saved)


def _tw_append(tw, pos: fitz.Point, run: str, font: fitz.Font, size: float, tc: float) -> fitz.Point:
    """Append a run to a TextWriter, honouring letter spacing; returns the end point."""
    if not tc:
        tw.append(pos, run, font=font, fontsize=size)
        return fitz.Point(pos.x + font.text_length(run, fontsize=size), pos.y)
    for c in run:
        tw.append(pos, c, font=font, fontsize=size)
        pos = fitz.Point(pos.x + font.text_length(c, fontsize=size) + tc, pos.y)
    return pos


def _write_plan(doc, page, plan: Plan, fi: FontIndex) -> None:
    O = plan.origin
    d = plan.d
    nrm = (-d[1], d[0])
    morph = geom.morph_for_dir(O, d)
    writers: dict[tuple, fitz.TextWriter] = {}
    direct = []
    for pc in plan.pieces:
        if not pc.text:
            continue
        span = plan.line.spans[pc.style]
        ch = plan.choices[pc.style]
        tc = plan.tc if ch.tracks else 0.0
        if ch.kind == "resource":
            direct.append({"res": ch.res, "size": span.size, "rgb": span.rgb, "alpha": span.alpha, "tc": tc,
                           "origin": (O.x + pc.t * d[0] + pc.n * nrm[0], O.y + pc.t * d[1] + pc.n * nrm[1]),
                           "d": d, "text": pc.text})
            continue
        pos = fitz.Point(O.x + pc.t, O.y + pc.n)
        if ch.kind == "builtin":
            page.insert_text(pos, pc.text, fontname=ch.builtin, fontsize=span.size, color=span.rgb,
                             fill_opacity=span.alpha / 255 if span.alpha < 255 else 1)
            continue
        key = (span.color, span.alpha)
        tw = writers.get(key)
        if tw is None:
            tw = fitz.TextWriter(page.rect, color=span.rgb)
            writers[key] = tw
        if ch.kind == "system" and ch.face is not None and not fi.covers(ch.face, pc.text.replace(" ", "")):
            for run, face in fi.split_by_coverage(ch.face, pc.text):
                f = ch.font if face is ch.face else ch.extra.get(face.key)
                if f is None:
                    f = fitz.Font(fontbuffer=fi.subset(face, run))
                    ch.extra[face.key] = f
                pos = _tw_append(tw, pos, run, f, span.size, tc)
        else:
            _tw_append(tw, pos, pc.text, ch.font, span.size, tc)
    if direct:
        fontres.append_stream(doc, page, fontres.stream_for(doc, page, direct))
    if writers:
        before = {f[0] for f in page.get_fonts()}
        for (color, alpha), tw in writers.items():
            tw.write_text(page, morph=morph, opacity=(alpha / 255) if alpha < 255 else -1)
        for f in page.get_fonts():
            if f[0] not in before and f[2] == "Type0":
                fontres.fix_tounicode(doc, f[0])


# ------------------------------------------------------------------ public operations
def edit_line(doc, page, ref: dict, new_text: str) -> dict:
    lines = page_lines(doc, page)
    line = find_line(page, lines, ref)
    if line.in_object:
        raise ValueError("This text belongs to an added text box — double-click the box to edit it.")
    old = line.text
    trail = old[len(old.rstrip()):]
    new_full = new_text.rstrip("\r\n") + trail if ref.get("trimmed", True) else new_text
    if new_full == old:
        return {"changed": False, "fonts": []}
    plan = plan_line_edit(doc, page, line, new_full, {}, lines)
    apply_plans(doc, page, [plan])
    rep = plan.report()
    rep["changed"] = True
    return rep


def _pattern(query: str, case: bool, whole: bool, regex: bool = False) -> re.Pattern:
    pat = query if regex else re.escape(query)
    if whole:
        pat = r"(?<!\w)" + pat + r"(?!\w)"
    return re.compile(pat, 0 if case else re.IGNORECASE)


def search_page(doc, page, query: str, case=False, whole=False, regex=False) -> list[dict]:
    if not query:
        return []
    rx = _pattern(query, case, whole, regex)
    hits = []
    for ln in page_lines(doc, page):
        txt = ln.text
        for m in rx.finditer(txt):
            if m.end() <= m.start():
                continue
            rect = fitz.Rect(ln.chars[m.start()].bbox)
            for c in ln.chars[m.start() + 1:m.end()]:
                rect |= fitz.Rect(c.bbox)
            hits.append({"rect": geom.r4(geom.rect_to_disp(page, rect)), "text": m.group(0), "line": ln.key,
                         "unrot": rect})
    return hits


def replace_on_page(doc, page, query: str, repl: str, case=False, whole=False, limit_line: str | None = None,
                    limit_index: int | None = None) -> int:
    """Replace matches on one page. With limit_line/limit_index only that one match is replaced."""
    rx = _pattern(query, case, whole)
    plans = []
    count = 0
    cache: dict = {}
    all_lines = page_lines(doc, page)
    for ln in all_lines:
        if ln.in_object or ln.invisible:
            continue
        if limit_line is not None and ln.key != limit_line:
            continue
        txt = ln.text
        if limit_index is not None:
            ms = [m for m in rx.finditer(txt)]
            if limit_index >= len(ms):
                continue
            m = ms[limit_index]
            new = txt[:m.start()] + repl + txt[m.end():]
            n = 1
        else:
            new, n = rx.subn(lambda _m: repl, txt)
        if n == 0 or new == txt:
            continue
        if geom.axis_dir(ln.dir) is None or needs_shaping(txt) or needs_shaping(new):
            continue
        plans.append(plan_line_edit(doc, page, ln, new, cache, all_lines))
        count += n
    apply_plans(doc, page, plans)
    return count

"""Open documents: loading, saving, undo/redo and page rendering.

Every change goes through `Session.mutate`, which snapshots the document first. That
gives exact undo/redo for *any* operation (text edits, page moves, compression...) and a
guaranteed rollback when an operation fails half-way.
"""

from __future__ import annotations

import logging
import os
import re
import shutil
import threading
import time
import uuid
from collections import OrderedDict

import pymupdf as fitz

from .. import paths

log = logging.getLogger("folio.session")

# MuPDF is not thread-safe; every engine call runs under this lock.
ENGINE = threading.RLock()

UNDO_BUDGET = 600 * 1024 * 1024
UNDO_MAX = 80
RENDER_CACHE = 48


class NeedPassword(Exception):
    pass


class BadPassword(Exception):
    pass


class NoChange(Exception):
    """Raised inside a mutate() step that turned out to change nothing (an edit that
    left the text as it was, a replace with no matches): no history step is recorded
    and the redo history survives."""

    def __init__(self, result=None):
        super().__init__("no change")
        self.result = result


class Session:
    def __init__(self, doc: fitz.Document, path: str | None, name: str, *, protect: dict | None = None,
                 notice: str | None = None):
        self.id = uuid.uuid4().hex[:10]
        self.doc = doc
        self.path = path
        self.name = name
        self.protect = protect          # {"user_pw", "owner_pw"} re-applied on save
        self.notice = notice            # one-time message for the UI
        self.undo: list[tuple[str, bytes, int]] = []
        self.redo: list[tuple[str, bytes, int]] = []
        self._counter = 0
        self.state = 0
        self.saved_state = 0 if path else -1
        self.epoch = 0
        self.page_ver: dict[int, int] = {}
        self.backed_up = False
        self.protect_dirty = False      # password added/changed/removed but not saved yet
        self._render: OrderedDict = OrderedDict()
        self._text: OrderedDict = OrderedDict()
        self.opened = time.time()

    # ------------------------------------------------------------------ state
    @property
    def dirty(self) -> bool:
        return self.state != self.saved_state or self.protect_dirty

    def ver(self, xref: int) -> str:
        return f"{self.epoch}.{self.page_ver.get(xref, 0)}"

    def info(self) -> dict:
        with ENGINE:
            doc = self.doc
            pages = []
            for i in range(doc.page_count):
                pg = doc[i]
                r = pg.rect
                pages.append({"xref": pg.xref, "w": round(r.width, 2), "h": round(r.height, 2),
                              "rot": pg.rotation, "v": self.ver(pg.xref)})
            try:
                forms = bool(doc.is_form_pdf)
            except Exception:
                forms = False
            try:
                file_size = os.path.getsize(self.path) if self.path else None
            except OSError:
                file_size = None
            return {
                "id": self.id, "name": self.name, "path": self.path, "dirty": self.dirty, "file_size": file_size,
                "pages": pages, "can_undo": bool(self.undo), "can_redo": bool(self.redo),
                "undo_label": self.undo[-1][0] if self.undo else None,
                "redo_label": self.redo[-1][0] if self.redo else None,
                "forms": forms, "protected": bool(self.protect),
                "meta": {k: v for k, v in (doc.metadata or {}).items() if k in ("title", "author", "subject", "keywords")},
            }

    # ------------------------------------------------------------------ mutation & history
    def mutate(self, label: str, fn, pages: list[int] | None = None):
        """Run fn(doc) as one undoable step. `pages` = page numbers (after the change)
        whose rendering changed; None means 'everything may have changed'."""
        with ENGINE:
            snap = self.doc.tobytes()
            try:
                result = fn(self.doc)
            except NoChange as nc:
                return nc.result
            except Exception:
                self._load(snap)
                raise
            self._push(self.undo, (label, snap, self.state))
            self.redo.clear()
            self._counter += 1
            self.state = self._counter
            self._touch(pages)
            return result

    def touch_pages(self, pages: list[int]) -> None:
        """Mark more pages as re-rendered after a step (e.g. a form field shown on several pages)."""
        with ENGINE:
            self._touch(pages)

    def replace_document(self, label: str, new_bytes: bytes) -> None:
        """Swap in a whole new version of the document (e.g. after compression), undoably."""
        with ENGINE:
            snap = self.doc.tobytes()
            self._load(new_bytes)
            self._push(self.undo, (label, snap, self.state))
            self.redo.clear()
            self._counter += 1
            self.state = self._counter
            self._touch(None)

    def _touch(self, pages):
        if pages is None:
            self.epoch += 1
        else:
            for p in pages:
                if 0 <= p < self.doc.page_count:
                    x = self.doc.page_xref(p)
                    self.page_ver[x] = self.page_ver.get(x, 0) + 1

    def _push(self, stack, entry):
        stack.append(entry)
        total = sum(len(e[1]) for e in self.undo) + sum(len(e[1]) for e in self.redo)
        while stack is self.undo and len(self.undo) > 1 and (len(self.undo) > UNDO_MAX or total > UNDO_BUDGET):
            total -= len(self.undo[0][1])
            self.undo.pop(0)

    def _load(self, data: bytes):
        old = self.doc
        self.doc = fitz.open("pdf", data)
        try:
            old.close()
        except Exception:
            pass

    def do_undo(self) -> str | None:
        with ENGINE:
            if not self.undo:
                return None
            label, snap, sid = self.undo.pop()
            self.redo.append((label, self.doc.tobytes(), self.state))
            self._load(snap)
            self.state = sid
            self.epoch += 1
            return label

    def do_redo(self) -> str | None:
        with ENGINE:
            if not self.redo:
                return None
            label, snap, sid = self.redo.pop()
            self.undo.append((label, self.doc.tobytes(), self.state))
            self._load(snap)
            self.state = sid
            self.epoch += 1
            return label

    # ------------------------------------------------------------------ rendering
    def render(self, pno: int, scale: float, hide: tuple = (), annots: bool = True) -> tuple[bytes, str]:
        from . import objects
        scale = max(0.05, min(float(scale), 8.0))
        with ENGINE:
            if not 0 <= pno < self.doc.page_count:
                raise IndexError("page out of range")
            page = self.doc[pno]
            # cap the bitmap size (~ 40 megapixels)
            area = page.rect.width * page.rect.height * scale * scale
            if area > 40e6:
                scale *= (40e6 / area) ** 0.5
            key = (page.xref, self.ver(page.xref), round(scale, 3), hide, annots)
            hit = self._render.get(key)
            if hit is not None:
                self._render.move_to_end(key)
                return hit
            mat = fitz.Matrix(scale, scale)
            if hide:
                with objects.detached(self.doc, page, only=set(hide)):
                    pix = page.get_pixmap(matrix=mat, annots=annots)
            else:
                pix = page.get_pixmap(matrix=mat, annots=annots)
            if self._photo_heavy(page):
                out = (pix.tobytes("jpeg", jpg_quality=88), "image/jpeg")
            else:
                out = (pix.tobytes("png"), "image/png")
            self._render[key] = out
            while len(self._render) > RENDER_CACHE:
                self._render.popitem(last=False)
            return out

    def _photo_heavy(self, page) -> bool:
        try:
            area = page.rect.width * page.rect.height
            cover = 0.0
            for info in page.get_image_info():
                cover += fitz.Rect(info["bbox"]).get_area()
            return area > 0 and cover / area > 0.35
        except Exception:
            return False

    def render_object(self, pno: int, oid: str, scale: float) -> bytes:
        from . import objects
        with ENGINE:
            page = self.doc[pno]
            xref, meta = objects.find_object(self.doc, page, oid)
            if xref is None:
                raise KeyError("object not found")
            clip = objects.display_rect(page, meta)
            with objects.isolated(self.doc, page, [xref]):
                pix = page.get_pixmap(matrix=fitz.Matrix(scale, scale), alpha=True, annots=False, clip=clip)
            return pix.tobytes("png")

    def text_lines(self, pno: int) -> list[dict]:
        from . import text
        with ENGINE:
            page = self.doc[pno]
            key = (page.xref, self.ver(page.xref))
            hit = self._text.get(key)
            if hit is None:
                hit = text.lines_json(self.doc, page, text.page_lines(self.doc, page))
                self._text[key] = hit
                while len(self._text) > 64:
                    self._text.popitem(last=False)
            return hit

    # ------------------------------------------------------------------ saving
    def export(self, **opts) -> bytes:
        """Final file bytes, built from a throw-away copy.

        Garbage collection renumbers objects. Done on the live document it would leave
        MuPDF's own resource caches (e.g. the embedded-font cache) and the object numbers
        Folio stores pointing at the wrong objects, so it only ever runs on a copy."""
        with ENGINE:
            raw = self.doc.tobytes()
            tmp = fitz.open("pdf", raw)
            try:
                return tmp.tobytes(garbage=3, deflate=True, **opts)
            finally:
                tmp.close()

    def save(self, path: str | None = None) -> str:
        if not (path or self.path):
            raise ValueError("no file name")
        target = os.path.abspath(path or self.path)
        with ENGINE:
            opts = {}
            if self.protect:
                opts.update(encryption=fitz.PDF_ENCRYPT_AES_256, user_pw=self.protect.get("user_pw") or "",
                            owner_pw=self.protect.get("owner_pw") or self.protect.get("user_pw") or "",
                            permissions=int(self.protect.get("permissions", fitz.PDF_PERM_ACCESSIBILITY
                                                             | fitz.PDF_PERM_PRINT | fitz.PDF_PERM_COPY
                                                             | fitz.PDF_PERM_ANNOTATE | fitz.PDF_PERM_FORM
                                                             | fitz.PDF_PERM_PRINT_HQ | fitz.PDF_PERM_MODIFY
                                                             | fitz.PDF_PERM_ASSEMBLE)))
            else:
                opts.update(encryption=fitz.PDF_ENCRYPT_NONE)
            data = self.export(**opts)
            written_state = self.state  # exactly what these bytes contain
        # First overwrite of an existing file this session: keep the original safe.
        if os.path.exists(target) and not self.backed_up:
            try:
                backup_original(target)
                self.backed_up = True
            except OSError:
                log.warning("could not back up %s before overwriting it", target)
        tmp = target + ".folio-tmp"
        try:
            with open(tmp, "wb") as f:
                f.write(data)
            os.replace(tmp, target)
        except OSError as e:
            try:
                os.remove(tmp)  # never leave a half-written temporary file next to the user's
            except OSError:
                pass
            if isinstance(e, PermissionError):
                raise PermissionError("The file is open in another program (or read-only). Close it there, "
                                      "or use Save As to pick a different name.") from e
            raise
        self.path = target
        self.name = os.path.basename(target)
        # an edit made while the file was being written is not on disk: stay dirty
        self.saved_state = written_state
        self.protect_dirty = False
        _remember(target)
        return target

    def tobytes(self) -> bytes:
        return self.export()


def backup_original(path: str) -> str:
    bdir = paths.backups_dir()
    stamp = time.strftime("%Y%m%d-%H%M%S")
    base, ext = os.path.splitext(os.path.basename(path))
    dest = os.path.join(bdir, f"{base}.{stamp}{ext or '.pdf'}")
    n = 2
    while os.path.exists(dest):
        dest = os.path.join(bdir, f"{base}.{stamp}-{n}{ext or '.pdf'}")
        n += 1
    # copyfile (not copy2): the backup's timestamp is *now*, so pruning by age keeps it
    shutil.copyfile(path, dest)
    # keep the folder bounded (newest 60 files / 1 GB) — never the backup just made
    files = sorted((os.path.join(bdir, f) for f in os.listdir(bdir)), key=os.path.getmtime, reverse=True)
    total = os.path.getsize(dest)
    kept = 1
    for f in files:
        if os.path.normcase(f) == os.path.normcase(dest):
            continue
        size = os.path.getsize(f)
        if kept >= 60 or total + size > 1024 ** 3:
            try:
                os.remove(f)
            except OSError:
                pass
            continue
        kept += 1
        total += size
    return dest


def _remember(path: str) -> None:
    """Add to the recent-files list. Losing that list entry (settings file locked by
    antivirus or OneDrive) must never fail the open or save that triggered it."""
    try:
        paths.add_recent(path)
    except Exception:
        log.warning("could not update the recent-files list", exc_info=True)


# Permission bits a PDF can withhold: print, modify, copy, annotate, fill forms,
# accessibility copy, assemble, high-quality print.
_ALL_PERMS = (1 << 2) | (1 << 3) | (1 << 4) | (1 << 5) | (1 << 8) | (1 << 9) | (1 << 10) | (1 << 11)


def _restricted(doc) -> bool:
    try:
        kind, enc = doc.xref_get_key(-1, "Encrypt")
        if kind == "xref":
            enc = doc.xref_object(int(enc.split()[0]), compressed=True)
        m = re.search(r"/P\s*(-?\d+)", enc or "")
        return bool(m) and (int(m.group(1)) & _ALL_PERMS) != _ALL_PERMS
    except Exception:
        return False


def open_bytes(data: bytes, name: str, path: str | None = None, password: str | None = None) -> Session:
    with ENGINE:
        try:
            doc = fitz.open("pdf", data)
        except Exception as e:
            raise ValueError(f"This file could not be opened as a PDF ({e}).")
        protect = None
        notice = None
        # MuPDF quietly opens a file whose open password is empty and then reports it as
        # not encrypted, so the encryption dictionary is what tells.
        encrypted = doc.needs_pass or doc.xref_get_key(-1, "Encrypt")[0] != "null"
        restricted = encrypted and _restricted(doc)
        if doc.needs_pass:
            if not password:
                raise NeedPassword(name)
            rc = doc.authenticate(password)
            if not rc:
                raise BadPassword(name)
            protect = {"user_pw": password, "owner_pw": password}
            doc = fitz.open("pdf", doc.tobytes(encryption=fitz.PDF_ENCRYPT_NONE))
            if rc & 2:
                notice = "Password accepted. Folio will keep this password when you save (change it under Protect)."
                if restricted:
                    notice += " The file’s editing restrictions are lifted in what you save."
            else:
                # The owner password can't reproduce a different open password, so saving
                # changes how the file opens. Say so instead of doing it silently.
                notice = ("You opened this file with its owner password. When you save, that password will also open "
                          "the file; the separate open password can’t be kept. Change it under Protect.")
        elif encrypted:
            doc = fitz.open("pdf", doc.tobytes(encryption=fitz.PDF_ENCRYPT_NONE))
            if restricted:
                notice = "This PDF had editing restrictions. They are removed when you save from Folio."
        if doc.page_count == 0:
            raise ValueError("This PDF has no pages.")
        return Session(doc, path, name, protect=protect, notice=notice)


def open_path(path: str, password: str | None = None) -> Session:
    path = os.path.abspath(path)
    with open(path, "rb") as f:
        data = f.read()
    s = open_bytes(data, os.path.basename(path), path, password)
    s.saved_state = s.state
    _remember(path)
    return s


def new_session(doc: fitz.Document, name: str) -> Session:
    s = Session(doc, None, name)
    s.saved_state = -1
    return s

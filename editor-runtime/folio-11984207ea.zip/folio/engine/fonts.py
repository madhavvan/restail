"""Installed fonts: discovery, PDF-name matching, subsetting for embedding.

A PDF names its fonts the PostScript way ("ABCDEF+Calibri-Bold", "Arial,BoldItalic",
"TimesNewRomanPS-BoldMT") and usually embeds only the glyphs it used. To re-set edited
text in the *same* typeface we index every font on the machine (Windows, per-user and
Office cloud fonts) under the names a PDF could call it, then embed a tiny subset of the
real font file containing just the characters we write.
"""

from __future__ import annotations

import io
import json
import logging
import os
import re
import threading
from collections import OrderedDict
from dataclasses import asdict, dataclass

from fontTools import subset as ft_subset
from fontTools.ttLib import TTCollection, TTFont

from ..paths import cache_dir

log = logging.getLogger("folio.fonts")
logging.getLogger("fontTools").setLevel(logging.ERROR)

INDEX_VERSION = 4
FONT_EXTS = (".ttf", ".otf", ".ttc", ".otc")
SUBSET_PREFIX = re.compile(r"^[A-Z]{6}\+")

# Longer words first so "semibold" wins over "bold", "extralight" over "light".
WEIGHT_WORDS = [
    ("extralight", 200), ("ultralight", 200), ("semilight", 350), ("hairline", 100),
    ("extrabold", 800), ("ultrabold", 800), ("semibold", 600), ("demibold", 600),
    ("thin", 100), ("light", 300), ("book", 400), ("regular", 400), ("normal", 400),
    ("roman", 400), ("medium", 500), ("demi", 600), ("heavy", 900), ("black", 900),
    ("bold", 700),
]

# PDF font families that are commonly substituted by a metric-compatible installed one.
ALIASES = {
    "helvetica": ["arial", "liberationsans", "arimo"],
    "helveticaneue": ["neuehaasgrotesktextpro", "arial"],
    "helveticaneuelt": ["neuehaasgrotesktextpro", "arial"],
    "times": ["timesnewroman", "liberationserif", "tinos"],
    "timesroman": ["timesnewroman"],
    "courier": ["couriernew", "liberationmono", "cousine"],
    "calibri": ["carlito", "arial"],
    "cambria": ["caladea", "timesnewroman"],
    "liberationsans": ["arial"], "arimo": ["arial"], "nimbussans": ["arial"], "nimbussansl": ["arial"],
    "liberationserif": ["timesnewroman"], "tinos": ["timesnewroman"], "nimbusroman": ["timesnewroman"],
    "nimbusromanno9l": ["timesnewroman"],
    "liberationmono": ["couriernew"], "cousine": ["couriernew"], "nimbusmono": ["couriernew"],
    "nimbusmonol": ["couriernew"], "nimbusmonops": ["couriernew"],
    "dejavusans": ["verdana"], "dejavuserif": ["georgia"], "dejavusansmono": ["consolas"],
    "palatino": ["palatinolinotype", "bookantiqua"], "bookantiqua": ["palatinolinotype"],
    "palatinolinotype": ["bookantiqua"],
    "futura": ["centurygothic"], "gillsans": ["gillsansmt", "gillsansnova"],
    "lucidagrande": ["segoeui"], "sfnstext": ["segoeui"], "sfprotext": ["segoeui"],
    "sfprodisplay": ["segoeui"], "sfui": ["segoeui"], "sfuitext": ["segoeui"], "systemui": ["segoeui"],
    "roboto": ["segoeui"], "opensans": ["segoeui"], "lato": ["calibri"], "inter": ["segoeui"],
    "sourcesanspro": ["segoeui"], "sourcesans3": ["segoeui"], "notosans": ["segoeui"],
    "georgia": ["georgiapro"], "verdana": ["tahoma"],
    "symbolmt": ["symbol"],
}

STYLE_ABBREV = {"bd": 700, "bld": 700, "bol": 700, "blk": 900, "hv": 900, "hvy": 900, "md": 500, "med": 500,
                "lt": 300, "lgt": 300, "xlt": 200, "ult": 200, "sb": 600, "smbd": 600, "sbd": 600, "smb": 600,
                "xbd": 800, "ebd": 800, "rg": 400, "reg": 400, "rom": 400}

# Suffixes foundries glue onto family names ("HelveticaNeueLTStd", "MinionPro", "ArialMT").
FAMILY_SUFFIXES = ("ltstd", "ltpro", "std", "pro", "lt", "mt", "ps", "com", "ot", "w1g", "offc", "osf", "lf")

# TeX font names (Computer Modern, Latin Modern, EC, and the 'p*' PostScript aliases):
# closest installed Windows faces, most specific prefixes first.
TEX_ROLES = (
    (("ptm",), ["timesnewroman"]),
    (("phv",), ["arial"]),
    (("pcr",), ["couriernew"]),
    (("ppl",), ["palatinolinotype", "bookantiqua"]),
    (("pnc",), ["centuryschoolbook"]),
    (("cmtt", "lmmono", "sftt", "ectt", "cmuntt"), ["couriernew", "consolas"]),
    (("cmss", "lmsans", "sfss", "ecss", "cmunss"), ["arial", "segoeui"]),
    (("cmr", "cmbx", "cmti", "cmsl", "cmb", "cmunrm", "cmunbx", "cmunti", "lmroman", "sfrm", "sfbx", "sfti", "sfsl",
      "ecrm", "ecbx", "ecti"), ["centuryschoolbook", "cambria", "timesnewroman"]),
)


def tex_family(nb: str) -> tuple[list[str], int | None, bool] | None:
    """('cmbx10' ...) -> (candidate families, weight or None, italic) for TeX fonts."""
    m = re.match(r"([a-z]+)(\d*)(.*)$", nb)
    if not m:
        return None
    head = m.group(1)
    for prefixes, fams in TEX_ROLES:
        for pre in prefixes:
            if head.startswith(pre) and (len(head) - len(pre) <= 6):
                bold = "bx" in head or "bold" in nb or head.startswith("cmb")
                italic = any(x in head for x in ("ti", "sl", "it")) or "italic" in nb or "oblique" in nb
                return fams, (700 if bold else None), italic
    return None

GENERIC = {
    "mono": ["consolas", "couriernew", "lucidaconsole"],
    "serif": ["timesnewroman", "cambria", "georgia"],
    "sans": ["arial", "segoeui", "calibri", "verdana"],
}

# Faces tried, in order, for characters the chosen face does not have.
COVERAGE_FALLBACK = [
    "segoeui", "arial", "segoeuisymbol", "cambriamath", "microsoftyahei", "malgungothic",
    "yugothic", "nirmalaui", "ebrima", "gadugi", "leelawadeeui", "segoeuihistoric",
    "myanmartext", "javanesetext", "mongolianbaiti", "microsoftyibaiti", "simsunextb",
]

SERIF_HINTS = ("serif", "roman", "times", "georgia", "garamond", "cambria", "antiqua", "palatino", "bodoni",
               "baskerville", "caslon", "century", "bookman", "constantia", "rockwell", "sylfaen",
               "minion", "merriweather", "playfair", "bembo", "sabon", "dante", "mincho", "batang")


# Scripts whose letters change shape or order when set: right-to-left (Hebrew, Arabic,
# Syriac, Thaana, N'Ko) and those that join or reorder letters (the Indic scripts, Thai,
# Lao, Tibetan, Myanmar, Khmer). Setting them needs a shaping engine.
_COMPLEX = re.compile("[\u0590-\u08ff\u0900-\u0dff\u0e00-\u0eff\u0f00-\u0fff\u1000-\u109f"
                      "\u1780-\u17ff\ufb1d-\ufdff\ufe70-\ufeff]")


def needs_shaping(s: str | None) -> bool:
    return bool(_COMPLEX.search(s or ""))


def norm(s: str | None) -> str:
    return re.sub(r"[^a-z0-9]", "", (s or "").lower())


def strip_subset(name: str | None) -> str:
    return SUBSET_PREFIX.sub("", (name or "").strip())


def font_dirs() -> list[str]:
    out = [os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "Fonts")]
    local = os.environ.get("LOCALAPPDATA")
    if local:
        out.append(os.path.join(local, "Microsoft", "Windows", "Fonts"))
        out.append(os.path.join(local, "Microsoft", "FontCache", "4", "CloudFonts"))
    return [d for d in out if os.path.isdir(d)]


@dataclass
class Face:
    path: str
    index: int
    family: str     # typographic family (name 16, else 1)
    legacy: str     # GDI/RIBBI family (name 1) — what CSS font-family resolves on Windows
    lstyle: str     # RIBBI subfamily (name 2): Regular / Bold / Italic / Bold Italic
    style: str      # typographic subfamily (name 17, else 2)
    full: str
    ps: str
    weight: int
    italic: bool
    width: int      # usWidthClass, 5 = normal
    serif: bool
    mono: bool
    symbol: bool
    variable: bool
    system: bool    # registered with Windows (CSS can use it by name)

    @property
    def key(self) -> str:
        return f"{self.path}#{self.index}"

    @property
    def bold(self) -> bool:
        return self.weight >= 600

    def css(self) -> dict:
        lst = self.lstyle.lower()
        return {
            "family": self.legacy,
            "weight": 700 if "bold" in lst else 400,
            "style": "italic" if ("italic" in lst or "oblique" in lst) else "normal",
            "system": self.system,
            "key": self.key,
        }

    def label(self) -> str:
        return self.full or f"{self.family} {self.style}".strip()


def parse_pdf_name(name: str) -> tuple[str, int, bool, bool]:
    """'TimesNewRomanPS-BoldItalicMT' -> ('TimesNewRoman', 700, True, False)."""
    base = strip_subset(name).replace(" ", "")
    parts = re.split(r"[,-]", base, maxsplit=1)
    fam = parts[0]
    style = parts[1] if len(parts) > 1 else ""
    fam = re.sub(r"(PSMT|MT|PS)$", "", fam)
    style = re.sub(r"(PSMT|MT|PS)$", "", style)
    s = norm(style)
    weight = 400
    for word, w in WEIGHT_WORDS:
        if word in s:
            weight = w
            break
    italic = "italic" in s or "oblique" in s or s.endswith("it") or s == "it" or "slanted" in s
    condensed = any(w in s for w in ("cond", "narrow", "compressed"))
    if style and weight == 400:
        # foundry abbreviations: "Bd", "BdIt", "Md", "Lt", "Blk", "SmBd", "Hv"...
        for tok in re.findall(r"[A-Z][a-z]*|[a-z]+", style):
            t = tok.lower()
            if t in STYLE_ABBREV:
                weight = STYLE_ABBREV[t]
                break
    if style and not italic and any(t.lower() in ("it", "ita", "obl", "ital") for t in re.findall(r"[A-Z][a-z]*|[a-z]+", style)):
        italic = True
    if not style:
        # Style glued onto the family ("ArialBold", "CalibriLight") — peel known words off.
        nf = norm(fam)
        for word, w in WEIGHT_WORDS + [("italic", -1), ("oblique", -1)]:
            if nf.endswith(word) and len(nf) > len(word) + 2:
                if w == -1:
                    italic = True
                else:
                    weight = w
                fam = fam[: len(fam) - len(word)]
                nf = norm(fam)
    return fam, weight, italic, condensed


class FontIndex:
    _instance: "FontIndex | None" = None
    _lock = threading.Lock()

    def __init__(self):
        self.faces: list[Face] = []
        self.by_ps: dict[str, Face] = {}
        self.by_full: dict[str, Face] = {}
        self.by_family: dict[str, list[Face]] = {}
        self.by_legacy: dict[str, list[Face]] = {}
        self.by_key: dict[str, Face] = {}
        self._cmaps: dict[str, frozenset] = {}
        self._subsets: OrderedDict = OrderedDict()
        self._ready = threading.Event()
        self._io = threading.Lock()

    # ---------- loading ----------
    @classmethod
    def get(cls, wait: bool = True) -> "FontIndex":
        with cls._lock:
            if cls._instance is None:
                cls._instance = FontIndex()
                threading.Thread(target=cls._instance._load, name="font-index", daemon=True).start()
        if wait:
            cls._instance._ready.wait(120)
        return cls._instance

    def _load(self):
        try:
            self._build()
        except Exception:  # pragma: no cover - must never take the app down
            log.exception("font index failed")
        finally:
            self._ready.set()

    def _build(self):
        cache_file = os.path.join(cache_dir(), "fontindex.json")
        try:
            with open(cache_file, "r", encoding="utf-8") as f:
                cached = json.load(f)
            if cached.get("version") != INDEX_VERSION:
                cached = {}
        except (OSError, ValueError):
            cached = {}
        old_files = cached.get("files", {})
        new_files = {}
        changed = False
        sysdir = os.path.normcase(font_dirs()[0]) if font_dirs() else ""
        for d in font_dirs():
            for root, _dirs, files in os.walk(d):
                for fn in files:
                    if not fn.lower().endswith(FONT_EXTS):
                        continue
                    path = os.path.join(root, fn)
                    try:
                        st = os.stat(path)
                    except OSError:
                        continue
                    sig = [int(st.st_mtime), st.st_size]
                    prev = old_files.get(path)
                    if prev and prev.get("sig") == sig:
                        new_files[path] = prev
                        continue
                    changed = True
                    is_sys = os.path.normcase(root).startswith(sysdir) or "\\microsoft\\windows\\fonts" in os.path.normcase(root)
                    new_files[path] = {"sig": sig, "faces": [asdict(f) for f in _read_faces(path, is_sys)]}
        if changed or len(new_files) != len(old_files):
            try:
                tmp = cache_file + ".tmp"
                with open(tmp, "w", encoding="utf-8") as f:
                    json.dump({"version": INDEX_VERSION, "files": new_files}, f)
                os.replace(tmp, cache_file)
            except OSError:
                log.warning("could not write font index cache")
        for entry in new_files.values():
            for fd in entry["faces"]:
                self._add(Face(**fd))
        log.info("font index: %d faces", len(self.faces))

    def _add(self, f: Face):
        self.faces.append(f)
        self.by_key[f.key] = f
        for k in (norm(f.ps),):
            if k and (k not in self.by_ps or (f.system and not self.by_ps[k].system)):
                self.by_ps[k] = f
        k = norm(f.full)
        if k and (k not in self.by_full or (f.system and not self.by_full[k].system)):
            self.by_full[k] = f
        for k in {norm(f.family), norm(f.legacy)}:
            if k:
                self.by_family.setdefault(k, []).append(f)
        self.by_legacy.setdefault(norm(f.legacy), []).append(f)

    # ---------- queries ----------
    def families(self) -> list[dict]:
        """RIBBI families for a font picker: [{family, bold, italic, system}]."""
        out = {}
        for f in self.faces:
            if f.symbol or not f.legacy:
                continue
            e = out.setdefault(f.legacy, {"family": f.legacy, "styles": set(), "system": False})
            e["styles"].add(f.lstyle.lower())
            e["system"] = e["system"] or f.system
        res = []
        for e in out.values():
            st = e["styles"]
            reg = self.face_for_family(e["family"])
            res.append({"family": e["family"], "bold": any("bold" in s for s in st),
                        "italic": any("italic" in s or "oblique" in s for s in st), "system": e["system"],
                        "key": reg.key if reg else None})
        res.sort(key=lambda e: e["family"].lower())
        return res

    def face_for_family(self, family: str, bold: bool = False, italic: bool = False) -> Face | None:
        faces = self.by_legacy.get(norm(family)) or self.by_family.get(norm(family))
        if not faces:
            return None
        return _pick(faces, 700 if bold else 400, italic, False)

    def generic(self, serif: bool = False, mono: bool = False, bold: bool = False, italic: bool = False) -> Face | None:
        kind = "mono" if mono else ("serif" if serif else "sans")
        for fam in GENERIC[kind]:
            faces = self.by_family.get(fam)
            if faces:
                return _pick(faces, 700 if bold else 400, italic, False)
        return None

    def match(self, pdf_name: str, bold_flag: bool = False, italic_flag: bool = False,
              serif_flag: bool = False, mono_flag: bool = False) -> tuple[Face | None, str]:
        """Find the installed face for a PDF font name.

        Returns (face, quality) where quality is 'exact' (same typeface and style),
        'family' (same typeface, nearest style), 'similar' (metric-compatible alias) or
        'fallback' (generic serif/sans/mono)."""
        base = strip_subset(pdf_name)
        nb = norm(base)
        fam, weight, italic, cond = parse_pdf_name(pdf_name)
        if bold_flag and weight < 600:
            weight = 700
        italic = italic or italic_flag
        if nb:
            for k in (nb, re.sub(r"(psmt|mt|ps)$", "", nb)):
                f = self.by_ps.get(k) or self.by_full.get(k)
                if f and not f.symbol:
                    if (f.weight >= 600) == (weight >= 600) and f.italic == italic:
                        return f, "exact"
        nf = norm(fam)
        # try the family as written, then with foundry suffixes peeled off one at a time
        # ("HelveticaNeueLTStd" -> "HelveticaNeueLT" -> "HelveticaNeue")
        tried = []
        cand = nf
        while cand and cand not in tried:
            tried.append(cand)
            for suf in FAMILY_SUFFIXES:
                if cand.endswith(suf) and len(cand) > len(suf) + 2:
                    cand = cand[: -len(suf)]
                    break
        for k in tried:
            faces = self.by_family.get(k)
            if faces:
                f = _pick(faces, weight, italic, cond)
                ok = abs(f.weight - weight) <= 50 and f.italic == italic
                return f, ("exact" if ok else "family")
        for k in tried:
            for alias in ALIASES.get(k, []):
                faces = self.by_family.get(alias)
                if faces:
                    return _pick(faces, weight, italic, cond), "similar"
        tex = tex_family(nb)
        if tex:
            fams, tw, ti = tex
            for fam_key in fams:
                faces = self.by_family.get(fam_key)
                if faces:
                    return _pick(faces, tw or weight, ti or italic, cond), "similar"
        serif = serif_flag or any(h in nb for h in SERIF_HINTS)
        mono = mono_flag or any(h in nb for h in ("mono", "courier", "consol", "code"))
        f = self.generic(serif=serif, mono=mono, bold=weight >= 600, italic=italic)
        return f, "fallback"

    def cmap(self, face: Face) -> frozenset:
        cm = self._cmaps.get(face.key)
        if cm is None:
            try:
                with self._io:
                    tt = TTFont(face.path, fontNumber=face.index, lazy=True)
                    cm = frozenset((tt["cmap"].getBestCmap() or {}).keys())
                    tt.close()
            except Exception:
                cm = frozenset()
            self._cmaps[face.key] = cm
        return cm

    def vmetrics(self, face: Face) -> tuple[float, float] | None:
        """(ascent, descent) in em the way Windows/DirectWrite lays out a line box —
        so text drawn in the PDF lands exactly where the on-screen editor showed it."""
        key = ("vm", face.key)
        hit = self._cmaps.get(key)
        if hit is None:
            try:
                with self._io:
                    tt = TTFont(face.path, fontNumber=face.index, lazy=True)
                    upm = tt["head"].unitsPerEm
                    os2 = tt["OS/2"] if "OS/2" in tt else None
                    if os2 is not None and getattr(os2, "fsSelection", 0) & (1 << 7):
                        asc, desc = os2.sTypoAscender, -os2.sTypoDescender
                    elif os2 is not None and getattr(os2, "usWinAscent", 0):
                        asc, desc = os2.usWinAscent, os2.usWinDescent
                    else:
                        asc, desc = tt["hhea"].ascent, -tt["hhea"].descent
                    tt.close()
                hit = (asc / upm, -abs(desc) / upm)
            except Exception:
                hit = ()
            self._cmaps[key] = hit
        return hit or None

    def covers(self, face: Face, text: str) -> bool:
        cm = self.cmap(face)
        return all(ord(c) in cm or c in "\r\n\t" for c in text)

    def split_by_coverage(self, face: Face, text: str) -> list[tuple[str, Face]]:
        """Split text into runs, falling back to other faces for missing characters."""
        runs: list[tuple[str, Face]] = []
        cm = self.cmap(face)
        for ch in text:
            use = face
            if ord(ch) not in cm and not ch.isspace():
                use = self._fallback_for(ch, face) or face
            if runs and runs[-1][1] is use:
                runs[-1] = (runs[-1][0] + ch, use)
            else:
                runs.append((ch, use))
        return runs

    def _fallback_for(self, ch: str, like: Face) -> Face | None:
        for fam in COVERAGE_FALLBACK:
            faces = self.by_family.get(fam)
            if not faces:
                continue
            f = _pick(faces, like.weight, like.italic, False)
            if ord(ch) in self.cmap(f):
                return f
        return None

    def subset(self, face: Face, chars: str) -> bytes:
        """A standalone font file containing only `chars` (plus space and .notdef)."""
        uni = sorted({ord(c) for c in chars if c not in "\r\n"} | {32})
        key = (face.key, tuple(uni))
        hit = self._subsets.get(key)
        if hit is not None:
            self._subsets.move_to_end(key)
            return hit
        opts = ft_subset.Options()
        opts.name_IDs = ["*"]
        opts.name_languages = ["*"]
        opts.name_legacy = True
        opts.notdef_outline = True
        opts.notdef_glyph = True
        opts.layout_features = []
        opts.hinting = False
        opts.glyph_names = False
        opts.ignore_missing_glyphs = True
        opts.ignore_missing_unicodes = True
        opts.prune_unicode_ranges = True
        opts.recalc_bounds = True
        opts.drop_tables += ["DSIG", "GSUB", "GPOS", "GDEF", "BASE", "JSTF", "MATH", "COLR", "CPAL",
                             "SVG ", "sbix", "CBDT", "CBLC", "EBDT", "EBLC", "EBSC", "STAT", "meta", "MERG"]
        with self._io:
            # lazy loading parses only the glyphs we keep: ~10x faster on big fonts
            tt = TTFont(face.path, fontNumber=face.index, lazy=True)
            try:
                if "fvar" in tt:
                    tt.close()
                    tt = _default_instance(TTFont(face.path, fontNumber=face.index, lazy=False))
                sub = ft_subset.Subsetter(opts)
                sub.populate(unicodes=uni)
                sub.subset(tt)
                buf = io.BytesIO()
                tt.save(buf)
                data = buf.getvalue()
            finally:
                tt.close()
        self._subsets[key] = data
        while len(self._subsets) > 64:
            self._subsets.popitem(last=False)
        return data


    def shaping_subset(self, face: Face, chars: str) -> bytes:
        """Like subset(), but keeps the OpenType layout tables, and every glyph their
        substitutions can reach, so a shaping engine can join and reorder letters."""
        uni = sorted({ord(c) for c in chars if c not in "\r\n"} | {32})
        key = ("shape", face.key, tuple(uni))
        hit = self._subsets.get(key)
        if hit is not None:
            self._subsets.move_to_end(key)
            return hit
        opts = ft_subset.Options()
        opts.name_IDs = ["*"]
        opts.name_languages = ["*"]
        opts.name_legacy = True
        opts.notdef_outline = True
        opts.notdef_glyph = True
        opts.layout_features = ["*"]
        opts.hinting = False
        opts.ignore_missing_glyphs = True
        opts.ignore_missing_unicodes = True
        opts.drop_tables += ["DSIG", "SVG ", "sbix", "CBDT", "CBLC", "EBDT", "EBLC", "EBSC", "COLR", "CPAL", "MERG"]
        with self._io:
            tt = TTFont(face.path, fontNumber=face.index, lazy=False)
            try:
                if "fvar" in tt:
                    tt = _default_instance(tt)
                sub = ft_subset.Subsetter(opts)
                sub.populate(unicodes=uni)
                sub.subset(tt)
                buf = io.BytesIO()
                tt.save(buf)
                data = buf.getvalue()
            finally:
                tt.close()
        self._subsets[key] = data
        while len(self._subsets) > 64:
            self._subsets.popitem(last=False)
        return data


def _default_instance(tt: TTFont) -> TTFont:
    try:
        from fontTools.varLib import instancer
        axes = {a.axisTag: a.defaultValue for a in tt["fvar"].axes}
        return instancer.instantiateVariableFont(tt, axes)
    except Exception:
        return tt


def _pick(faces: list[Face], weight: int, italic: bool, condensed: bool) -> Face:
    def score(f: Face):
        s = abs(f.weight - weight)
        s += 0 if f.italic == italic else 1000
        s += 0 if ((f.width < 5) == condensed) else 300
        s += 150 if f.variable else 0
        s += 0 if f.system else 5
        s += 0 if not f.symbol else 5000
        return s
    return min(faces, key=score)


def _name(tt: TTFont, *ids: int) -> str:
    table = tt["name"] if "name" in tt else None
    if table is None:
        return ""
    for i in ids:
        try:
            v = table.getDebugName(i)
        except Exception:
            v = None
        if v:
            return v.strip()
    return ""


def _read_faces(path: str, is_system: bool) -> list[Face]:
    out = []
    try:
        if path.lower().endswith((".ttc", ".otc")):
            coll = TTCollection(path, lazy=True)
            fonts = list(coll.fonts)
        else:
            fonts = [TTFont(path, lazy=True)]
    except Exception:
        return out
    for idx, tt in enumerate(fonts):
        try:
            family = _name(tt, 16, 1)
            legacy = _name(tt, 1)
            lstyle = _name(tt, 2) or "Regular"
            style = _name(tt, 17, 2) or "Regular"
            full = _name(tt, 4)
            ps = _name(tt, 6)
            weight, width, italic, serif, mono = 400, 5, False, None, False
            if "OS/2" in tt:
                os2 = tt["OS/2"]
                weight = int(getattr(os2, "usWeightClass", 400) or 400)
                if weight < 100:      # some old fonts store 1..9
                    weight *= 100
                width = int(getattr(os2, "usWidthClass", 5) or 5)
                italic = bool(getattr(os2, "fsSelection", 0) & 1)
                pan = getattr(os2, "panose", None)
                if pan is not None and getattr(pan, "bFamilyType", 0) == 2:
                    ss = getattr(pan, "bSerifStyle", 0)
                    if 2 <= ss <= 10:
                        serif = True
                    elif ss >= 11:
                        serif = False
                    mono = getattr(pan, "bProportion", 0) == 9
            if "post" in tt:
                mono = mono or bool(getattr(tt["post"], "isFixedPitch", 0))
                if abs(getattr(tt["post"], "italicAngle", 0) or 0) > 1:
                    italic = True
            st = (style + " " + lstyle).lower()
            italic = italic or "italic" in st or "oblique" in st
            if serif is None:
                serif = any(h in norm(family) for h in SERIF_HINTS)
            symbol = True
            if "cmap" in tt:
                for t in tt["cmap"].tables:
                    if (t.platformID == 3 and t.platEncID in (1, 10)) or t.platformID == 0:
                        symbol = False
                        break
            out.append(Face(path=path, index=idx, family=family or legacy, legacy=legacy or family,
                            lstyle=lstyle, style=style, full=full, ps=ps, weight=weight, italic=italic,
                            width=width, serif=bool(serif), mono=bool(mono), symbol=symbol,
                            variable="fvar" in tt, system=is_system))
        except Exception:
            continue
        finally:
            try:
                tt.close()
            except Exception:
                pass
    return out

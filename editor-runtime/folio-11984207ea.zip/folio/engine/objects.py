"""Things the user adds: text boxes, images, signatures, shapes, ink, check marks, whiteout.

Each added thing is drawn into its *own* content stream, and that stream's dictionary
carries a /FolioObj entry with JSON describing it. To every PDF viewer it is ordinary
page content (so it looks identical everywhere and survives flattening/uploading), but
Folio can find it again to move, restyle or delete it — even after save and reopen.

Geometry: an object lives in its own upright frame. `o` is the unrotated-page point of
the frame's top-left corner, `rot` is the page rotation it was created under (so it was
upright on screen), and `w`/`h` is its size. Local point p maps to the page as
    o + p * R(rot)
"""

from __future__ import annotations

import html
import json
import math
import re
import uuid
from contextlib import contextmanager

import pymupdf as fitz

from . import geom
from .fonts import Face, FontIndex, needs_shaping

OBJ_KEY = "FolioObj"

TEXT_DEFAULTS = {"size": 12.0, "color": "#000000", "align": "left", "lh": 1.2, "opacity": 1.0,
                 "font": {"family": "Arial", "bold": False, "italic": False}}


# ---------------------------------------------------------------- content plumbing
def set_contents(doc: fitz.Document, page: fitz.Page, xrefs: list[int]) -> None:
    doc.xref_set_key(page.xref, "Contents", "[" + " ".join(f"{x} 0 R" for x in xrefs) + "]")


def meta_of(doc: fitz.Document, xref: int) -> dict | None:
    try:
        kind, val = doc.xref_get_key(xref, OBJ_KEY)
    except Exception:
        return None
    if kind != "string":
        return None
    try:
        m = json.loads(val)
    except ValueError:
        return None
    return m if isinstance(m, dict) and "type" in m else None


def object_streams(doc: fitz.Document, page: fitz.Page) -> list[tuple[int, dict]]:
    out = []
    for x in page.get_contents():
        m = meta_of(doc, x)
        if m is not None:
            out.append((x, m))
    return out


@contextmanager
def detached(doc: fitz.Document, page: fitz.Page, only: set | None = None):
    """Temporarily take Folio object streams out of the page (all, or the ids in `only`).

    If nothing else changed meanwhile (e.g. rendering with an object hidden) the page's
    stream order is restored exactly, so stacking never changes as a side effect. If the
    rest of the content was rewritten (redaction merges it into one stream), the objects
    go back on top in their original relative order."""
    cont = page.get_contents()
    objs = []
    for x in cont:
        m = meta_of(doc, x)
        if m is not None and (only is None or m.get("id") in only):
            objs.append(x)
    if not objs:
        yield []
        return
    remaining = [x for x in cont if x not in objs]
    set_contents(doc, page, remaining)
    try:
        yield objs
    finally:
        cur = page.get_contents()
        if cur == remaining:
            set_contents(doc, page, cont)
        else:
            set_contents(doc, page, cur + [x for x in objs if x not in cur])


@contextmanager
def _unrotated(page: fitz.Page):
    """PyMuPDF's Shape and insert_image misplace drawings on rotated pages whose CropBox
    is offset from the MediaBox. Our coordinates are unrotated anyway, so draw with the
    rotation switched off for a moment."""
    rot = page.rotation
    if rot:
        page.set_rotation(0)
    try:
        yield
    finally:
        if rot:
            page.set_rotation(rot)


_DO_RX = re.compile(rb"/([A-Za-z0-9_.+\-]+)\s+Do\b")


def image_xref_of(doc, page, stream_xref: int) -> int | None:
    """The image XObject an image object draws, found through the page's resource name
    (object numbers change whenever a file is saved compactly, names don't)."""
    m = _DO_RX.search(doc.xref_stream(stream_xref) or b"")
    if not m:
        return None
    kind, val = doc.xref_get_key(page.xref, f"Resources/XObject/{m.group(1).decode('latin-1')}")
    if kind == "xref":
        try:
            return int(val.split()[0])
        except (ValueError, IndexError):
            return None
    return None


def lift_all(doc) -> list:
    """Take every Folio object out of every page (keeping what they need) — for whole-file
    rewrites such as image recompression that would otherwise merge them into the page."""
    state = []
    for pno in range(doc.page_count):
        page = doc[pno]
        cont = page.get_contents()
        objs = [x for x in cont if meta_of(doc, x) is not None]
        if not objs:
            continue
        saved = _resources_used_by(doc, page, objs)
        set_contents(doc, page, [x for x in cont if x not in objs])
        state.append((page.xref, objs, saved))
    return state


def restore_all(doc, state: list) -> None:
    by_xref = {doc.page_xref(i): i for i in range(doc.page_count)}
    for page_xref, objs, saved in state:
        pno = by_xref.get(page_xref)
        if pno is None:
            continue
        page = doc[pno]
        cur = page.get_contents()
        set_contents(doc, page, cur + [x for x in objs if x not in cur])
        for cat, n, val in saved:
            kind, _cur = doc.xref_get_key(page.xref, f"Resources/{cat}/{n}")
            if kind == "null":
                set_resource(doc, page, cat, n, val)


def content_text(page: fitz.Page, flags: int, clip=None) -> dict:
    """rawdict of the page's *own* content, in unrotated coordinates. PyMuPDF's
    get_text also reads the appearance of comments and form fields, which aren't page
    text: offering a field's value as an editable line (or replacing it) would write a
    second copy into the page underneath the field."""
    mu = fitz.mupdf
    rot = page.rotation
    if rot:
        page.set_rotation(0)
    try:
        pg = page.this
        if isinstance(pg, mu.PdfPage):
            pg = pg.super()
        rect = mu.fz_bound_page(pg) if clip is None else mu.FzRect(*fitz.Rect(clip))
        st = mu.FzStextPage(rect)
        dev = mu.fz_new_stext_device(st, mu.FzStextOptions(flags))
        try:
            mu.fz_run_page_contents(pg, dev, mu.FzMatrix(), mu.FzCookie())
        finally:
            mu.fz_close_device(dev)
    except Exception:
        if rot:
            page.set_rotation(rot)
            rot = 0
        return page.get_text("rawdict", flags=flags, clip=clip)
    finally:
        if rot:
            page.set_rotation(rot)
    return fitz.TextPage(st).extractRAWDICT()


@contextmanager
def isolated(doc: fitz.Document, page: fitz.Page, xrefs: list[int]):
    """Temporarily make the page consist of only the given streams (for rendering one object)."""
    cont = page.get_contents()
    set_contents(doc, page, list(xrefs))
    try:
        yield
    finally:
        set_contents(doc, page, cont)


def ensure_wrapped(doc: fitz.Document, page: fitz.Page) -> None:
    """Make sure page content leaves the graphics state as it found it, so content we
    append starts from the default coordinate system."""
    own_resources(doc, page)
    with detached(doc, page):
        if page.get_contents() and not page.is_wrapped:
            page.wrap_contents()


# ---------------------------------------------------------------- page resources
_RES_ENTRY = re.compile(r"/([^\s/<>\[\]()%]+)\s*(\d+)\s+0\s+R")


def own_resources(doc: fitz.Document, page: fitz.Page) -> None:
    """Give the page its own /Resources when it only inherits them from the page tree.
    MuPDF's writers (TextWriter, Shape, insert_image) otherwise put a fresh dictionary on
    the page holding only what they add — and the page's own text loses its fonts."""
    if doc.xref_get_key(page.xref, "Resources")[0] != "null":
        return
    x, seen = page.xref, set()
    while x not in seen:
        seen.add(x)
        kind, val = doc.xref_get_key(x, "Parent")
        if kind != "xref":
            break
        x = int(val.split()[0])
        kind, val = doc.xref_get_key(x, "Resources")
        if kind == "xref":
            doc.xref_set_key(page.xref, "Resources", doc.xref_object(int(val.split()[0]), compressed=True))
            return
        if kind == "dict":
            doc.xref_set_key(page.xref, "Resources", val)
            return
    doc.xref_set_key(page.xref, "Resources", "<<>>")


def _res_slot(doc, page, cat: str) -> tuple[int, str]:
    """(object, key prefix) addressing /Resources/<cat> without crossing an indirect
    reference — PyMuPDF refuses to set a key through a path that does."""
    own_resources(doc, page)
    kind, val = doc.xref_get_key(page.xref, "Resources")
    if kind == "xref":
        holder, pre = int(val.split()[0]), ""
    else:
        holder, pre = page.xref, "Resources/"
    kind, val = doc.xref_get_key(holder, pre + cat)
    if kind == "xref":
        return int(val.split()[0]), ""
    if kind != "dict":
        doc.xref_set_key(holder, pre + cat, "<<>>")
    return holder, pre + cat + "/"


def set_resource(doc, page, cat: str, name: str, value: str) -> None:
    x, pre = _res_slot(doc, page, cat)
    doc.xref_set_key(x, pre + name, value)


def del_resource(doc, page, cat: str, name: str) -> None:
    x, pre = _res_slot(doc, page, cat)
    doc.xref_set_key(x, pre + name, "null")


def resource_entries(doc, page, cat: str) -> dict[str, int]:
    """name -> object number of the page's /Resources/<cat> entries that are references."""
    kind, val = doc.xref_get_key(page.xref, f"Resources/{cat}")
    if kind == "xref":
        val = doc.xref_object(int(val.split()[0]), compressed=True)
    elif kind != "dict":
        return {}
    out = {}
    for name, x in _RES_ENTRY.findall(val or ""):
        k2, v2 = doc.xref_get_key(page.xref, f"Resources/{cat}/{name}")
        if k2 == "xref" and v2.split()[0] == x:
            out[name] = int(x)
    return out


def _merge_new_streams(doc: fitz.Document, page: fitz.Page, new: list[int]) -> int:
    if len(new) == 1:
        return new[0]
    data = b"\n".join(doc.xref_stream(x) or b"" for x in new)
    doc.update_stream(new[0], data)
    set_contents(doc, page, [x for x in page.get_contents() if x not in new[1:]])
    return new[0]


RES_CATS = ("Font", "XObject", "ExtGState", "ColorSpace", "Pattern", "Shading", "Properties")
_NAME_RX = re.compile(rb"/([A-Za-z0-9_.+\-]+)")


def _resources_used_by(doc, page, xrefs) -> list[tuple[str, str, str]]:
    """(category, name, value) of page resources the given content streams may use."""
    names = set()
    for x in xrefs:
        names.update(n.decode("latin-1") for n in _NAME_RX.findall(doc.xref_stream(x) or b""))
    out = []
    for cat in RES_CATS:
        for n in names:
            kind, val = doc.xref_get_key(page.xref, f"Resources/{cat}/{n}")
            if kind != "null":
                out.append((cat, n, val))
    return out


def redact_keep_objects(doc, page, keep_ids: set | None = None, **kw) -> None:
    """apply_redactions() while Folio objects (all, or those in keep_ids) are taken out of
    the page. The redaction filter rebuilds the page's resource dictionary from what the
    remaining content uses, so we put back the fonts/images the objects need *before*
    anything else is written (otherwise their names get reused for other resources)."""
    cont = page.get_contents()
    objs = []
    for x in cont:
        m = meta_of(doc, x)
        if m is not None and (keep_ids is None or m.get("id") in keep_ids):
            objs.append(x)
    saved = _resources_used_by(doc, page, objs) if objs else []
    with detached(doc, page, only=keep_ids):
        page.apply_redactions(**kw)
        for cat, n, val in saved:
            kind, cur = doc.xref_get_key(page.xref, f"Resources/{cat}/{n}")
            if kind == "null":
                set_resource(doc, page, cat, n, val)


def redact_preserving_objects(doc, page, images, graphics, text) -> None:
    redact_keep_objects(doc, page, None, images=images, graphics=graphics, text=text)


# ---------------------------------------------------------------- geometry helpers
def _to_page(meta: dict, lx: float, ly: float) -> fitz.Point:
    o = fitz.Point(meta["o"])
    v = fitz.Point(lx, ly) * geom.R(meta.get("rot", 0))
    return o + v


def local_rect_to_page(meta: dict) -> fitz.Rect:
    w, h = meta["bw"], meta["bh"]
    pts = [_to_page(meta, x, y) for x, y in ((0, 0), (w, 0), (0, h), (w, h))]
    r = fitz.Rect(pts[0], pts[0])
    for p in pts[1:]:
        r |= p
    return r


def display_rect(page: fitz.Page, meta: dict) -> fitz.Rect:
    return geom.rect_to_disp(page, local_rect_to_page(meta))


def _frame_from_display_rect(page: fitz.Page, meta: dict, drect) -> tuple[fitz.Point, float, float]:
    """New (o, w, h) for an object whose on-screen bounding box should become `drect`."""
    rot = meta.get("rot", 0)
    inv = ~geom.R(rot)
    o_old = fitz.Point(meta["o"])
    d = fitz.Rect(drect)
    corners = [geom.pt_from_disp(page, p) for p in (d.tl, d.tr, d.bl, d.br)]
    loc = [(c - o_old) * inv for c in corners]
    lx0 = min(p.x for p in loc)
    ly0 = min(p.y for p in loc)
    lx1 = max(p.x for p in loc)
    ly1 = max(p.y for p in loc)
    o_new = o_old + fitz.Point(lx0, ly0) * geom.R(rot)
    return o_new, lx1 - lx0, ly1 - ly0


def new_frame(page: fitz.Page, drect) -> dict:
    """Frame for a new object occupying display rect `drect`, upright on screen."""
    d = fitz.Rect(drect)
    o = geom.pt_from_disp(page, d.tl)
    return {"o": [round(o.x, 3), round(o.y, 3)], "rot": page.rotation, "bw": d.width, "bh": d.height}


def _rgb(c, default=(0, 0, 0)):
    if c is None:
        return None
    if isinstance(c, str):
        c = c.lstrip("#")
        if len(c) == 3:
            c = "".join(ch * 2 for ch in c)
        return tuple(int(c[i:i + 2], 16) / 255 for i in (0, 2, 4))
    c = list(c)
    if any(v > 1 for v in c):
        c = [v / 255 for v in c]
    return tuple(c[:3]) if len(c) >= 3 else default


# ---------------------------------------------------------------- text layout
def text_face(fi: FontIndex, font: dict) -> Face | None:
    fam = (font or {}).get("family") or "Arial"
    bold = bool((font or {}).get("bold"))
    italic = bool((font or {}).get("italic"))
    f = fi.face_for_family(fam, bold, italic)
    if f is None:
        f = fi.generic(bold=bold, italic=italic)
    return f


def layout_text(meta: dict, fi: FontIndex | None = None):
    """Lay out a text object in its local frame.

    Returns (lines, box_w, box_h, fonts) where lines = [(x, baseline_y, [(text, face_key), ...])]
    and fonts maps face_key -> fitz.Font (subset of exactly the characters used)."""
    fi = fi or FontIndex.get()
    text = meta.get("text", "")
    size = float(meta.get("size") or 12)
    lh = float(meta.get("lh") or 1.2)
    face = text_face(fi, meta.get("font"))
    builtin = fitz.Font("helv") if face is None else None

    # Character coverage → which face renders which character.
    def runs_of(s: str):
        if face is None:
            return [(s, None)]
        return fi.split_by_coverage(face, s)

    paragraphs = text.split("\n")
    all_runs = [runs_of(p) for p in paragraphs]
    chars_per_face: dict[str | None, set] = {}
    for runs in all_runs:
        for t, f in runs:
            chars_per_face.setdefault(f.key if f else None, set()).update(t)
    fonts: dict[str | None, fitz.Font] = {}
    for key, chars in chars_per_face.items():
        if key is None:
            fonts[None] = builtin or fitz.Font("helv")
        else:
            fonts[key] = fitz.Font(fontbuffer=fi.subset(fi.by_key[key], "".join(chars)))
    main = fonts.get(face.key if face else None) or next(iter(fonts.values()), fitz.Font("helv"))

    def width(runs):
        return sum(fonts[f.key if f else None].text_length(t, fontsize=size) for t, f in runs)

    wrap = meta.get("w")
    lines_runs: list[list[tuple[str, Face | None]]] = []
    for runs in all_runs:
        if not wrap:
            lines_runs.append(runs)
            continue
        # word wrap at spaces, breaking over-long words by character
        para = "".join(t for t, _ in runs)
        owner = []
        for t, f in runs:
            owner.extend([f] * len(t))
        cur_start = 0
        i = 0
        last_space = -1
        n = len(para)
        if n == 0:
            lines_runs.append([])
            continue
        while i < n:
            seg = _runs_slice(para, owner, cur_start, i + 1)
            if width(seg) > wrap and i > cur_start:
                brk = last_space if last_space > cur_start else i
                lines_runs.append(_runs_slice(para, owner, cur_start, brk))
                cur_start = brk + 1 if (brk == last_space and last_space > cur_start) else brk
                last_space = -1
                i = cur_start
                continue
            if para[i] == " ":
                last_space = i
            i += 1
        lines_runs.append(_runs_slice(para, owner, cur_start, n))

    widths = [width(r) for r in lines_runs]
    box_w = float(wrap) if wrap else (max(widths) if widths else 0.0)
    vm = fi.vmetrics(face) if face is not None else None
    asc, desc = vm if vm else (main.ascender if main.ascender > 0 else 0.9,
                               main.descender if main.descender < 0 else -0.25)
    # CSS line-box model: each line is size*lh tall with the glyph box centred in it,
    # matching the on-screen editor the user typed into.
    line_h = size * lh
    lead = (line_h - (asc - desc) * size) / 2
    n = max(1, len(lines_runs))
    box_h = n * line_h
    align = meta.get("align", "left")
    out = []
    for i, runs in enumerate(lines_runs):
        lw = widths[i]
        if align == "center":
            x = (box_w - lw) / 2
        elif align == "right":
            x = box_w - lw
        else:
            x = 0.0
        out.append((x, lead + asc * size + i * line_h, [(t, f.key if f else None) for t, f in runs if t]))
    return out, max(box_w, 1.0), box_h, fonts


def _runs_slice(para, owner, a, b):
    runs = []
    for k in range(a, b):
        f = owner[k]
        if runs and runs[-1][1] is f:
            runs[-1] = (runs[-1][0] + para[k], f)
        else:
            runs.append((para[k], f))
    return runs


# ---------------------------------------------------------------- drawing
def _draw_shaped_text(doc, page, meta):
    """Text in right-to-left or joined scripts (Arabic, Hebrew, the Indic scripts...)
    must be shaped: letters join, reorder and change form. MuPDF's HTML layout has a
    shaping engine, so such a text box is set through it, with fonts that keep their
    OpenType layout tables."""
    fi = FontIndex.get()
    text = meta.get("text", "")
    size = float(meta.get("size") or 12)
    lh = float(meta.get("lh") or 1.2)
    face = text_face(fi, meta.get("font"))
    faces: list[Face] = []
    if face is not None:
        for _run, f in fi.split_by_coverage(face, text):
            if f not in faces:
                faces.append(f)
    arch = fitz.Archive()
    fams = []
    for i, f in enumerate(faces):
        arch.add(fi.shaping_subset(f, text), f"f{i}.ttf")
        fams.append(f"f{i}")
    r, g, b = _rgb(meta.get("color"), (0, 0, 0))
    css = "".join(f"@font-face{{font-family:{n};src:url({n}.ttf);}}" for n in fams)
    css += (f"*{{margin:0;padding:0;font-family:{','.join(fams) or 'sans-serif'};font-size:{size}px;"
            f"line-height:{lh};font-weight:normal;font-style:normal;"
            f"color:#{int(r * 255):02x}{int(g * 255):02x}{int(b * 255):02x};text-align:{meta.get('align', 'left')};}}")
    body = html.escape(text).replace("\n", "<br/>")
    # Measure on a scratch page: the box is as wide as the shaped text (or the wrap width)
    # and as tall as its lines.
    wrap = meta.get("w")
    width = float(wrap) if wrap else 5000.0
    scratch = fitz.open()
    try:
        sp = scratch.new_page(width=width + 20, height=5000)
        spare, _scale = sp.insert_htmlbox(fitz.Rect(0, 0, width, 5000), body, css=css, archive=arch)
        if not wrap:
            boxes = [fitz.Rect(rr) for kind, rr in sp.get_bboxlog() if "text" in kind]
            width = (max(bx.x1 for bx in boxes) - min(bx.x0 for bx in boxes)) if boxes else size
    finally:
        scratch.close()
    meta["bw"], meta["bh"] = round(width + 2, 3), round(max(5000 - spare, size * lh), 3)
    opacity = float(meta.get("opacity", 1.0))
    with _unrotated(page):
        page.insert_htmlbox(local_rect_to_page(meta), body, css=css, archive=arch, rotate=int(meta.get("rot", 0)),
                            opacity=opacity if opacity < 1 else 1)


def _draw_text(doc, page, meta):
    if needs_shaping(meta.get("text", "")):
        _draw_shaped_text(doc, page, meta)
        return
    lines, bw, bh, fonts = layout_text(meta)
    meta["bw"], meta["bh"] = round(bw, 3), round(bh, 3)
    o = fitz.Point(meta["o"])
    size = float(meta.get("size") or 12)
    color = _rgb(meta.get("color"), (0, 0, 0))
    tw = fitz.TextWriter(page.rect, color=color)
    wrote = False
    for x, base, runs in lines:
        pos = fitz.Point(o.x + x, o.y + base)
        for t, key in runs:
            font = fonts[key]
            tw.append(pos, t, font=font, fontsize=size)
            pos = fitz.Point(pos.x + font.text_length(t, fontsize=size), pos.y)
            wrote = True
    if not wrote:
        return
    d = fitz.Point(1, 0) * geom.R(meta.get("rot", 0))
    morph = geom.morph_for_dir(o, (d.x, d.y))
    opacity = float(meta.get("opacity", 1.0))
    tw.write_text(page, morph=morph, opacity=opacity if opacity < 1 else -1)


def _norm_pts(meta, pts):
    w, h = meta["bw"], meta["bh"]
    return [_to_page(meta, px * w, py * h) for px, py in pts]


def _draw_shape(doc, page, meta):
    t = meta["type"]
    sh = page.new_shape()
    stroke = _rgb(meta.get("stroke"), None)
    fill = _rgb(meta.get("fill"), None)
    lw = float(meta.get("lw", 1.5))
    opacity = float(meta.get("opacity", 1.0))
    rect_u = local_rect_to_page(meta)
    kw = dict(width=lw, color=stroke, fill=fill, stroke_opacity=opacity, fill_opacity=opacity)
    if t in ("rect", "whiteout"):
        if t == "whiteout":
            kw.update(color=None, fill=_rgb(meta.get("fill") or "#ffffff"), width=0)
        sh.draw_rect(rect_u)
        sh.finish(**kw)
    elif t == "ellipse":
        sh.draw_oval(rect_u)
        sh.finish(**kw)
    elif t in ("line", "arrow"):
        p1, p2 = _norm_pts(meta, meta["pts"])
        sh.draw_line(p1, p2)
        if t == "arrow":
            v = p2 - p1
            ln = math.hypot(v.x, v.y) or 1
            u = fitz.Point(v.x / ln, v.y / ln)
            nrm = fitz.Point(-u.y, u.x)
            head = max(6.0, lw * 4)
            b = p2 - u * head
            sh.draw_polyline([b + nrm * (head * 0.5), p2, b - nrm * (head * 0.5)])
        sh.finish(width=lw, color=stroke or (0, 0, 0), stroke_opacity=opacity, lineCap=1, lineJoin=1, closePath=False)
    elif t == "ink":
        for path in meta.get("paths", []):
            pts = _norm_pts(meta, path)
            if len(pts) == 1:
                pts = [pts[0], pts[0] + (0.01, 0.01)]
            sh.draw_polyline(pts)
        sh.finish(width=lw, color=stroke or (0, 0, 0), stroke_opacity=opacity, lineCap=1, lineJoin=1, closePath=False)
    elif t == "check":
        sh.draw_polyline(_norm_pts(meta, [(0.08, 0.55), (0.38, 0.86), (0.92, 0.14)]))
        sh.finish(width=max(1.0, min(meta["bw"], meta["bh"]) * 0.13), color=stroke or (0, 0, 0),
                  lineCap=1, lineJoin=1, closePath=False, stroke_opacity=opacity)
    elif t == "cross":
        a, b, c, d = _norm_pts(meta, [(0.12, 0.12), (0.88, 0.88), (0.88, 0.12), (0.12, 0.88)])
        sh.draw_line(a, b)
        sh.draw_line(c, d)
        sh.finish(width=max(1.0, min(meta["bw"], meta["bh"]) * 0.12), color=stroke or (0, 0, 0),
                  lineCap=1, closePath=False, stroke_opacity=opacity)
    elif t == "dot":
        sh.draw_oval(rect_u)
        col = stroke or (0, 0, 0)
        sh.finish(width=0, color=None, fill=col, fill_opacity=opacity)
    else:
        raise ValueError(f"unknown shape {t}")
    sh.commit(overlay=True)


def _draw_image(doc, page, meta, data: bytes | None = None, img_xref: int | None = None):
    rect_u = local_rect_to_page(meta)
    rot = int(meta.get("rot", 0))
    if data is not None:
        xref = page.insert_image(rect_u, stream=data, rotate=rot, keep_proportion=False)
    else:
        if not img_xref:
            raise ValueError("The picture for this object is missing.")
        xref = page.insert_image(rect_u, xref=int(img_xref), rotate=rot, keep_proportion=False)
    meta["img"] = xref  # informational only — always re-resolved by resource name


SHAPES = {"rect", "ellipse", "line", "arrow", "ink", "check", "cross", "dot", "whiteout"}


def _draw(doc, page, meta, data=None, img_xref=None):
    t = meta["type"]
    if t == "text":
        _draw_text(doc, page, meta)
    elif t == "image":
        with _unrotated(page):
            _draw_image(doc, page, meta, data, img_xref)
    elif t in SHAPES:
        with _unrotated(page):
            _draw_shape(doc, page, meta)
    else:
        raise ValueError(f"unknown object type {t}")


def _store(doc, xref, meta):
    clean = {k: v for k, v in meta.items() if k not in ("xref",)}
    doc.xref_set_key(xref, OBJ_KEY, fitz.get_pdf_str(json.dumps(clean, separators=(",", ":"))))


def add_object(doc: fitz.Document, page: fitz.Page, spec: dict, data: bytes | None = None,
               img_xref: int | None = None) -> dict:
    meta = dict(spec)
    meta.setdefault("id", uuid.uuid4().hex[:12])
    if meta["type"] == "text":
        for k, v in TEXT_DEFAULTS.items():
            meta.setdefault(k, v)
        if not meta.get("text", "").strip():
            raise ValueError("empty text")
    ensure_wrapped(doc, page)
    before = set(page.get_contents())
    _draw(doc, page, meta, data, img_xref)
    new = [x for x in page.get_contents() if x not in before]
    if not new:
        raise RuntimeError("nothing was drawn")
    xref = _merge_new_streams(doc, page, new)
    _store(doc, xref, meta)
    meta["xref"] = xref
    return meta


def find_object(doc, page, oid: str) -> tuple[int, dict] | tuple[None, None]:
    for x, m in object_streams(doc, page):
        if m.get("id") == oid:
            return x, m
    return None, None


def delete_object(doc, page, oid: str) -> dict:
    xref, meta = find_object(doc, page, oid)
    if xref is None:
        raise KeyError("object not found")
    set_contents(doc, page, [x for x in page.get_contents() if x != xref])
    return meta


def update_object(doc, page, oid: str, changes: dict) -> dict:
    """Re-draw an object with changed properties. `changes` may hold a display `rect`
    (move/resize) and any style/text fields."""
    xref, meta = find_object(doc, page, oid)
    if xref is None:
        raise KeyError("object not found")
    new = dict(meta)
    drect = changes.pop("rect", None)
    for k, v in changes.items():
        if k in ("id", "type", "o", "rot", "img", "xref"):
            continue
        new[k] = v
    if drect is not None:
        o, w, h = _frame_from_display_rect(page, meta, drect)
        new["o"] = [round(o.x, 3), round(o.y, 3)]
        if new["type"] == "text":
            # width handles change the wrap width; height always follows the text
            if abs(w - meta["bw"]) > 0.5:
                new["w"] = max(8.0, w)
        else:
            new["bw"], new["bh"] = max(1.0, w), max(1.0, h)
    img = image_xref_of(doc, page, xref) if new["type"] == "image" else None
    # position in the stack is kept: remove old stream, draw new, put it where the old one was
    cont = page.get_contents()
    pos = cont.index(xref)
    set_contents(doc, page, [x for x in cont if x != xref])
    ensure_wrapped(doc, page)
    before = set(page.get_contents())
    _draw(doc, page, new, None, img)
    added = [x for x in page.get_contents() if x not in before]
    nx = _merge_new_streams(doc, page, added)
    _store(doc, nx, new)
    cur = [x for x in page.get_contents() if x != nx]
    # keep z-order: re-insert at the old index among remaining streams
    pos = min(pos, len(cur))
    set_contents(doc, page, cur[:pos] + [nx] + cur[pos:])
    new["xref"] = nx
    return new


def _hex(c) -> str | None:
    rgb = _rgb(c, None)
    return None if rgb is None else "#%02x%02x%02x" % tuple(max(0, min(255, round(v * 255))) for v in rgb)


def object_json(page: fitz.Page, meta: dict) -> dict:
    d = display_rect(page, meta)
    out = {k: v for k, v in meta.items() if k not in ("o", "xref")}
    # colours always reach the UI as #rrggbb, however the object was stored
    for k in ("color", "stroke", "fill"):
        if out.get(k) not in (None, ""):
            out[k] = _hex(out[k])
    out["rect"] = geom.r4(d)
    out["rel_rot"] = (int(meta.get("rot", 0)) - page.rotation) % 360
    return out

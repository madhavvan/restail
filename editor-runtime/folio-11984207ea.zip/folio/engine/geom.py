"""Coordinate spaces.

PyMuPDF works in *unrotated* page space (top-left origin, points). The UI works in
*display* space: the page as the user sees it after its /Rotate is applied. Everything
crossing the API boundary is converted here and nowhere else.
"""

from __future__ import annotations

import pymupdf as fitz

# Pure rotation (vector part) of the derotation matrix for each page rotation:
# local "upright" direction -> unrotated page direction.
_R = {
    0: fitz.Matrix(1, 0, 0, 1, 0, 0),
    90: fitz.Matrix(0, -1, 1, 0, 0, 0),
    180: fitz.Matrix(-1, 0, 0, -1, 0, 0),
    270: fitz.Matrix(0, 1, -1, 0, 0, 0),
}


def R(theta: int) -> fitz.Matrix:
    return fitz.Matrix(_R[int(theta) % 360])


def rect_to_disp(page: fitz.Page, r) -> fitz.Rect:
    return fitz.Rect(r) * page.rotation_matrix


def rect_from_disp(page: fitz.Page, r) -> fitz.Rect:
    return fitz.Rect(r) * page.derotation_matrix


def pt_to_disp(page: fitz.Page, p) -> fitz.Point:
    return fitz.Point(p) * page.rotation_matrix


def pt_from_disp(page: fitz.Page, p) -> fitz.Point:
    return fitz.Point(p) * page.derotation_matrix


def vec_to_disp(page: fitz.Page, v) -> fitz.Point:
    m = page.rotation_matrix
    v = fitz.Point(v)
    return fitz.Point(m.a * v.x + m.c * v.y, m.b * v.x + m.d * v.y)


def vec_from_disp(page: fitz.Page, v) -> fitz.Point:
    m = page.derotation_matrix
    v = fitz.Point(v)
    return fitz.Point(m.a * v.x + m.c * v.y, m.b * v.x + m.d * v.y)


def morph_for_dir(origin, d) -> tuple | None:
    """TextWriter morph that turns text written left-to-right at `origin` so it runs
    along unrotated direction `d` (verified empirically for all 90-degree cases)."""
    dx, dy = float(d[0]), float(d[1])
    if abs(dx - 1) < 1e-6 and abs(dy) < 1e-6:
        return None
    return (fitz.Point(origin), fitz.Matrix(dx, -dy, dy, dx, 0, 0))


def r4(r) -> list[float]:
    r = fitz.Rect(r)
    return [round(r.x0, 2), round(r.y0, 2), round(r.x1, 2), round(r.y1, 2)]


def axis_dir(d, tol: float = 0.02) -> tuple[int, int] | None:
    """Snap a direction vector to one of the four axes, or None if it is oblique."""
    dx, dy = float(d[0]), float(d[1])
    for cand in ((1, 0), (0, 1), (-1, 0), (0, -1)):
        if abs(dx - cand[0]) < tol and abs(dy - cand[1]) < tol:
            return cand
    return None

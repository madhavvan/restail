"""Writing new text with a font object the PDF already has.

The most faithful way to set an edited word is with the very font the line was drawn
with: identical glyphs, the PDF's own advance widths and its own text mapping — so the
new word renders, copies and searches exactly like its neighbours, and nothing new is
embedded. That takes the reverse of the PDF's text mapping (which character code draws
which character). A font is only used when every character needed has a code whose
glyph is really in the (usually subset) font, and the mapping is proven first by
reading back a sample written with it.

(Re-embedding the font program through MuPDF's TextWriter instead is not an option for
Type 1 programs: MuPDF writes them as an invalid CID font with every advance set to the
same wrong width, so the letters pile up.)
"""

from __future__ import annotations

import io
import logging
import re
from collections import Counter

import pymupdf as fitz
from fontTools import agl

from . import objects

log = logging.getLogger("folio.fontres")

_REF = re.compile(r"(\d+)\s+0\s+R")
_NUM_OR_BRACKET = re.compile(r"\[|\]|[-+]?(?:\d+\.?\d*|\.\d+)")
_DIFF_TOKEN = re.compile(r"/([^\s/\[\]<>(){}%]+)|([-+]?\d+)")
_T1_DUP = re.compile(rb"dup\s+(\d+)\s*/([^\s/\[\]{}()<>%]+)\s+put")

# StandardEncoding where it differs from ASCII (and its common upper-half glyphs).
_STANDARD = {0x27: "’", 0x60: "‘", 0xA1: "¡", 0xA2: "¢", 0xA3: "£", 0xA5: "¥",
             0xA7: "§", 0xAA: "“", 0xAB: "«", 0xB1: "–", 0xB2: "†", 0xB3: "‡",
             0xB7: "•", 0xBA: "”", 0xBB: "»", 0xBC: "…", 0xBF: "¿", 0xD0: "—"}


# ------------------------------------------------------------------ small PDF readers
def _ref(val: str) -> int | None:
    m = _REF.match(val or "")
    return int(m.group(1)) if m else None


def _value(doc, xref: int, key: str) -> tuple[str, str]:
    """(kind, PDF source) of a key, following one indirect reference for arrays/dicts."""
    kind, val = doc.xref_get_key(xref, key)
    if kind == "xref":
        x = _ref(val)
        if x is not None and not doc.xref_is_stream(x):
            src = doc.xref_object(x, compressed=True).strip()
            if src.startswith("["):
                return "array", src
            if src.startswith("<<"):
                return "dict", src
            return "other", src
    return kind, val


def _num(doc, xref: int, key: str, default: float) -> float:
    kind, val = doc.xref_get_key(xref, key)
    if kind == "xref":
        x = _ref(val)
        val = doc.xref_object(x, compressed=True) if x else ""
    try:
        return float(val)
    except (TypeError, ValueError):
        return default


def _utf16(hexstr: bytes) -> str:
    h = re.sub(rb"\s+", b"", hexstr)
    if len(h) % 2:
        h += b"0"
    raw = bytes.fromhex(h.decode("ascii"))
    if len(raw) % 2:
        raw = b"\x00" + raw
    return raw.decode("utf-16-be", errors="replace")


def parse_tounicode(data: bytes) -> dict[int, str]:
    """code -> text from a ToUnicode CMap (bfchar and bfrange sections)."""
    out: dict[int, str] = {}
    for block in re.finditer(rb"beginbfchar(.*?)endbfchar", data, re.S):
        for src, dst in re.findall(rb"<([0-9A-Fa-f\s]+)>\s*<([0-9A-Fa-f\s]*)>", block.group(1)):
            try:
                out[int(re.sub(rb"\s+", b"", src), 16)] = _utf16(dst)
            except ValueError:
                continue
    for block in re.finditer(rb"beginbfrange(.*?)endbfrange", data, re.S):
        for m in re.finditer(rb"<([0-9A-Fa-f\s]+)>\s*<([0-9A-Fa-f\s]+)>\s*(<[0-9A-Fa-f\s]*>|\[[^\]]*\])", block.group(1)):
            try:
                lo = int(re.sub(rb"\s+", b"", m.group(1)), 16)
                hi = int(re.sub(rb"\s+", b"", m.group(2)), 16)
            except ValueError:
                continue
            if hi < lo or hi - lo > 0xFFFF:
                continue
            dst = m.group(3)
            if dst.startswith(b"["):
                for i, item in enumerate(re.findall(rb"<([0-9A-Fa-f\s]*)>", dst)[: hi - lo + 1]):
                    out[lo + i] = _utf16(item)
            else:
                s = _utf16(dst[1:-1])
                if not s:
                    continue
                last = ord(s[-1])
                for i in range(hi - lo + 1):
                    cp = last + i
                    if 0xD800 <= cp <= 0xDFFF or cp > 0x10FFFF:
                        break
                    out[lo + i] = s[:-1] + chr(cp)
    return out


def _cmap_source(mapping: dict[int, str], two_byte: bool = True) -> bytes:
    fmt = "<%04x>" if two_byte else "<%02x>"
    items = sorted(mapping.items())
    parts = ["/CIDInit /ProcSet findresource begin", "12 dict begin", "begincmap",
             "/CIDSystemInfo <</Registry (Adobe) /Ordering (UCS) /Supplement 0>> def",
             "/CMapName /Adobe-Identity-UCS def", "/CMapType 2 def",
             "1 begincodespacerange", ("<0000> <FFFF>" if two_byte else "<00> <FF>"), "endcodespacerange"]
    for i in range(0, len(items), 100):
        chunk = items[i:i + 100]
        parts.append(f"{len(chunk)} beginbfchar")
        for code, s in chunk:
            parts.append(f"{fmt % code} <{s.encode('utf-16-be').hex()}>")
        parts.append("endbfchar")
    parts += ["endcmap", "CMapName currentdict /CMap defineresource pop", "end", "end"]
    return "\n".join(parts).encode("ascii")


def _parse_w(src: str) -> dict[int, float]:
    """CID font /W array: `c [w1 w2 ...]` and `c_first c_last w` entries."""
    out: dict[int, float] = {}
    toks = _NUM_OR_BRACKET.findall(src or "")
    i = 0
    if toks and toks[0] == "[":
        toks = toks[1:]
    while i < len(toks):
        t = toks[i]
        if t in ("[", "]"):
            i += 1
            continue
        try:
            first = int(float(t))
        except ValueError:
            break
        if i + 1 < len(toks) and toks[i + 1] == "[":
            j = i + 2
            c = first
            while j < len(toks) and toks[j] != "]":
                out[c] = float(toks[j])
                c += 1
                j += 1
            i = j + 1
        elif i + 2 < len(toks):
            try:
                last, w = int(float(toks[i + 1])), float(toks[i + 2])
            except ValueError:
                break
            if 0 <= last - first <= 0xFFFF:
                for c in range(first, last + 1):
                    out[c] = w
            i += 3
        else:
            break
    return out


def _glyph_char(name: str) -> str | None:
    try:
        s = agl.toUnicode(name)
    except Exception:
        return None
    return s if len(s) == 1 else None


def _base_encoding(name: str) -> dict[int, str]:
    out: dict[int, str] = {}
    if name == "WinAnsiEncoding":
        for c in range(0x20, 0x100):
            try:
                out[c] = bytes([c]).decode("cp1252")
            except UnicodeDecodeError:
                pass
    elif name == "MacRomanEncoding":
        for c in range(0x20, 0x100):
            if c != 0x7F:
                out[c] = bytes([c]).decode("mac_roman")
    elif name == "StandardEncoding":
        for c in range(0x20, 0x7F):
            out[c] = chr(c)
        out.update(_STANDARD)
    return out


def embedded_program(doc, xref: int, cache: dict) -> tuple[fitz.Font | None, str, bytes]:
    """(font, extension, raw bytes) of the font program embedded for a font object."""
    key = ("emb", xref)
    if key not in cache:
        font, ext, buf = None, "", b""
        try:
            _name, ext, _typ, buf = doc.extract_font(xref)
            if buf and ext not in ("n/a", ""):
                font = fitz.Font(fontbuffer=buf)
        except Exception:
            font = None
        cache[key] = (font, ext or "", buf or b"")
    return cache[key]


def _builtin_encoding(ext: str, buf: bytes) -> dict[int, str] | None:
    """A Type 1 / CFF program's own encoding vector (used when the PDF gives none)."""
    if not buf:
        return None
    if ext in ("pfa", "pfb"):
        head = buf[: buf.find(b"eexec")] if b"eexec" in buf else buf[:65536]
        if re.search(rb"/Encoding\s+StandardEncoding\s+def", head):
            return _base_encoding("StandardEncoding")
        out = {}
        for code, name in _T1_DUP.findall(head):
            ch = _glyph_char(name.decode("latin-1"))
            if ch:
                out[int(code)] = ch
        return out or None
    if ext == "cff":
        try:
            from fontTools.cffLib import CFFFontSet
            cff = CFFFontSet()
            cff.decompile(io.BytesIO(buf), None)
            enc = cff.topDictIndex[0].Encoding
        except Exception:
            return None
        if enc == "StandardEncoding" or enc == 0:
            return _base_encoding("StandardEncoding")
        if isinstance(enc, list):
            out = {}
            for code, name in enumerate(enc[:256]):
                ch = _glyph_char(name) if name and name != ".notdef" else None
                if ch:
                    out[code] = ch
            return out or None
    return None


# ------------------------------------------------------------------ the font object
# The 14 standard fonts every PDF reader has built in (often not embedded at all).
STANDARD14 = {
    "helvetica": "helv", "helvetica-bold": "hebo", "helvetica-oblique": "heit", "helvetica-boldoblique": "hebi",
    "times-roman": "tiro", "times-bold": "tibo", "times-italic": "tiit", "times-bolditalic": "tibi",
    "courier": "cour", "courier-bold": "cobo", "courier-oblique": "coit", "courier-boldoblique": "cobi",
    "symbol": "symb", "zapfdingbats": "zadb",
}


class FontRes:
    """A font object of the PDF that can be written with directly."""

    standard = False   # a standard-14 font the PDF doesn't embed

    def __init__(self, xref: int, two_byte: bool, codes: dict[str, list[int]], widths: dict[int, float],
                 default_w: float, cid_to_gid: dict[int, int] | None):
        self.xref = xref
        self.two_byte = two_byte
        self.cands = codes              # char -> candidate codes, best first
        self.widths = widths            # code -> width in 1/1000 em
        self.default_w = default_w
        self.cid_to_gid = cid_to_gid    # CIDFontType2 only: for preferring the glyphs the page uses
        self.chosen: dict[str, int] = {}
        self.verified: dict[str, bool] = {}

    def code(self, ch: str) -> int | None:
        if ch in self.chosen:
            return self.chosen[ch]
        c = self.cands.get(ch)
        return c[0] if c else None

    def width(self, code: int) -> float:
        return self.widths.get(code, self.default_w)

    def covers(self, chars: str) -> bool:
        for ch in chars:
            if ch.isspace():
                continue
            c = self.code(ch)
            if c is None or self.width(c) <= 0:
                return False
        return True

    def length(self, text: str, size: float) -> float:
        total = 0.0
        for ch in text:
            c = self.code(ch)
            total += self.width(c) if c is not None else (250.0 if ch.isspace() else 0.0)
        return total * size / 1000.0

    def space(self, size: float) -> float:
        c = self.code(" ")
        if c is not None and self.width(c) > 0:
            return self.width(c) * size / 1000.0
        return 0.25 * size

    def hex(self, text: str) -> str:
        fmt = "%04x" if self.two_byte else "%02x"
        return "".join(fmt % self.code(ch) for ch in text if self.code(ch) is not None)

    def prefer_used(self, chars: str, usage) -> None:
        """Among several codes for one character (alternates such as small capitals map
        to the same letter) take the glyph the page itself draws for it. `usage` is
        called only when a needed character really has alternates."""
        if self.cid_to_gid is None:
            return
        ambiguous = [c for c in set(chars) if len(self.cands.get(c, ())) > 1 and c not in self.chosen]
        if not ambiguous:
            return
        used = usage()
        for ch in ambiguous:
            codes = self.cands[ch]
            if ch not in used:
                continue
            gid_count = used[ch]
            best = max(codes, key=lambda c: (gid_count.get(self.cid_to_gid.get(c, c), 0), -codes.index(c)))
            if gid_count.get(self.cid_to_gid.get(best, best), 0):
                self.chosen[ch] = best


def load(doc, xref: int, cache: dict) -> FontRes | None:
    key = ("fontres", xref)
    if key not in cache:
        try:
            cache[key] = _load(doc, xref, cache)
        except Exception:
            log.debug("font %d not reusable", xref, exc_info=True)
            cache[key] = None
    return cache[key]


def _tounicode(doc, xref: int) -> dict[int, str]:
    kind, val = doc.xref_get_key(xref, "ToUnicode")
    x = _ref(val) if kind == "xref" else None
    if x is None or not doc.xref_is_stream(x):
        return {}
    return parse_tounicode(doc.xref_stream(x) or b"")


def _invert(code_to_text: dict[int, str], widths, default_w, prefer_codes=None) -> dict[str, list[int]]:
    out: dict[str, list[int]] = {}
    for code in sorted(code_to_text):
        s = code_to_text[code]
        if len(s) != 1 or s == "�":
            continue
        out.setdefault(s, []).append(code)
    for s, codes in out.items():
        # glyphs with a width first; then the code the PDF's own encoding gives the char
        codes.sort(key=lambda c: (0 if (widths.get(c, default_w) > 0 or s.isspace()) else 1,
                                  0 if (prefer_codes and prefer_codes.get(s) == c) else 1, c))
    return out


def _load(doc, xref: int, cache: dict) -> FontRes | None:
    kind, subtype = doc.xref_get_key(xref, "Subtype")
    if kind != "name":
        return None
    subtype = subtype.lstrip("/")
    if subtype == "Type0":
        kind, enc = doc.xref_get_key(xref, "Encoding")
        if kind != "name" or enc != "/Identity-H":
            return None
        kind, desc = _value(doc, xref, "DescendantFonts")
        m = _REF.search(desc or "")
        if not m:
            return None
        dx = int(m.group(1))
        _k, w_src = _value(doc, dx, "W")
        widths = _parse_w(w_src) if _k == "array" else {}
        dw = _num(doc, dx, "DW", 1000.0)
        tu = _tounicode(doc, xref)
        if not tu:
            return None
        cid_to_gid = None
        if doc.xref_get_key(dx, "Subtype")[1] == "/CIDFontType2":
            mk, mv = doc.xref_get_key(dx, "CIDToGIDMap")
            mx = _ref(mv) if mk == "xref" else None
            if mx is not None and doc.xref_is_stream(mx):
                raw = doc.xref_stream(mx) or b""
                cid_to_gid = {i // 2: (raw[i] << 8) | raw[i + 1] for i in range(0, len(raw) - 1, 2)}
            else:
                cid_to_gid = {}
        return FontRes(xref, True, _invert(tu, widths, dw), widths, dw, cid_to_gid)

    if subtype not in ("Type1", "MMType1", "TrueType"):
        return None
    prog, ext, buf = embedded_program(doc, xref, cache)
    std = None
    if prog is None:
        # Not embedded: only the standard 14 are drawn the same by every reader.
        bk, bv = doc.xref_get_key(xref, "BaseFont")
        std = STANDARD14.get(re.sub(r"^[A-Z]{6}\+", "", bv.lstrip("/")).lower()) if bk == "name" else None
        if std is None:
            return None
        prog = fitz.Font(std)
    first = int(_num(doc, xref, "FirstChar", 0))
    wk, w_src = _value(doc, xref, "Widths")
    if wk == "array":
        nums = [float(t) for t in _NUM_OR_BRACKET.findall(w_src) if t not in ("[", "]")]
        widths = {first + i: w for i, w in enumerate(nums)}
    elif std is not None:
        widths = None   # the reader uses the font's standard metrics: filled in below
    else:
        return None
    fdk, fdv = doc.xref_get_key(xref, "FontDescriptor")
    fdx = _ref(fdv) if fdk == "xref" else None
    missing = _num(doc, fdx, "MissingWidth", 0.0) if fdx else 0.0

    # code -> char the way a reader derives it: base encoding, /Differences, then ToUnicode.
    ek, ev = _value(doc, xref, "Encoding")
    base: dict[int, str] | None = None
    diffs: dict[int, str] = {}
    if ek == "name":
        base = _base_encoding(ev.lstrip("/"))
    elif ek == "dict":
        bk, bv = doc.xref_get_key(xref, "Encoding/BaseEncoding")
        if bk == "name":
            base = _base_encoding(bv.lstrip("/"))
        dk, dv = doc.xref_get_key(xref, "Encoding/Differences")
        if dk == "xref":
            x = _ref(dv)
            dv = doc.xref_object(x, compressed=True) if x else ""
        code = None
        for name, num in _DIFF_TOKEN.findall(dv or ""):
            if num:
                code = int(num)
            elif code is not None:
                ch = _glyph_char(name)
                if ch:
                    diffs[code] = ch
                code += 1
    if not base:
        base = (_builtin_encoding(ext, buf) if std is None else None) or {}
        if not base and subtype != "TrueType" and std not in ("symb", "zadb"):
            base = _base_encoding("StandardEncoding")
    from_encoding = dict(base)
    from_encoding.update(diffs)
    # Encoding-derived codes count only if the glyph is really in the subset program.
    enc_map = {c: s for c, s in from_encoding.items() if s.isspace() or prog.has_glyph(ord(s))}
    if widths is None:
        widths = {c: prog.glyph_advance(ord(s)) * 1000 for c, s in enc_map.items()}
    tu = _tounicode(doc, xref)
    code_to_text = dict(enc_map)
    code_to_text.update(tu)
    prefer = {}
    for c, s in sorted(enc_map.items()):
        prefer.setdefault(s, c)
    res = FontRes(xref, False, _invert(code_to_text, widths, missing, prefer), widths, missing, None)
    res.standard = std is not None
    return res


# ------------------------------------------------------------------ using it on a page
def resource_name(doc, page, xref: int) -> str:
    """The page's resource name for a font object, adding one if the page lacks it
    (the font may live in a form XObject, or a redaction just pruned the entry)."""
    names = objects.resource_entries(doc, page, "Font")
    for n, x in names.items():
        if x == xref:
            return n
    i = 0
    while f"FolioF{i}" in names:
        i += 1
    name = f"FolioF{i}"
    objects.set_resource(doc, page, "Font", name, f"{xref} 0 R")
    return name


def _gs_name(doc, page, alpha: float) -> str:
    names = objects.resource_entries(doc, page, "ExtGState")
    key = f"FolioGS{int(round(alpha * 1000))}"
    if key not in names:
        x = doc.get_new_xref()
        doc.update_object(x, f"<</Type/ExtGState/ca {alpha:.3f}/CA {alpha:.3f}>>")
        objects.set_resource(doc, page, "ExtGState", key, f"{x} 0 R")
    return key


def _n(v: float) -> str:
    s = f"{v:.4f}".rstrip("0").rstrip(".")
    return "0" if s in ("-0", "") else s


def _to_pdf_matrix(page) -> fitz.Matrix:
    with objects._unrotated(page):
        m = page.transformation_matrix
    return ~m


def stream_for(doc, page, items: list[dict], names: dict | None = None) -> bytes:
    """Content-stream bytes drawing `items`, each {res, size, rgb, alpha, tc, origin, d, text}
    with origin/d in unrotated page space."""
    inv = _to_pdf_matrix(page)
    lin = fitz.Matrix(inv.a, inv.b, inv.c, inv.d, 0, 0)
    names = {} if names is None else names
    ops = []
    for it in items:
        res: FontRes = it["res"]
        hexs = res.hex(it["text"])
        if not hexs:
            continue
        name = names.get(res.xref)
        if name is None:
            name = names[res.xref] = resource_name(doc, page, res.xref)
        d = fitz.Point(it["d"])
        nrm = fitz.Point(-d.y, d.x)
        u = d * lin
        up = (nrm * lin) * -1
        p = fitz.Point(it["origin"]) * inv
        r, g, b = it.get("rgb", (0, 0, 0))
        ops.append("q")
        alpha = it.get("alpha", 255)
        if alpha < 255:
            ops.append(f"/{_gs_name(doc, page, alpha / 255)} gs")
        ops.append(f"{_n(r)} {_n(g)} {_n(b)} rg")
        ops.append("BT")
        ops.append(f"/{name} {_n(it['size'])} Tf")
        if it.get("tc"):
            ops.append(f"{_n(it['tc'])} Tc")
        ops.append(f"{_n(u.x)} {_n(u.y)} {_n(up.x)} {_n(up.y)} {_n(p.x)} {_n(p.y)} Tm")
        ops.append(f"<{hexs}> Tj")
        ops.append("ET")
        ops.append("Q")
    return ("\n".join(ops) + "\n").encode("latin-1")


def append_stream(doc, page, data: bytes) -> int:
    x = doc.get_new_xref()
    doc.update_object(x, "<<>>")
    doc.update_stream(x, data)
    objects.set_contents(doc, page, page.get_contents() + [x])
    return x


def verify(doc, page, res: FontRes, chars: str) -> bool:
    """Prove the reverse mapping before trusting it: write the characters with the font,
    read them back from just that sample, and compare. The page is left as it was."""
    need = "".join(sorted({c for c in chars if not c.isspace()}))
    if not need:
        return True
    todo = "".join(c for c in need if c not in res.verified)
    if todo:
        # Small rows from the top-left corner, so the sample is inside the page wherever
        # the edited line is (text outside the page box isn't read back).
        box = fitz.Rect(page.rect) * page.derotation_matrix
        items = []
        for i in range(0, len(todo), 24):
            items.append({"res": res, "size": 6.0, "origin": (box.x0 + 2, box.y0 + 8 + 9 * (i // 24)),
                          "d": (1, 0), "text": todo[i:i + 24]})
        before_names = objects.resource_entries(doc, page, "Font")
        data = stream_for(doc, page, items)
        x = doc.get_new_xref()
        doc.update_object(x, "<<>>")
        doc.update_stream(x, data)
        try:
            with objects.isolated(doc, page, [x]):
                got = objects.content_text(page, fitz.TEXT_PRESERVE_WHITESPACE | fitz.TEXT_PRESERVE_LIGATURES)
        finally:
            for n in set(objects.resource_entries(doc, page, "Font")) - set(before_names):
                objects.del_resource(doc, page, "Font", n)
        seq = [ch["c"] for b in got.get("blocks", []) for ln in b.get("lines", []) for s in ln.get("spans", [])
               for ch in s.get("chars", [])]
        read = Counter(c for c in seq if not c.isspace())
        ok_all = read == Counter(todo)
        for c in todo:
            res.verified[c] = ok_all or read.get(c, 0) == 1
        if not ok_all:
            log.info("font %d: wrote %r, read back %r", res.xref, todo, "".join(seq))
    return all(res.verified.get(c) for c in need)


def page_glyph_usage(page, cache: dict) -> dict[str, dict[str, Counter]]:
    """font name -> char -> Counter of glyph ids the page draws it with."""
    key = ("usage", page.xref)
    if key not in cache:
        use: dict[str, dict[str, Counter]] = {}
        try:
            for span in page.get_texttrace():
                fname = span.get("font", "")
                per = use.setdefault(fname, {})
                for ch in span.get("chars", ()):
                    u, gid = ch[0], ch[1]
                    if u is None or u < 0 or gid is None or gid < 0:
                        continue
                    per.setdefault(chr(u), Counter())[gid] += 1
        except Exception:
            use = {}
        cache[key] = use
    return cache[key]


def fix_tounicode(doc, xref: int) -> None:
    """MuPDF builds the ToUnicode map of a font it embeds by walking the font's cmap and
    letting the *last* code point win for each glyph — so a hyphen glyph the font also
    maps to U+00AD reads back as a soft hyphen, and a space as a no-break space. Give
    every glyph its plainest code point instead."""
    kind, val = doc.xref_get_key(xref, "ToUnicode")
    tx = _ref(val) if kind == "xref" else None
    if tx is None or not doc.xref_is_stream(tx):
        return
    mapping = parse_tounicode(doc.xref_stream(tx) or b"")
    if not mapping:
        return
    try:
        _name, _ext, _typ, buf = doc.extract_font(xref)
        font = fitz.Font(fontbuffer=buf)
        cps = font.valid_codepoints()
    except Exception:
        return
    best: dict[int, int] = {}
    for cp in cps:
        if cp < 0x20 or 0x7F <= cp <= 0x9F:
            continue
        g = font.has_glyph(cp)
        if g and (g not in best or cp < best[g]):
            best[g] = cp
    changed = False
    for gid, s in list(mapping.items()):
        if len(s) == 1 and gid in best and best[gid] < ord(s):
            mapping[gid] = chr(best[gid])
            changed = True
    if changed:
        doc.update_stream(tx, _cmap_source(mapping, True))

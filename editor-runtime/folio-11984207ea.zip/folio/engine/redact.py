"""Erase and redact: content under the area is actually removed, not just covered.

"Removed" includes what sits on top of the page too: form fields and comments in the
area are deleted, because their values live in the file even when a box is drawn over
them. Redaction marks already in the document (someone else's pending redactions) are
left alone.
"""

from __future__ import annotations

import re

import pymupdf as fitz

from . import geom, objects, text

PATTERNS = {
    "ssn": r"\b\d{3}-\d{2}-\d{4}\b",
    "email": r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}",
    "phone": r"(?:\+?1[\s.-]?)?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}\b",
    "card": r"\b(?:\d[ -]?){13,16}\b",
    "date": r"\b(?:\d{1,2}[/-]\d{1,2}[/-]\d{2,4}|\d{4}-\d{2}-\d{2})\b",
}
_SKIP_ANNOTS = {fitz.PDF_ANNOT_REDACT, fitz.PDF_ANNOT_LINK, fitz.PDF_ANNOT_POPUP}


def _remove_overlays(page, rects_u: list) -> int:
    """Delete form fields and comments that touch the areas."""
    n = 0
    for w in list(page.widgets() or []):
        if any(fitz.Rect(w.rect).intersects(r) for r in rects_u):
            page.delete_widget(w)
            n += 1
    for a in list(page.annots() or []):
        if a.type[0] in _SKIP_ANNOTS or a.type[0] == fitz.PDF_ANNOT_WIDGET:
            continue
        if any(fitz.Rect(a.rect).intersects(r) for r in rects_u):
            page.delete_annot(a)
            n += 1
    return n


def _apply(doc, page, rects_u: list, fill, keep_untouched_objects=True) -> None:
    # Added objects that don't touch the area stay movable objects; ones that do are
    # removed along with everything else there.
    keep = set()
    if keep_untouched_objects:
        for _x, m in objects.object_streams(doc, page):
            r = objects.local_rect_to_page(m)
            if not any(r.intersects(ru) for ru in rects_u):
                keep.add(m.get("id"))
    stash = text._stash_foreign_redactions(page)
    try:
        _remove_overlays(page, rects_u)
        # Our rects are unrotated; with /Rotate and a CropBox offset from the MediaBox,
        # MuPDF draws the fill box shifted by that offset, so apply with rotation off.
        with objects._unrotated(page):
            for ru in rects_u:
                page.add_redact_annot(ru, fill=fill if fill is not None else False, cross_out=False)
            objects.redact_keep_objects(doc, page, keep, images=fitz.PDF_REDACT_IMAGE_PIXELS,
                                        graphics=fitz.PDF_REDACT_LINE_ART_REMOVE_IF_COVERED,
                                        text=fitz.PDF_REDACT_TEXT_REMOVE)
    finally:
        if stash:
            text._restore_foreign_redactions(page, stash)


def erase(doc, page, rect_disp, fill: str | None = None) -> None:
    """Remove text, image pixels and covered vector art in the area. The area becomes
    transparent (page background shows) unless a fill colour is given."""
    ru = geom.rect_from_disp(page, rect_disp)
    if ru.is_empty:
        raise ValueError("empty area")
    objects.ensure_wrapped(doc, page)
    _apply(doc, page, [ru], objects._rgb(fill) if fill else None)


def redact(doc, page, rects_disp: list, color: str = "#000000") -> None:
    rus = [geom.rect_from_disp(page, r) for r in rects_disp]
    rus = [r for r in rus if not r.is_empty]
    if not rus:
        raise ValueError("empty area")
    objects.ensure_wrapped(doc, page)
    _apply(doc, page, rus, objects._rgb(color))


def _rx(query: str, regex: bool, case: bool, whole: bool) -> re.Pattern:
    return text._pattern(query, case, whole, regex)


def find_matches(doc, query: str, regex: bool, case: bool, whole: bool, pages=None) -> dict[int, list]:
    out = {}
    for pno in (pages if pages is not None else range(doc.page_count)):
        hits = text.search_page(doc, doc[pno], query, case=case, whole=whole, regex=regex)
        if hits:
            out[pno] = hits
    return out


def _overlay_matches(page, rx: re.Pattern) -> tuple[list, list]:
    """Form fields whose value matches, and comments whose text matches."""
    widgets, annots = [], []
    for w in page.widgets() or []:
        v = w.field_value
        if isinstance(v, str) and v and rx.search(v):
            widgets.append(w)
    for a in page.annots() or []:
        if a.type[0] in _SKIP_ANNOTS or a.type[0] == fitz.PDF_ANNOT_WIDGET:
            continue
        info = a.info or {}
        blob = " ".join(str(info.get(k, "")) for k in ("content", "title", "subject"))
        if blob.strip() and rx.search(blob):
            annots.append(a)
    return widgets, annots


def _outside(hits: list, widgets: list) -> list:
    """Page-text hits that aren't just a field's own visible value (counted once)."""
    wr = [fitz.Rect(w.rect) for w in widgets]
    return [h for h in hits if not any(r.intersects(fitz.Rect(h["unrot"])) for r in wr)]


def preview_matches(doc, query: str, regex: bool, case: bool, whole: bool) -> tuple[int, list[int], list]:
    found = find_matches(doc, query, regex, case, whole)
    rx = _rx(query, regex, case, whole)
    count = 0
    pages = set()
    hits = []
    for pno in range(doc.page_count):
        page = doc[pno]
        widgets, annots = _overlay_matches(page, rx)
        for h in _outside(found.get(pno, []), widgets):
            count += 1
            pages.add(pno)
            hits.append({"page": pno, "rect": h["rect"], "text": h["text"]})
        for w in widgets:
            count += 1
            pages.add(pno)
            hits.append({"page": pno, "rect": geom.r4(geom.rect_to_disp(page, w.rect)), "text": w.field_value})
        for a in annots:
            count += 1
            pages.add(pno)
            hits.append({"page": pno, "rect": geom.r4(geom.rect_to_disp(page, a.rect)), "text": (a.info or {}).get("content", "")})
    return count, sorted(pages), hits


def redact_matches(doc, query: str, regex: bool, case: bool, whole: bool, pages=None,
                   color: str = "#000000") -> tuple[int, list[int]]:
    found = find_matches(doc, query, regex, case, whole, pages)
    rx = _rx(query, regex, case, whole)
    count = 0
    touched = set()
    for pno in (pages if pages is not None else range(doc.page_count)):
        page = doc[pno]
        # field values and comment text first: they are not page content
        widgets, annots = _overlay_matches(page, rx)
        hits = found.get(pno) or []
        count += len(_outside(hits, widgets))
        for w in widgets:
            page.delete_widget(w)
            count += 1
            touched.add(pno)
        for a in annots:
            page.delete_annot(a)
            count += 1
            touched.add(pno)
        if hits:
            objects.ensure_wrapped(doc, page)
            _apply(doc, page, [fitz.Rect(h["unrot"]) for h in hits], objects._rgb(color))
            touched.add(pno)
    return count, sorted(touched)


def scrub_hidden(doc) -> None:
    """Remove metadata, XMP, JavaScript, attachments and thumbnails. Invisible text is
    kept on purpose: in scanned PDFs it is the searchable OCR layer."""
    doc.scrub(attached_files=True, clean_pages=False, embedded_files=True, hidden_text=False, javascript=True,
              metadata=True, redactions=False, redact_images=0, remove_links=False, reset_fields=False,
              reset_responses=True, thumbnails=True, xml_metadata=True)

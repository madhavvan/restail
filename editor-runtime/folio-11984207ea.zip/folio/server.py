"""Folio's local API + UI server.

Binds to 127.0.0.1 on a random port. Every request must carry the per-launch secret
(cookie for the UI, header for the second-instance hand-off), the Host header must be
the loopback address (no DNS rebinding) and state-changing requests need a custom header
(no cross-site form posts). Nothing ever leaves the machine.
"""

from __future__ import annotations

import base64
import http.server
import json
import logging
import mimetypes
import os
import re
import secrets
import subprocess
import threading
import time
import traceback
import urllib.parse

import pymupdf as fitz

from . import __version__, paths
from .engine import (annots, compress, convert, forms, geom, objects, pages, redact, session,
                     stamp, text)
from .engine.fonts import FontIndex
from .engine.session import ENGINE, BadPassword, NeedPassword

log = logging.getLogger("folio.server")

PDF_TYPES = ("PDF files (*.pdf)", "All files (*.*)")
OPEN_TYPES = ("PDF and images (*.pdf;*.png;*.jpg;*.jpeg;*.tif;*.tiff;*.bmp;*.gif;*.webp;*.xps;*.epub)",
              "Office documents (*.docx;*.doc;*.rtf;*.odt;*.xlsx;*.xls;*.pptx;*.ppt)",
              "All files (*.*)")
IMAGE_TYPES = ("Images (*.png;*.jpg;*.jpeg;*.tif;*.tiff;*.bmp;*.gif;*.webp)", "All files (*.*)")


class ApiError(Exception):
    def __init__(self, msg, status=400, **extra):
        super().__init__(msg)
        self.status = status
        self.extra = extra


def _data_url_bytes(s: str) -> bytes:
    if "," in s and s.startswith("data:"):
        s = s.split(",", 1)[1]
    return base64.b64decode(s)


def _human(n: int) -> str:
    for unit in ("bytes", "KB", "MB", "GB"):
        if n < 1024 or unit == "GB":
            return f"{n:.0f} {unit}" if unit == "bytes" else f"{n:.1f} {unit}"
        n /= 1024
    return str(n)


class App:
    def __init__(self):
        self.sessions: dict[str, session.Session] = {}
        self.order: list[str] = []
        self.active: str | None = None
        self.token = secrets.token_urlsafe(24)
        self.port = 0
        self.window = None
        self.quitting = False
        self._events: list[dict] = []
        self._event_seq = 0
        self._cond = threading.Condition()
        self.pending: list[dict] = []   # events raised before the UI first asked for state
        self.ui_connected = False
        self.ui_busy = False            # an editor / drawing is open in the UI
        self.lock = threading.RLock()   # guards sessions / order / active (many request threads)

    # ---------------------------------------------------------------- events (long poll)
    def push(self, ev: dict) -> None:
        with self._cond:
            self._event_seq += 1
            ev = dict(ev, seq=self._event_seq)
            self._events.append(ev)
            self._events = self._events[-100:]
            self._cond.notify_all()

    def wait_events(self, since: int, timeout: float = 25) -> list[dict]:
        end = time.time() + timeout
        with self._cond:
            while True:
                out = [e for e in self._events if e["seq"] > since]
                if out or self.quitting:
                    return out
                left = end - time.time()
                if left <= 0:
                    return []
                self._cond.wait(left)

    # ---------------------------------------------------------------- sessions
    def add(self, s: session.Session) -> session.Session:
        with self.lock:
            self.sessions[s.id] = s
            self.order.append(s.id)
            self.active = s.id
        return s

    def get(self, sid: str) -> session.Session:
        with self.lock:
            s = self.sessions.get(sid)
        if s is None:
            raise ApiError("That document is no longer open.", 404)
        return s

    def all_sessions(self) -> list[session.Session]:
        with self.lock:
            return [self.sessions[i] for i in self.order if i in self.sessions]

    def find_open(self, path: str) -> session.Session | None:
        norm = os.path.normcase(os.path.abspath(path))
        for s in self.all_sessions():
            if s.path and os.path.normcase(s.path) == norm:
                return s
        return None

    def open_file(self, path: str, password: str | None = None) -> dict:
        path = os.path.abspath(path)
        if not os.path.exists(path):
            raise ApiError(f"File not found: {path}")
        existing = self.find_open(path)
        if existing:
            with self.lock:
                self.active = existing.id
            return {"doc": existing.info(), "already": True}
        ext = os.path.splitext(path)[1].lower()
        if ext in convert.OFFICE_EXTS:
            return self.open_office(path)
        if ext != ".pdf":
            with open(path, "rb") as f:
                head = f.read(5)
            if head != b"%PDF-":
                with ENGINE:
                    doc = pages.open_any(path)
                s = self.add(session.new_session(doc, os.path.splitext(os.path.basename(path))[0] + ".pdf"))
                return {"doc": s.info(), "converted": True}
        try:
            s = session.open_path(path, password)
        except NeedPassword:
            return {"need_password": True, "path": path, "name": os.path.basename(path)}
        except BadPassword:
            return {"need_password": True, "bad": True, "path": path, "name": os.path.basename(path)}
        self.add(s)
        return {"doc": s.info()}

    def open_office(self, path: str) -> dict:
        tmp = os.path.join(paths.cache_dir(), f"office-{secrets.token_hex(4)}.pdf")
        convert.office_to_pdf(path, tmp)
        try:
            with open(tmp, "rb") as f:
                data = f.read()
        finally:
            try:
                os.remove(tmp)
            except OSError:
                pass
        s = session.open_bytes(data, os.path.splitext(os.path.basename(path))[0] + ".pdf")
        s.saved_state = -1
        s.suggest_dir = os.path.dirname(path)
        self.add(s)
        return {"doc": s.info(), "converted": True}

    def notify(self, ev: dict) -> None:
        """Push to the UI — or keep it for the UI's first state request at start-up."""
        if self.ui_connected:
            self.push(ev)
        else:
            self.pending.append(ev)

    def state(self) -> dict:
        st = paths.load_settings()
        recent = [dict(r, exists=os.path.exists(r["path"])) for r in st.get("recent", [])]
        pending, self.pending = self.pending, []
        self.ui_connected = True
        return {"docs": [x.info() for x in self.all_sessions()], "active": self.active,
                "recent": recent, "settings": {k: v for k, v in st.items() if k != "recent"}, "version": __version__,
                "seq": self._event_seq, "word": convert.office_available("word"), "pending": pending}

    # ---------------------------------------------------------------- native dialogs
    def _dialog(self, kind: str, **kw):
        if self.window is None:
            raise ApiError("File dialogs need the desktop window.", 409)
        import webview
        t = {"open": webview.FileDialog.OPEN, "save": webview.FileDialog.SAVE, "folder": webview.FileDialog.FOLDER}[kind]
        res = self.window.create_file_dialog(t, **kw)
        if not res:
            return None
        if isinstance(res, str):
            return [res]
        return list(res)

    def ask_open(self, types=OPEN_TYPES, multiple=True, directory=""):
        return self._dialog("open", allow_multiple=multiple, file_types=types, directory=directory) or []

    def ask_save(self, filename: str, types=PDF_TYPES, directory=""):
        r = self._dialog("save", save_filename=filename, file_types=types, directory=directory)
        if not r:
            return None
        path = r[0]
        want = os.path.splitext(filename)[1]
        if want and not path.lower().endswith(want.lower()):
            path += want
        return path

    def ask_folder(self, directory=""):
        r = self._dialog("folder", directory=directory)
        return r[0] if r else None

    def default_dir(self, s: session.Session) -> str:
        if s.path:
            return os.path.dirname(s.path)
        return getattr(s, "suggest_dir", "") or os.path.join(os.path.expanduser("~"), "Documents")


# ======================================================================== routing
ROUTES: list[tuple[str, re.Pattern, callable]] = []


def route(method: str, pattern: str):
    rx = re.compile("^" + re.sub(r"<(\w+)>", r"(?P<\1>[^/]+)", pattern) + "$")

    def deco(fn):
        ROUTES.append((method, rx, fn))
        return fn
    return deco


def _pno(s: session.Session, v) -> int:
    p = int(v)
    with ENGINE:  # undo/redo swap the document object
        count = s.doc.page_count
    if not 0 <= p < count:
        raise ApiError("Page out of range.")
    return p


def _pages_arg(s, body) -> list[int]:
    ps = body.get("pages")
    if ps is None:
        with ENGINE:
            return list(range(s.doc.page_count))
    return [_pno(s, p) for p in ps]


def _unique(path: str) -> str:
    """'a.pdf' -> 'a (2).pdf' if a.pdf exists, so batch outputs never overwrite files."""
    base, ext = os.path.splitext(path)
    n = 2
    while os.path.exists(path):
        path = f"{base} ({n}){ext}"
        n += 1
    return path


def _fonts_ready() -> None:
    # make sure the font index is loaded *before* taking the engine lock
    FontIndex.get()


# ---------------------------------------------------------------- app level
@route("GET", "/api/state")
def api_state(app, q, body, **kw):
    return app.state()


@route("GET", "/api/events")
def api_events(app, q, body, **kw):
    since = int(q.get("since", ["0"])[0])
    return {"events": app.wait_events(since, 20)}


@route("POST", "/api/open")
def api_open(app, q, body, **kw):
    res = app.open_file(body["path"], body.get("password"))
    return res


@route("POST", "/api/open-dialog")
def api_open_dialog(app, q, body, **kw):
    files = app.ask_open()
    results = []
    for f in files:
        try:
            results.append(app.open_file(f))
        except Exception as e:
            results.append({"error": str(e), "path": f})
    return {"results": results, "cancelled": not files}


@route("POST", "/api/upload")
def api_upload(app, q, body, raw=None, **kw):
    name = q.get("name", ["document.pdf"])[0]
    password = q.get("password", [None])[0]
    if raw is None:
        raise ApiError("no data")
    if raw[:5] == b"%PDF-":
        try:
            s = session.open_bytes(raw, name, None, password)
        except NeedPassword:
            return {"need_password": True, "name": name, "upload": True}
        except BadPassword:
            return {"need_password": True, "bad": True, "name": name, "upload": True}
        s.saved_state = -1
    else:
        with ENGINE:
            doc = pages.open_any(raw, name)
        s = session.new_session(doc, os.path.splitext(name)[0] + ".pdf")
    app.add(s)
    return {"doc": s.info()}


@route("POST", "/api/images-to-pdf")
def api_images_to_pdf(app, q, body, **kw):
    items = body.get("paths")
    if not items:
        items = app.ask_open(IMAGE_TYPES, True)
    if not items:
        return {"cancelled": True}
    with ENGINE:
        doc = convert.images_to_pdf(items, body.get("size", "letter"), float(body.get("margin", 18)))
    base = os.path.splitext(os.path.basename(items[0] if isinstance(items[0], str) else "Images"))[0]
    s = session.new_session(doc, f"{base}.pdf")
    if isinstance(items[0], str):
        s.suggest_dir = os.path.dirname(items[0])
    app.add(s)
    return {"doc": s.info()}


@route("POST", "/api/office-to-pdf")
def api_office_to_pdf(app, q, body, **kw):
    path = body.get("path")
    if not path:
        got = app.ask_open(("Office documents (*.docx;*.doc;*.rtf;*.odt;*.xlsx;*.xls;*.csv;*.pptx;*.ppt)",), False)
        if not got:
            return {"cancelled": True}
        path = got[0]
    return app.open_office(path)


@route("POST", "/api/merge")
def api_merge(app, q, body, **kw):
    files = body.get("paths") or app.ask_open(("PDF files (*.pdf)", "Images (*.png;*.jpg;*.jpeg;*.tif;*.tiff)"), True)
    if not files:
        return {"cancelled": True}
    with ENGINE:
        out = fitz.open()
        for f in files:
            src = pages.open_any(f)
            if src.needs_pass:
                raise ApiError(f"{os.path.basename(f)} is password protected — open it first and save a copy without the password.")
            out.insert_pdf(src)
    s = session.new_session(out, "Merged.pdf")
    s.suggest_dir = os.path.dirname(files[0])
    app.add(s)
    return {"doc": s.info()}


@route("GET", "/api/fonts")
def api_fonts(app, q, body, **kw):
    fi = FontIndex.get()
    return {"families": fi.families()}


@route("POST", "/api/settings")
def api_settings(app, q, body, **kw):
    st = paths.load_settings()
    for k in ("theme", "zoom", "show_thumbs"):
        if k in body:
            st[k] = body[k]
    paths.save_settings(st)
    return {"ok": True}


@route("POST", "/api/recent/remove")
def api_recent_remove(app, q, body, **kw):
    st = paths.load_settings()
    st["recent"] = [r for r in st.get("recent", []) if r.get("path") != body.get("path")]
    paths.save_settings(st)
    return {"ok": True}


@route("POST", "/api/reveal")
def api_reveal(app, q, body, **kw):
    p = body.get("path") or ""
    if body.get("folder") == "backups":
        os.startfile(paths.backups_dir())
        return {"ok": True}
    if not os.path.exists(p):
        raise ApiError("That file no longer exists.")
    explorer = os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "explorer.exe")
    subprocess.Popen([explorer, "/select,", os.path.normpath(p)])
    return {"ok": True}


@route("POST", "/api/title")
def api_title(app, q, body, **kw):
    if app.window is not None:
        title = body.get("title") or "Folio"

        def set_title():
            try:
                app.window.set_title(title)
            except Exception:
                pass
        threading.Thread(target=set_title, daemon=True).start()
    return {"ok": True}


@route("POST", "/api/quit")
def api_quit(app, q, body, **kw):
    app.quitting = True
    if app.window is not None:
        threading.Thread(target=app.window.destroy, daemon=True).start()
    return {"ok": True}


# ---------------------------------------------------------------- signatures
def _sig_list():
    d = paths.signatures_dir()
    out = []
    for f in sorted(os.listdir(d), key=lambda n: os.path.getmtime(os.path.join(d, n)), reverse=True):
        if f.endswith(".png"):
            sid, _ = os.path.splitext(f)
            kind = "initials" if sid.startswith("ini-") else "signature"
            out.append({"id": sid, "kind": kind, "url": f"/sig/{sid}.png?m={int(os.path.getmtime(os.path.join(d, f)))}"})
    return out


@route("GET", "/api/signatures")
def api_sigs(app, q, body, **kw):
    return {"items": _sig_list()}


@route("POST", "/api/signatures")
def api_sig_add(app, q, body, **kw):
    data = _data_url_bytes(body["png"])
    with ENGINE:
        pix = fitz.Pixmap(data)  # validates it is an image
        w, h = pix.width, pix.height
        pix = None
    if w < 2 or h < 2:
        raise ApiError("empty signature")
    prefix = "ini-" if body.get("kind") == "initials" else "sig-"
    sid = prefix + secrets.token_hex(5)
    with open(os.path.join(paths.signatures_dir(), sid + ".png"), "wb") as f:
        f.write(data)
    return {"id": sid, "items": _sig_list()}


@route("POST", "/api/signatures/<sig>/delete")
def api_sig_del(app, q, body, sig=None, **kw):
    if not re.fullmatch(r"(sig|ini)-[0-9a-f]+", sig or ""):
        raise ApiError("bad id")
    try:
        os.remove(os.path.join(paths.signatures_dir(), sig + ".png"))
    except OSError:
        pass
    return {"items": _sig_list()}


# ---------------------------------------------------------------- document level
@route("POST", "/api/doc/<sid>/activate")
def api_activate(app, q, body, sid=None, **kw):
    app.get(sid)
    with app.lock:
        app.active = sid
    return {"ok": True}


@route("POST", "/api/doc/<sid>/close")
def api_close(app, q, body, sid=None, **kw):
    with app.lock:
        s = app.sessions.pop(sid, None)
        if sid in app.order:
            idx = app.order.index(sid)
            app.order.remove(sid)
            if app.active == sid:
                app.active = app.order[min(idx, len(app.order) - 1)] if app.order else None
    if s is not None:
        with ENGINE:
            try:
                s.doc.close()
            except Exception:
                pass
    return {"ok": True, "active": app.active}


@route("GET", "/api/doc/<sid>")
def api_doc(app, q, body, sid=None, **kw):
    s = app.get(sid)
    info = s.info()
    if s.notice:
        info["notice"] = s.notice
        s.notice = None
    return info


@route("POST", "/api/doc/<sid>/save")
def api_save(app, q, body, sid=None, **kw):
    s = app.get(sid)
    path = body.get("path")
    if body.get("as") or (not path and not s.path):
        path = app.ask_save(s.name if s.name.lower().endswith(".pdf") else s.name + ".pdf", PDF_TYPES, app.default_dir(s))
        if not path:
            return {"cancelled": True}
    other = app.find_open(path) if path else None
    if other is not None and other is not s:
        raise ApiError("That file is open in another tab — close it first or pick another name.")
    saved = s.save(path)
    return {"doc": s.info(), "path": saved, "size": os.path.getsize(saved)}


@route("POST", "/api/doc/<sid>/undo")
def api_undo(app, q, body, sid=None, **kw):
    s = app.get(sid)
    label = s.do_undo()
    return {"doc": s.info(), "label": label}


@route("POST", "/api/doc/<sid>/redo")
def api_redo(app, q, body, sid=None, **kw):
    s = app.get(sid)
    label = s.do_redo()
    return {"doc": s.info(), "label": label}


@route("GET", "/api/doc/<sid>/size")
def api_size(app, q, body, sid=None, **kw):
    s = app.get(sid)
    return {"size": len(s.tobytes())}


# ---------------------------------------------------------------- page content
@route("GET", "/api/doc/<sid>/page/<n>/text")
def api_text(app, q, body, sid=None, n=None, **kw):
    s = app.get(sid)
    return {"lines": s.text_lines(_pno(s, n))}


@route("GET", "/api/doc/<sid>/page/<n>/layer")
def api_layer(app, q, body, sid=None, n=None, **kw):
    s = app.get(sid)
    p = _pno(s, n)
    with ENGINE:
        page = s.doc[p]
        objs = [objects.object_json(page, m) for _x, m in objects.object_streams(s.doc, page)]
        return {"objects": objs, "annots": annots.list_annots(s.doc, page), "fields": forms.page_fields(s.doc, page)}


@route("POST", "/api/doc/<sid>/page/<n>/edit-line")
def api_edit_line(app, q, body, sid=None, n=None, **kw):
    s = app.get(sid)
    p = _pno(s, n)
    _fonts_ready()
    def fn(doc):
        rep = text.edit_line(doc, doc[p], body["ref"], body["text"])
        if not rep.get("changed"):
            raise session.NoChange(rep)  # nothing changed: no history step, redo kept
        return rep
    rep = s.mutate("Edit text", fn, [p])
    return {"doc": s.info(), "report": rep}


@route("GET", "/api/doc/<sid>/search")
def api_search(app, q, body, sid=None, **kw):
    s = app.get(sid)
    query = q.get("q", [""])[0]
    case = q.get("case", ["0"])[0] == "1"
    whole = q.get("whole", ["0"])[0] == "1"
    hits = []
    with ENGINE:
        for p in range(s.doc.page_count):
            per_line: dict[str, int] = {}
            for h in text.search_page(s.doc, s.doc[p], query, case=case, whole=whole):
                idx = per_line.get(h["line"], 0)
                per_line[h["line"]] = idx + 1
                hits.append({"page": p, "rect": h["rect"], "line": h["line"], "idx": idx, "text": h["text"]})
            if len(hits) >= 5000:  # the UI shows "5000+"; no need to read the remaining pages
                break
    return {"hits": hits[:5000]}


@route("POST", "/api/doc/<sid>/replace")
def api_replace(app, q, body, sid=None, **kw):
    s = app.get(sid)
    query, repl = body.get("q", ""), body.get("r", "")
    if not query:
        raise ApiError("Type something to find.")
    case, whole = bool(body.get("case")), bool(body.get("whole"))
    if body.get("one"):
        p = _pno(s, body["page"])
        _fonts_ready()

        def one(doc):
            c = text.replace_on_page(doc, doc[p], query, repl, case, whole,
                                     limit_line=body.get("line"), limit_index=int(body.get("idx", 0)))
            if not c:
                raise session.NoChange(0)
            return c
        n = s.mutate("Replace", one, [p])
        return {"doc": s.info(), "count": n}

    def fn(doc):
        total, touched = 0, []
        for p in range(doc.page_count):
            c = text.replace_on_page(doc, doc[p], query, repl, case, whole)
            if c:
                total += c
                touched.append(p)
        if not total:
            raise session.NoChange((0, []))
        return total, touched
    _fonts_ready()
    total, touched = s.mutate("Replace all", fn, None)
    return {"doc": s.info(), "count": total, "pages": touched}


# ---------------------------------------------------------------- objects
@route("POST", "/api/doc/<sid>/page/<n>/object")
def api_obj_add(app, q, body, sid=None, n=None, **kw):
    s = app.get(sid)
    p = _pno(s, n)
    spec = dict(body["spec"])
    data = None
    if spec.get("type") == "image":
        if body.get("image"):
            data = _data_url_bytes(body["image"])
        elif body.get("signature"):
            sig = body["signature"]
            if not re.fullmatch(r"(sig|ini)-[0-9a-f]+", sig):
                raise ApiError("bad signature id")
            with open(os.path.join(paths.signatures_dir(), sig + ".png"), "rb") as f:
                data = f.read()
            spec["sig"] = True
        elif body.get("path"):
            data, _w, _h = convert._image_bytes(body["path"])
        else:
            raise ApiError("no image data")
    rect = body["rect"]

    def fn(doc):
        page = doc[p]
        spec.update(objects.new_frame(page, rect))
        if spec.get("type") == "text":
            spec["w"] = body.get("wrap")
        m = objects.add_object(doc, page, spec, data)
        return objects.object_json(page, m)
    label = {"text": "Add text", "image": "Add signature" if spec.get("sig") else "Add image"}.get(spec.get("type"), "Add shape")
    _fonts_ready()
    obj = s.mutate(label, fn, [p])
    return {"doc": s.info(), "object": obj}


@route("POST", "/api/doc/<sid>/page/<n>/object/<oid>")
def api_obj_update(app, q, body, sid=None, n=None, oid=None, **kw):
    s = app.get(sid)
    p = _pno(s, n)
    changes = dict(body.get("changes") or {})

    def fn(doc):
        page = doc[p]
        if changes.get("type") == "text" and not str(changes.get("text", "x")).strip():
            objects.delete_object(doc, page, oid)
            return None
        changes.pop("type", None)
        m = objects.update_object(doc, page, oid, changes)
        return objects.object_json(page, m)
    label = "Move" if set(changes) == {"rect"} else "Edit"
    _fonts_ready()
    obj = s.mutate(label, fn, [p])
    return {"doc": s.info(), "object": obj}


@route("POST", "/api/doc/<sid>/page/<n>/object/<oid>/delete")
def api_obj_delete(app, q, body, sid=None, n=None, oid=None, **kw):
    s = app.get(sid)
    p = _pno(s, n)
    s.mutate("Delete", lambda doc: objects.delete_object(doc, doc[p], oid), [p])
    return {"doc": s.info()}


@route("POST", "/api/doc/<sid>/page/<n>/object/<oid>/duplicate")
def api_obj_dup(app, q, body, sid=None, n=None, oid=None, **kw):
    s = app.get(sid)
    p = _pno(s, n)

    def fn(doc):
        page = doc[p]
        _x, m = objects.find_object(doc, page, oid)
        if m is None:
            raise ApiError("object not found")
        spec = {k: v for k, v in m.items() if k not in ("id", "xref", "img")}
        step = geom.vec_from_disp(page, (12, 12))  # 12 pt right and down, as the user sees the page
        spec["o"] = [round(m["o"][0] + step.x, 3), round(m["o"][1] + step.y, 3)]
        img = objects.image_xref_of(doc, page, _x) if m.get("type") == "image" else None
        nm = objects.add_object(doc, page, spec, img_xref=img)
        return objects.object_json(page, nm)
    _fonts_ready()
    obj = s.mutate("Duplicate", fn, [p])
    return {"doc": s.info(), "object": obj}


# ---------------------------------------------------------------- annotations
@route("POST", "/api/doc/<sid>/page/<n>/markup")
def api_markup(app, q, body, sid=None, n=None, **kw):
    s = app.get(sid)
    p = _pno(s, n)
    kind = body.get("kind", "highlight")
    s.mutate({"highlight": "Highlight", "underline": "Underline", "strike": "Strike out"}.get(kind, "Markup"),
             lambda doc: annots.add_markup(doc, doc[p], kind, body["rects"], body.get("color")), [p])
    return {"doc": s.info()}


@route("POST", "/api/doc/<sid>/page/<n>/note")
def api_note(app, q, body, sid=None, n=None, **kw):
    s = app.get(sid)
    p = _pno(s, n)
    x = s.mutate("Add note", lambda doc: annots.add_note(doc, doc[p], body["point"], body.get("text", ""), body.get("color")), [p])
    return {"doc": s.info(), "xref": x}


@route("POST", "/api/doc/<sid>/page/<n>/annot/<x>")
def api_annot_update(app, q, body, sid=None, n=None, x=None, **kw):
    s = app.get(sid)
    p = _pno(s, n)

    def fn(doc):
        if "content" in body:
            annots.update_note(doc, doc[p], int(x), body["content"])
        if "rect" in body:
            annots.move_annot(doc, doc[p], int(x), body["rect"])
    s.mutate("Edit comment", fn, [p])
    return {"doc": s.info()}


@route("POST", "/api/doc/<sid>/page/<n>/annot/<x>/delete")
def api_annot_delete(app, q, body, sid=None, n=None, x=None, **kw):
    s = app.get(sid)
    p = _pno(s, n)
    s.mutate("Delete comment", lambda doc: annots.delete_annot(doc, doc[p], int(x)), [p])
    return {"doc": s.info()}


# ---------------------------------------------------------------- erase / redact
@route("POST", "/api/doc/<sid>/page/<n>/erase")
def api_erase(app, q, body, sid=None, n=None, **kw):
    s = app.get(sid)
    p = _pno(s, n)
    s.mutate("Erase", lambda doc: redact.erase(doc, doc[p], body["rect"], body.get("fill")), [p])
    return {"doc": s.info()}


@route("POST", "/api/doc/<sid>/page/<n>/redact")
def api_redact(app, q, body, sid=None, n=None, **kw):
    s = app.get(sid)
    p = _pno(s, n)
    s.mutate("Redact", lambda doc: redact.redact(doc, doc[p], body["rects"], body.get("color", "#000000")), [p])
    return {"doc": s.info()}


@route("POST", "/api/doc/<sid>/redact-search")
def api_redact_search(app, q, body, sid=None, **kw):
    s = app.get(sid)
    preset = body.get("preset")
    query = redact.PATTERNS.get(preset) if preset else body.get("q", "")
    regex = bool(preset) or bool(body.get("regex"))
    if not query:
        raise ApiError("Type what to redact.")
    if body.get("preview"):
        with ENGINE:
            count, pg, hits = redact.preview_matches(s.doc, query, regex, bool(body.get("case")), bool(body.get("whole")))
        return {"count": count, "pages": pg, "hits": hits[:500]}
    count, pg = s.mutate("Redact matches", lambda doc: redact.redact_matches(doc, query, regex, bool(body.get("case")),
                                                                           bool(body.get("whole"))), None)
    return {"doc": s.info(), "count": count, "pages": pg}


# ---------------------------------------------------------------- forms
@route("POST", "/api/doc/<sid>/page/<n>/field/<x>")
def api_field(app, q, body, sid=None, n=None, x=None, **kw):
    s = app.get(sid)
    p = _pno(s, n)
    others = s.mutate("Fill field", lambda doc: forms.set_field(doc, doc[p], int(x), body.get("value")), [p])
    if others:
        s.touch_pages(others)
    with ENGINE:
        fields = forms.page_fields(s.doc, s.doc[p])
    return {"doc": s.info(), "fields": fields}


@route("POST", "/api/doc/<sid>/flatten")
def api_flatten(app, q, body, sid=None, **kw):
    s = app.get(sid)
    what = body.get("what", "forms")
    s.mutate("Flatten form" if what == "forms" else "Flatten everything",
             forms.flatten if what == "forms" else forms.flatten_all, None)
    return {"doc": s.info()}


# ---------------------------------------------------------------- pages
@route("POST", "/api/doc/<sid>/pages/<op>")
def api_pages(app, q, body, sid=None, op=None, **kw):
    s = app.get(sid)
    if op == "rotate":
        ps = _pages_arg(s, body)
        s.mutate("Rotate pages", lambda doc: pages.rotate(doc, ps, int(body.get("delta", 90))), None)
    elif op == "delete":
        ps = _pages_arg(s, body)
        s.mutate("Delete pages" if len(ps) > 1 else "Delete page", lambda doc: pages.delete(doc, ps), None)
    elif op == "move":
        ps = _pages_arg(s, body)
        res = s.mutate("Move pages", lambda doc: pages.move(doc, ps, int(body["to"])), None)
        return {"doc": s.info(), "pages": res}
    elif op == "duplicate":
        ps = _pages_arg(s, body)
        s.mutate("Duplicate pages", lambda doc: pages.duplicate(doc, ps), None)
    elif op == "blank":
        at = s.mutate("Insert blank page", lambda doc: pages.insert_blank(doc, int(body.get("at", doc.page_count))), None)
        return {"doc": s.info(), "pages": [at]}
    elif op == "insert-file":
        path = body.get("path")
        if not path:
            got = app.ask_open(("PDF and images (*.pdf;*.png;*.jpg;*.jpeg;*.tif;*.tiff;*.bmp)", "All files (*.*)"), False,
                               app.default_dir(s))
            if not got:
                return {"cancelled": True}
            path = got[0]
        ext = os.path.splitext(path)[1].lower()
        office_pdf = None
        if ext in convert.OFFICE_EXTS:
            # Office can take a while: never hold the engine lock while it works
            tmp = os.path.join(paths.cache_dir(), f"ins-{secrets.token_hex(4)}.pdf")
            convert.office_to_pdf(path, tmp)
            with open(tmp, "rb") as f:
                office_pdf = f.read()
            os.remove(tmp)
        with ENGINE:
            if office_pdf is not None:
                src = fitz.open("pdf", office_pdf)
            elif ext in pages.IMAGE_EXTS:
                src = convert.images_to_pdf([path], "letter")
            else:
                src = pages.open_any(path)
            at = int(body.get("at", s.doc.page_count))
        res = s.mutate("Insert pages", lambda doc: pages.insert_doc(doc, src, at), None)
        return {"doc": s.info(), "pages": res}
    elif op == "extract":
        ps = _pages_arg(s, body)
        base = os.path.splitext(s.name)[0]
        label = f"p{ps[0] + 1}" if len(ps) == 1 else f"p{ps[0] + 1}-{ps[-1] + 1}"
        path = body.get("path") or app.ask_save(f"{base} ({label}).pdf", PDF_TYPES, app.default_dir(s))
        if not path:
            return {"cancelled": True}
        with ENGINE:
            data = pages.extract(s.doc, ps)
        with open(path, "wb") as f:
            f.write(data)
        return {"path": path}
    elif op == "split":
        with ENGINE:
            n = s.doc.page_count
        if body.get("mode") == "every":
            groups = pages.split_every(n, int(body.get("k", 1)))
        else:
            groups = pages.parse_ranges(body.get("spec", ""), n)
        folder = body.get("folder") or app.ask_folder(app.default_dir(s))
        if not folder:
            return {"cancelled": True}
        base = os.path.splitext(s.name)[0]
        out = []
        with ENGINE:
            snap = fitz.open("pdf", s.doc.tobytes())
        try:
            for g in groups:
                label = f"p{g[0] + 1}" if len(g) == 1 else f"p{g[0] + 1}-{g[-1] + 1}"
                with ENGINE:
                    data = pages.extract(snap, g)
                path = _unique(os.path.join(folder, f"{base} ({label}).pdf"))
                with open(path, "wb") as f:
                    f.write(data)
                out.append(path)
        finally:
            with ENGINE:
                snap.close()
        return {"files": out, "folder": folder}
    else:
        raise ApiError("unknown page operation")
    return {"doc": s.info()}


# ---------------------------------------------------------------- whole-document tools
@route("POST", "/api/doc/<sid>/compress")
def api_compress(app, q, body, sid=None, **kw):
    s = app.get(sid)
    with ENGINE:
        before = s.tobytes()
        state0 = s.state
    gray = bool(body.get("gray"))
    if body.get("target_mb"):
        target = int(float(body["target_mb"]) * 1024 * 1024)
        out, preset, reached = compress.compress_to(before, target, gray)
    else:
        preset = body.get("preset", "balanced")
        out = compress.compress(before, preset, gray)
        reached = True
    with ENGINE:
        if s.state != state0:
            raise ApiError("The document changed while it was being compressed, so nothing was replaced. "
                           "Run Compress again.", 409)
        if len(out) < len(before):
            s.replace_document("Compress", out)
    return {"doc": s.info(), "before": len(before), "after": min(len(out), len(before)), "preset": preset,
            "reached": reached, "before_h": _human(len(before)), "after_h": _human(min(len(out), len(before)))}


@route("POST", "/api/doc/<sid>/export-images")
def api_export_images(app, q, body, sid=None, **kw):
    s = app.get(sid)
    ps = _pages_arg(s, body)
    folder = body.get("folder") or app.ask_folder(app.default_dir(s))
    if not folder:
        return {"cancelled": True}
    with ENGINE:
        snap = fitz.open("pdf", s.doc.tobytes())  # what the document is now, whatever is edited meanwhile
    files = []
    try:
        for p in ps:
            with ENGINE:
                files += convert.pdf_to_images(snap, [p], folder, os.path.splitext(s.name)[0], body.get("fmt", "png"),
                                               int(body.get("dpi", 150)))
    finally:
        with ENGINE:
            snap.close()
    return {"files": files, "folder": folder}


@route("POST", "/api/doc/<sid>/to-word")
def api_to_word(app, q, body, sid=None, **kw):
    s = app.get(sid)
    base = os.path.splitext(s.name)[0]
    path = body.get("path") or app.ask_save(base + ".docx", ("Word document (*.docx)",), app.default_dir(s))
    if not path:
        return {"cancelled": True}
    data = s.tobytes()
    convert.pdf_to_word(data, path)
    return {"path": path}


@route("POST", "/api/doc/<sid>/protect")
def api_protect(app, q, body, sid=None, **kw):
    s = app.get(sid)
    pw = body.get("password") or ""
    if body.get("remove"):
        if not s.protect:
            return {"doc": s.info()}
        s.protect = None
    else:
        if len(pw) < 1:
            raise ApiError("Enter a password.")
        perms = fitz.PDF_PERM_ACCESSIBILITY | fitz.PDF_PERM_PRINT | fitz.PDF_PERM_PRINT_HQ
        if body.get("allow_copy", True):
            perms |= fitz.PDF_PERM_COPY
        if body.get("allow_edit", True):
            perms |= fitz.PDF_PERM_MODIFY | fitz.PDF_PERM_ANNOTATE | fitz.PDF_PERM_FORM | fitz.PDF_PERM_ASSEMBLE
        s.protect = {"user_pw": pw, "owner_pw": body.get("owner") or pw, "permissions": perms}
    s.protect_dirty = True  # not part of the page content, so it's tracked on its own
    return {"doc": s.info()}


@route("POST", "/api/doc/<sid>/metadata")
def api_metadata(app, q, body, sid=None, **kw):
    s = app.get(sid)

    def fn(doc):
        md = dict(doc.metadata or {})
        for k in ("title", "author", "subject", "keywords"):
            if k in body:
                md[k] = body[k]
        doc.set_metadata(md)
    s.mutate("Edit properties", fn, [])
    return {"doc": s.info()}


@route("POST", "/api/doc/<sid>/scrub")
def api_scrub(app, q, body, sid=None, **kw):
    s = app.get(sid)
    s.mutate("Remove hidden data", redact.scrub_hidden, None)
    return {"doc": s.info()}


@route("POST", "/api/doc/<sid>/page-numbers")
def api_page_numbers(app, q, body, sid=None, **kw):
    s = app.get(sid)
    ps = _pages_arg(s, body)
    _fonts_ready()
    s.mutate("Add page numbers", lambda doc: stamp.page_numbers(
        doc, ps, fmt=body.get("fmt", "Page {n} of {N}"), position=body.get("position", "bottom-center"),
        size=float(body.get("size", 10)), start=int(body.get("start", 1)), family=body.get("family", "Arial"),
        color=body.get("color", "#000000")), None)
    return {"doc": s.info()}


@route("POST", "/api/doc/<sid>/watermark")
def api_watermark(app, q, body, sid=None, **kw):
    s = app.get(sid)
    ps = _pages_arg(s, body)
    if not (body.get("text") or "").strip():
        raise ApiError("Type the watermark text.")
    _fonts_ready()
    s.mutate("Add watermark", lambda doc: stamp.watermark(
        doc, ps, body["text"], size=float(body.get("size", 64)), color=body.get("color", "#888888"),
        opacity=float(body.get("opacity", 0.22)), angle=float(body.get("angle", 45))), None)
    return {"doc": s.info()}


@route("POST", "/api/external-open")
def api_external_open(app, q, body, **kw):
    """Files handed over by a second launch. Answer immediately (that launch is waiting)
    and open them in the background."""
    files = list(body.get("paths", []))

    def work():
        results = []
        for p in files:
            try:
                r = app.open_file(p)
            except Exception as e:
                r = {"error": str(e), "path": p}
            results.append(r)
        app.notify({"type": "external-open", "results": results})
    threading.Thread(target=work, daemon=True).start()
    if app.window is not None:
        threading.Thread(target=raise_window, daemon=True).start()
    return {"ok": True}


@route("POST", "/api/ui-state")
def api_ui_state(app, q, body, **kw):
    app.ui_busy = bool(body.get("busy"))
    return {"ok": True}


def raise_window() -> None:
    """Bring Folio's window to the front with plain Win32 calls.

    (pywebview's `on_top` setter touches the form from a non-UI thread, which can
    deadlock the whole process; ctypes calls release the interpreter lock.)"""
    try:
        import ctypes
        from ctypes import wintypes
        user32 = ctypes.windll.user32
        pid = os.getpid()
        found = []

        @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
        def cb(hwnd, _lp):
            owner = wintypes.DWORD()
            user32.GetWindowThreadProcessId(hwnd, ctypes.byref(owner))
            if owner.value == pid and user32.IsWindowVisible(hwnd) and user32.GetWindowTextLengthW(hwnd) > 0:
                found.append(hwnd)
            return True
        user32.EnumWindows(cb, 0)
        for hwnd in found:
            if user32.IsIconic(hwnd):
                user32.ShowWindow(hwnd, 9)  # SW_RESTORE
            user32.SetForegroundWindow(hwnd)
            break
    except Exception:
        log.exception("could not raise window")


# ======================================================================== HTTP plumbing
class Handler(http.server.BaseHTTPRequestHandler):
    server_version = "Folio"
    protocol_version = "HTTP/1.1"
    app: App = None  # set by make_server
    ui_root: str = ""

    def log_message(self, fmt, *args):
        pass

    # -------------------------------------------------- security gate
    def _authorized(self, allow_query_token=False) -> bool:
        host = (self.headers.get("Host") or "").lower()
        if host not in (f"127.0.0.1:{self.app.port}", f"localhost:{self.app.port}"):
            return False
        tok = self.app.token
        cookie = self.headers.get("Cookie") or ""
        for part in cookie.split(";"):
            k, _, v = part.strip().partition("=")
            if k == "folio" and secrets.compare_digest(v.encode(), tok.encode()):
                return True
        hdr = self.headers.get("X-Folio-Token")
        if hdr and secrets.compare_digest(hdr.encode(), tok.encode()):
            return True
        return False

    def _send(self, status, body: bytes, ctype: str, headers: dict | None = None):
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("X-Content-Type-Options", "nosniff")
        for k, v in (headers or {}).items():
            self.send_header(k, v)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def _json(self, status, obj):
        self._send(status, json.dumps(obj, ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8",
                   {"Cache-Control": "no-store"})

    def do_GET(self):
        self._dispatch("GET")

    def do_POST(self):
        self._dispatch("POST")

    def _dispatch(self, method):
        url = urllib.parse.urlsplit(self.path)
        q = urllib.parse.parse_qs(url.query)
        path = url.path
        try:
            if method == "GET" and path in ("/", "/index.html"):
                return self._index(q)
            if not self._authorized():
                return self._send(403, b"forbidden", "text/plain")
            if method == "GET" and path.startswith("/ui/"):
                return self._static(path[4:])
            if method == "GET" and path.startswith("/r/"):
                return self._render(path, q)
            if method == "GET" and path.startswith("/o/"):
                return self._objimg(path, q)
            if method == "GET" and path.startswith("/sig/"):
                return self._sig(path)
            if method == "GET" and path == "/font":
                return self._font(q)
            if method == "POST" and self.headers.get("X-Folio") != "1":
                return self._send(403, b"missing header", "text/plain")
            for m, rx, fn in ROUTES:
                if m != method:
                    continue
                mm = rx.match(path)
                if not mm:
                    continue
                body, raw = {}, None
                length = int(self.headers.get("Content-Length") or 0)
                if length:
                    data = self.rfile.read(length)
                    if (self.headers.get("Content-Type") or "").startswith("application/json"):
                        body = json.loads(data.decode("utf-8") or "{}")
                    else:
                        raw = data
                res = fn(self.app, q, body, raw=raw, **mm.groupdict())
                return self._json(200, res)
            return self._send(404, b"not found", "text/plain")
        except ApiError as e:
            self._json(e.status, dict({"error": str(e)}, **e.extra))
        except (ValueError, LookupError, PermissionError, FileNotFoundError, RuntimeError) as e:
            log.info("request failed: %s %s: %s", method, path, e)
            self._json(400, {"error": str(e) or e.__class__.__name__})
        except re.error as e:
            self._json(400, {"error": f"That search pattern isn't valid: {e}"})
        except TypeError as e:
            log.warning("bad request %s %s\n%s", method, path, traceback.format_exc())
            self._json(400, {"error": f"Folio couldn't use that request ({e})."})
        except (ConnectionError, BrokenPipeError):
            pass
        except Exception as e:  # pragma: no cover
            log.error("error in %s %s\n%s", method, path, traceback.format_exc())
            try:
                self._json(500, {"error": f"Something went wrong: {e}"})
            except Exception:
                pass

    # -------------------------------------------------- static & images
    def _index(self, q):
        tok = q.get("t", [None])[0]
        authorized = self._authorized() or (tok is not None and secrets.compare_digest(tok.encode(), self.app.token.encode()))
        host = (self.headers.get("Host") or "").lower()
        if not authorized or host not in (f"127.0.0.1:{self.app.port}", f"localhost:{self.app.port}"):
            return self._send(403, b"forbidden", "text/plain")
        with open(os.path.join(self.ui_root, "index.html"), "rb") as f:
            body = f.read()
        self._send(200, body, "text/html; charset=utf-8", {
            "Set-Cookie": f"folio={self.app.token}; Path=/; HttpOnly; SameSite=Strict",
            "Cache-Control": "no-store",
            "Content-Security-Policy": "default-src 'self'; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; "
                                       "font-src 'self' data:; script-src 'self'; connect-src 'self'; object-src 'none'; "
                                       "base-uri 'none'; frame-ancestors 'none'",
        })

    def _static(self, rel):
        rel = urllib.parse.unquote(rel)
        full = os.path.normpath(os.path.join(self.ui_root, rel))
        if not full.startswith(os.path.normpath(self.ui_root) + os.sep) or not os.path.isfile(full):
            return self._send(404, b"not found", "text/plain")
        ctype = mimetypes.guess_type(full)[0] or "application/octet-stream"
        if full.endswith(".js"):
            ctype = "text/javascript"
        with open(full, "rb") as f:
            body = f.read()
        self._send(200, body, ctype + ("; charset=utf-8" if ctype.startswith("text") else ""), {"Cache-Control": "no-cache"})

    def _render(self, path, q):
        # /r/<sid>/<pno>
        parts = path.split("/")
        s = self.app.get(parts[2])
        pno = _pno(s, parts[3])
        scale = float(q.get("s", ["1"])[0])
        hide = tuple(h for h in q.get("hide", [""])[0].split(",") if h)
        annots_on = q.get("annots", ["1"])[0] != "0"
        data, ctype = s.render(pno, scale, hide, annots_on)
        self._send(200, data, ctype, {"Cache-Control": "private, max-age=31536000, immutable"})

    def _objimg(self, path, q):
        parts = path.split("/")
        s = self.app.get(parts[2])
        pno = _pno(s, parts[3])
        data = s.render_object(pno, parts[4], float(q.get("s", ["1"])[0]))
        self._send(200, data, "image/png", {"Cache-Control": "private, max-age=31536000, immutable"})

    def _sig(self, path):
        sid = os.path.splitext(path.split("/")[-1])[0]
        if not re.fullmatch(r"(sig|ini)-[0-9a-f]+", sid):
            return self._send(404, b"not found", "text/plain")
        p = os.path.join(paths.signatures_dir(), sid + ".png")
        if not os.path.exists(p):
            return self._send(404, b"not found", "text/plain")
        with open(p, "rb") as f:
            self._send(200, f.read(), "image/png", {"Cache-Control": "no-cache"})

    def _font(self, q):
        key = q.get("key", [""])[0]
        fi = FontIndex.get()
        face = fi.by_key.get(key)
        if face is None:
            return self._send(404, b"not found", "text/plain")
        data = fi.subset(face, "".join(chr(c) for c in range(32, 127)) + "".join(chr(c) for c in range(160, 384))
                         + "\u2013\u2014\u2018\u2019\u201c\u201d\u2022\u2026\u20ac\u2122")
        self._send(200, data, "font/ttf", {"Cache-Control": "private, max-age=86400"})


class _Server(http.server.ThreadingHTTPServer):
    daemon_threads = True

    def handle_error(self, request, client_address):
        # The window closing mid-request (e.g. the event long-poll) is normal: stay quiet.
        # Anything else goes to Folio's log, never to a console (the app has none).
        import sys
        exc = sys.exc_info()[1]
        if isinstance(exc, (ConnectionError, TimeoutError)):
            return
        log.error("request from %s failed\n%s", client_address, traceback.format_exc())


def make_server(app: App, port: int = 0) -> http.server.ThreadingHTTPServer:
    Handler.app = app
    Handler.ui_root = paths.resource_path("ui")
    srv = _Server(("127.0.0.1", port), Handler)
    app.port = srv.server_address[1]
    return srv

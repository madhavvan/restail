"""Folio — a local, offline PDF editor."""

__version__ = "1.0.1"
APP_NAME = "Folio"

"""Folio in the browser.

The editor runs Folio's own engine and HTTP routes (folio/, copied unchanged from the
desktop app) inside Pyodide, in a Web Worker. This module adapts the handful of places
that assume a desktop:

  threads    Pyodide can't start one, so the font index loads synchronously.
  fonts      a browser has no installed fonts to borrow, so the editor ships
             metric-compatible open fonts (Carlito for Calibri, Caladea for Cambria,
             Arimo/Tinos/Cousine for Arial/Times/Courier, Gelasio for Georgia) in /fonts.
  files      native dialogs become uploads (staged into the virtual file system) and
             downloads (files a route would write to disk come back as bytes).
  desktop    no Office, no Explorer, no window: those routes say so instead.

handle() is the whole interface: one request in, (status, content type, body bytes,
meta) out — the same answers the desktop server sends over HTTP.
"""

from __future__ import annotations

import base64
import json
import logging
import os
import re
import secrets
import shutil
import traceback
import urllib.parse
import zipfile
import io

os.environ.setdefault("FOLIO_DATA_DIR", "/folio_data")
FONT_DIR = "/fonts"
STAGE_DIR = "/tmp/folio-in"
OUT_DIR = "/tmp/folio-out"

import pymupdf as fitz  # noqa: E402

from folio import paths, server  # noqa: E402
from folio.engine import convert, fonts, pages, session, text  # noqa: E402
from folio.engine.session import ENGINE  # noqa: E402
from folio.server import ApiError  # noqa: E402

log = logging.getLogger("folio.web")

# ======================================================================== fonts
# The open look-alikes, by the PDF family names they stand in for. Desktop entries keep
# their order after these (on Windows the real font wins before an alias is consulted).
WEB_ALIASES = {
    "calibri": ["carlito"], "lato": ["carlito"],
    "cambria": ["caladea"],
    "arial": ["arimo"], "helvetica": ["arimo"], "helveticaneue": ["arimo"], "helveticaneuelt": ["arimo"],
    "liberationsans": ["arimo"], "nimbussans": ["arimo"], "nimbussansl": ["arimo"], "arimo": ["arimo"],
    "segoeui": ["arimo"], "verdana": ["arimo"], "tahoma": ["arimo"], "roboto": ["arimo"], "opensans": ["arimo"],
    "inter": ["arimo"], "sourcesanspro": ["arimo"], "sourcesans3": ["arimo"], "notosans": ["arimo"],
    "systemui": ["arimo"], "sfprotext": ["arimo"], "sfprodisplay": ["arimo"], "lucidagrande": ["arimo"],
    "timesnewroman": ["tinos"], "times": ["tinos"], "timesroman": ["tinos"], "liberationserif": ["tinos"],
    "nimbusroman": ["tinos"], "nimbusromanno9l": ["tinos"], "garamond": ["tinos"], "palatino": ["tinos"],
    "palatinolinotype": ["tinos"], "bookantiqua": ["tinos"],
    "couriernew": ["cousine"], "courier": ["cousine"], "liberationmono": ["cousine"], "nimbusmono": ["cousine"],
    "consolas": ["cousine"],
    "georgia": ["gelasio"], "georgiapro": ["gelasio"],
}
for _k, _v in WEB_ALIASES.items():
    fonts.ALIASES[_k] = _v + [a for a in fonts.ALIASES.get(_k, []) if a not in _v]
fonts.GENERIC.update({
    "sans": ["arimo", "carlito"] + fonts.GENERIC["sans"],
    "serif": ["tinos", "caladea", "gelasio"] + fonts.GENERIC["serif"],
    "mono": ["cousine"] + fonts.GENERIC["mono"],
})
fonts.COVERAGE_FALLBACK[:0] = ["arimo", "tinos", "carlito", "caladea", "gelasio", "cousine"]
fonts.font_dirs = lambda: [FONT_DIR] if os.path.isdir(FONT_DIR) else []

_read_faces = fonts._read_faces


def _read_faces_web(path, is_system):
    # Nothing is installed in a browser: the editor serves every face to the page itself.
    return _read_faces(path, False)


fonts._read_faces = _read_faces_web


def _font_index_get(cls, wait: bool = True):
    if cls._instance is None:
        cls._instance = fonts.FontIndex()
        cls._instance._load()  # no thread: build (or read the cached index) right now
    return cls._instance


fonts.FontIndex.get = classmethod(_font_index_get)

_face_for_family = fonts.FontIndex.face_for_family


def _face_for_family_web(self, family, bold=False, italic=False):
    """A text box in "Arial" gets Arimo, "Times New Roman" gets Tinos, and so on."""
    f = _face_for_family(self, family, bold, italic)
    if f is None:
        for alias in fonts.ALIASES.get(fonts.norm(family), []):
            f = _face_for_family(self, alias, bold, italic)
            if f is not None:
                break
    return f


fonts.FontIndex.face_for_family = _face_for_family_web

_choose_font = text.choose_font


def _choose_font_web(*a, **kw):
    c = _choose_font(*a, **kw)
    if c.kind == "system" and c.label:
        c.label = (c.label.replace("(installed, replaces", "(look-alike for")
                   .replace("(installed)", "(editor font)"))
    return c


text.choose_font = _choose_font_web


def prepare_fonts() -> int:
    """Pin the unpacked fonts' timestamps so the cached index stays valid between visits,
    then load the index. Returns the number of faces."""
    if os.path.isdir(FONT_DIR):
        for name in os.listdir(FONT_DIR):
            try:
                os.utime(os.path.join(FONT_DIR, name), (1, 1))
            except OSError:
                pass
    fonts.FontIndex._instance = None
    return len(fonts.FontIndex.get().faces)


# ======================================================================== desktop-only parts
convert.office_available = lambda kind="word": False

_image_bytes = convert._image_bytes


def _image_bytes_web(path_or_bytes, name=""):
    try:
        import PIL  # noqa: F401  (the worker loads Pillow before routes that convert images)
    except ImportError:
        raw = path_or_bytes if isinstance(path_or_bytes, (bytes, bytearray)) else open(path_or_bytes, "rb").read()
        pix = fitz.Pixmap(raw)
        return raw, pix.width, pix.height
    return _image_bytes(path_or_bytes, name)


convert._image_bytes = _image_bytes_web


def _sig_list_web():
    """Saved signatures as data URLs: the page shows them without asking the engine again."""
    d = paths.signatures_dir()
    out = []
    for f in sorted(os.listdir(d), key=lambda n: os.path.getmtime(os.path.join(d, n)), reverse=True):
        if f.endswith(".png"):
            sid, _ = os.path.splitext(f)
            with open(os.path.join(d, f), "rb") as fh:
                url = "data:image/png;base64," + base64.b64encode(fh.read()).decode("ascii")
            out.append({"id": sid, "kind": "initials" if sid.startswith("ini-") else "signature", "url": url})
    return out


server._sig_list = _sig_list_web

APP = server.App()
APP.wait_events = lambda since, timeout=0: [e for e in APP._events if e["seq"] > since]

# Files in /folio_data (signatures, settings, the font index) live in IndexedDB; the
# worker writes them back after a request that changed them.
_fs_dirty = False


def take_fs_dirty() -> bool:
    global _fs_dirty
    d, _fs_dirty = _fs_dirty, False
    return d


# ======================================================================== web routes
class Binary:
    """A route result that is a file, not JSON."""

    def __init__(self, data: bytes, ctype: str, name: str | None = None, meta: dict | None = None):
        self.data, self.ctype, self.name, self.meta = data, ctype, name, meta or {}


WEB_ROUTES: list = []


def web_route(method: str, pattern: str):
    rx = re.compile("^" + re.sub(r"<(\w+)>", r"(?P<\1>[^/]+)", pattern) + "$")

    def deco(fn):
        WEB_ROUTES.append((method, rx, fn))
        return fn
    return deco


def _unavailable(what: str):
    def fn(app, q, body, **kw):
        raise ApiError(f"{what} needs the Folio desktop app — it isn't available in the browser.", 409)
    return fn


for _m, _p, _what in (("POST", "/api/open-dialog", "The system file dialog"),
                      ("POST", "/api/open", "Opening files by path"),
                      ("POST", "/api/office-to-pdf", "Converting Office files"),
                      ("POST", "/api/doc/<sid>/to-word", "Converting to Word"),
                      ("POST", "/api/reveal", "Showing files in a folder"),
                      ("POST", "/api/external-open", "Opening files from Windows"),
                      ("POST", "/api/quit", "Quitting")):
    web_route(_m, _p)(_unavailable(_what))


def _safe_name(name: str, default: str) -> str:
    name = os.path.basename((name or "").replace("\\", "/")).strip()
    name = re.sub(r"[\x00-\x1f<>:\"|?*]", "_", name)
    return name[:120] or default


@web_route("POST", "/api/upload")
def web_upload(app, q, body, raw=None, **kw):
    """Open uploaded bytes. A PDF opened from the user's computer starts out saved."""
    res = server.api_upload(app, q, body, raw=raw)
    if res.get("doc") and raw is not None and raw[:5] == b"%PDF-":
        s = app.get(res["doc"]["id"])
        s.saved_state = s.state
        res["doc"] = s.info()
    return res


@web_route("POST", "/api/web/stage")
def web_stage(app, q, body, files=None, **kw):
    """Files picked in the page, written to the virtual file system so the desktop routes
    (merge, images to PDF, insert pages) can read them by path. Each call replaces the
    previous batch."""
    if not files:
        raise ApiError("No files.")
    shutil.rmtree(STAGE_DIR, ignore_errors=True)
    folder = os.path.join(STAGE_DIR, secrets.token_hex(4))
    os.makedirs(folder, exist_ok=True)
    out = []
    for i, (name, data) in enumerate(files):
        # a folder per file: each keeps its own name (routes name new documents after it)
        sub = os.path.join(folder, f"{i:03d}")
        os.makedirs(sub, exist_ok=True)
        p = os.path.join(sub, _safe_name(name, "file"))
        with open(p, "wb") as f:
            f.write(data)
        out.append(p)
    return {"paths": out}


def _export_options(s: session.Session) -> dict:
    # The same encryption rules Session.save applies before it writes to disk.
    if s.protect:
        return dict(encryption=fitz.PDF_ENCRYPT_AES_256, user_pw=s.protect.get("user_pw") or "",
                    owner_pw=s.protect.get("owner_pw") or s.protect.get("user_pw") or "",
                    permissions=int(s.protect.get("permissions", fitz.PDF_PERM_ACCESSIBILITY | fitz.PDF_PERM_PRINT
                                                  | fitz.PDF_PERM_COPY | fitz.PDF_PERM_ANNOTATE | fitz.PDF_PERM_FORM
                                                  | fitz.PDF_PERM_PRINT_HQ | fitz.PDF_PERM_MODIFY
                                                  | fitz.PDF_PERM_ASSEMBLE)))
    return dict(encryption=fitz.PDF_ENCRYPT_NONE)


@web_route("POST", "/api/doc/<sid>/save")
def web_save(app, q, body, sid=None, **kw):
    """Save = the finished file as bytes (the page downloads it or hands it back)."""
    s = app.get(sid)
    with ENGINE:
        data = s.export(**_export_options(s))
        written = s.state
    s.saved_state = written
    s.protect_dirty = False
    name = s.name if s.name.lower().endswith(".pdf") else s.name + ".pdf"
    return Binary(data, "application/pdf", name, {"doc": s.info(), "size": len(data)})


def _out_folder() -> str:
    shutil.rmtree(OUT_DIR, ignore_errors=True)
    folder = os.path.join(OUT_DIR, secrets.token_hex(4))
    os.makedirs(folder, exist_ok=True)
    return folder


def _bundle(files: list[str], zip_name: str, ctype_single: str) -> Binary:
    if len(files) == 1:
        with open(files[0], "rb") as f:
            return Binary(f.read(), ctype_single, os.path.basename(files[0]), {"count": 1})
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for p in files:
            z.write(p, os.path.basename(p))
    return Binary(buf.getvalue(), "application/zip", zip_name, {"count": len(files)})


@web_route("POST", "/api/doc/<sid>/pages/<op>")
def web_pages(app, q, body, sid=None, op=None, raw=None, **kw):
    s = app.get(sid)
    base = os.path.splitext(s.name)[0]
    if op == "extract":
        ps = server._pages_arg(s, body)
        label = f"p{ps[0] + 1}" if len(ps) == 1 else f"p{ps[0] + 1}-{ps[-1] + 1}"
        target = os.path.join(_out_folder(), f"{base} ({label}).pdf")
        server.api_pages(app, q, dict(body, path=target), sid=sid, op=op)
        return _bundle([target], "", "application/pdf")
    if op == "split":
        res = server.api_pages(app, q, dict(body, folder=_out_folder()), sid=sid, op=op)
        return _bundle(res["files"], f"{base} (split).zip", "application/pdf")
    return server.api_pages(app, q, body, sid=sid, op=op, raw=raw)


@web_route("POST", "/api/doc/<sid>/export-images")
def web_export_images(app, q, body, sid=None, **kw):
    s = app.get(sid)
    res = server.api_export_images(app, q, dict(body, folder=_out_folder()), sid=sid)
    fmt = "jpeg" if str(body.get("fmt", "png")).lower() in ("jpg", "jpeg") else "png"
    return _bundle(res["files"], f"{os.path.splitext(s.name)[0]} (images).zip", f"image/{fmt}")


# ======================================================================== dispatch
def _json_bytes(obj) -> bytes:
    return json.dumps(obj, ensure_ascii=False).encode("utf-8")


def _find(method: str, path: str):
    for table in (WEB_ROUTES, server.ROUTES):
        for m, rx, fn in table:
            if m == method:
                mm = rx.match(path)
                if mm:
                    return fn, mm.groupdict()
    return None, None


def _engine_get(path: str, q: dict):
    """The desktop server's non-JSON GETs: page renders, object images, editor fonts."""
    parts = path.split("/")
    if path.startswith("/r/"):
        s = APP.get(parts[2])
        pno = server._pno(s, parts[3])
        hide = tuple(h for h in q.get("hide", [""])[0].split(",") if h)
        data, ctype = s.render(pno, float(q.get("s", ["1"])[0]), hide, q.get("annots", ["1"])[0] != "0")
        return data, ctype
    if path.startswith("/o/"):
        s = APP.get(parts[2])
        pno = server._pno(s, parts[3])
        return s.render_object(pno, parts[4], float(q.get("s", ["1"])[0])), "image/png"
    if path == "/font":
        fi = fonts.FontIndex.get()
        face = fi.by_key.get(q.get("key", [""])[0])
        if face is None:
            raise LookupError("font not found")
        chars = ("".join(chr(c) for c in range(32, 127)) + "".join(chr(c) for c in range(160, 384))
                 + "–—‘’“”•…€™")
        return fi.subset(face, chars), "font/ttf"
    return None


_PERSISTENT = re.compile(r"^/api/(signatures|settings)")


def _given(x):
    """None for an absent argument (Python None, or a JavaScript null/undefined proxy)."""
    if x is None or type(x).__name__ in ("JsNull", "JsUndefined"):
        return None
    return x


def handle(method: str, url: str, body_text, raw, files):
    """One request. Returns (status, content type, body bytes, meta dict)."""
    global _fs_dirty
    body_text, raw, files = _given(body_text), _given(raw), _given(files)
    split = urllib.parse.urlsplit(url)
    q = urllib.parse.parse_qs(split.query)
    path = split.path
    try:
        if method == "GET":
            got = _engine_get(path, q)
            if got is not None:
                return 200, got[1], got[0], None
        fn, groups = _find(method, path)
        if fn is None:
            return 404, "text/plain", b"not found", None
        body = json.loads(body_text) if body_text else {}
        raw_b = raw.to_bytes() if raw is not None and hasattr(raw, "to_bytes") else raw
        kw = dict(groups)
        if files is not None:
            kw["files"] = [(str(f[0]), f[1].to_bytes() if hasattr(f[1], "to_bytes") else bytes(f[1])) for f in files]
        res = fn(APP, q, body, raw=raw_b, **kw)
        if method == "POST" and _PERSISTENT.match(path):
            _fs_dirty = True
        if isinstance(res, Binary):
            return 200, res.ctype, res.data, dict(res.meta, name=res.name)
        return 200, "application/json", _json_bytes(res), None
    except ApiError as e:
        return e.status, "application/json", _json_bytes(dict({"error": str(e)}, **e.extra)), None
    except (ValueError, LookupError, PermissionError, FileNotFoundError, RuntimeError) as e:
        return 400, "application/json", _json_bytes({"error": str(e) or e.__class__.__name__}), None
    except re.error as e:
        return 400, "application/json", _json_bytes({"error": f"That search pattern isn't valid: {e}"}), None
    except TypeError as e:
        log.warning("bad request %s %s\n%s", method, path, traceback.format_exc())
        return 400, "application/json", _json_bytes({"error": f"Folio couldn't use that request ({e})."}), None
    except Exception as e:  # pragma: no cover
        log.error("error in %s %s\n%s", method, path, traceback.format_exc())
        return 500, "application/json", _json_bytes({"error": f"Something went wrong: {e}"}), None


def warm() -> dict:
    """Load what the first edit needs, so it doesn't pay for it."""
    n = prepare_fonts()
    return {"faces": n, "version": __import__("folio").__version__, "pymupdf": fitz.VersionBind}

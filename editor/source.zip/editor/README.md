# The PDF editor (Folio, in the browser)

ResuTailor's **Edit PDF** mode — and the "Edit in the PDF editor" button on a PDF's ATS report — open
**Folio**, a desktop PDF editor, running entirely in the page. Folio's own engine (Python, PyMuPDF) runs on
[Pyodide](https://pyodide.org) in a Web Worker; its own UI runs in a same-origin frame. A PDF is opened,
edited and saved in the visitor's browser — it is never uploaded.

## How it fits together

```
App (React) ── PdfEditorModal ──iframe──► editor/index.html  (Folio's UI, vanilla JS)
                 postMessage                   │ api.js → engine.js
                 open / done / cancel          ▼
                                          worker.js  (module worker)
                                               │ Pyodide 0.28 + PyMuPDF 1.26 + fontTools (+ Pillow on demand)
                                               ▼
                                          py/folio_web.py  →  py/folio/  (Folio's engine and routes)
```

- **`py/folio/`** — Folio's Python package (engine + HTTP route functions), copied **unchanged** from the
  desktop app. Keep it that way: browser differences belong in `folio_web.py`.
- **`py/folio_web.py`** — the adapter. Pyodide can't start threads, so the font index loads synchronously;
  a browser has no installed fonts, so the editor ships metric-compatible open fonts (Carlito for Calibri,
  Caladea for Cambria, Arimo/Tinos/Cousine for Arial/Times/Courier, Gelasio for Georgia) and maps PDF font
  names onto them; native file dialogs become uploads (staged into the virtual file system) and downloads
  (files a route would have written come back as bytes); Office, Explorer and window routes say they need
  the desktop app. `handle()` answers one request exactly as Folio's HTTP server would.
- **`worker.js`** — loads the runtime, unpacks Folio and the fonts, keeps signatures/settings/the font index
  in IndexedDB, and runs requests one at a time from two lanes (API calls before page renders; a render the
  page no longer needs is cancelled before it is drawn).
- **`js/engine.js`** — the page side: requests by id, and object URLs for the engine's images and fonts
  (`/r/…` page renders, `/o/…` object images, `/font?…`), cached by version.
- **`js/web.js`** — file chooser, downloads, and the embed protocol with ResuTailor
  (`?embed=1`: the app sends `{type:'open', name, bytes}`; the editor answers `ready`, `opened`, `dirty`,
  `done {bytes, name, changed}`, `cancel`, `failed`; both sides check origin and source).
- The other `js/*.js`, `css/app.css` and `index.html` are Folio's UI with browser changes: open = file
  chooser, save = download (or **Done** inside ResuTailor), images and editor fonts through `engine.js`, and
  no Word/Office/Explorer features.

The runtime files are produced by `scripts/editor-runtime.mjs` (a Vite plugin) under `editor-runtime/`:
Pyodide's core from the pinned `pyodide` npm package, the PyMuPDF/fontTools/Pillow wheels from the same
Pyodide release (downloaded once, checked against the SHA-256 in its lock file, cached in
`node_modules/.cache`), `fonts-<hash>.zip` (the `@fontsource` WOFF files unwrapped to TrueType) and
`folio-<hash>.zip` (this folder's `py/`). In development the plugin serves them and reloads the page when a
`.py` file changes.

## Updating from the desktop app

Copy `folio/folio/**/*.py` (without `ui/`, `app.py`, `__main__.py`) over `py/folio/`. UI changes in Folio
need merging by hand into `js/` — the browser edits are small and marked; compare with
`git diff --no-index <folio>/folio/ui/js/<file>.js editor/js/<file>.js`.

## Limits in the browser

- Text is edited line by line (no paragraph reflow), as in the desktop app.
- Fonts: words are set in the PDF's own embedded font when it has the letters; otherwise in one of the
  six bundled families (Latin). Other scripts fall back to MuPDF's built-in fonts.
- No Word/Office conversion (that needs Microsoft Office), no printing to a chosen printer (the browser's
  print dialog is used), no "show in folder".
- An edited line is drawn after the rest of its page, so a parser that reads a PDF's stored order (rather
  than its layout) meets it last. ResuTailor's ATS check reads by layout, as most parsers do, and warns
  only when a file's order is substantially shuffled.

## Licences

This folder is a combined work with **PyMuPDF/MuPDF** (© Artifex Software, **AGPL-3.0**). Served to
visitors over a network, it must offer its complete source under the AGPL — which this public repository
does. The editor's code in this folder is therefore distributed under the **GNU AGPL v3.0 or later**
(full text in [`LICENSE`](LICENSE)); the rest of ResuTailor stays MIT. Bundled at build time (not stored in this repository):

| Component | Licence |
|---|---|
| Pyodide 0.28 (CPython, WebAssembly) | MPL-2.0 (CPython: PSF) |
| PyMuPDF 1.26 / MuPDF | AGPL-3.0 |
| fontTools 4.56 | MIT |
| Pillow 11.3 | MIT-CMU (HPND) |
| Carlito, Caladea, Arimo, Tinos, Cousine, Gelasio (via @fontsource) | SIL OFL-1.1 |
| pdf.js (ResuTailor's PDF reader and preview) | Apache-2.0 |

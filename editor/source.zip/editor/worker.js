// The editor's engine: Folio's own Python (folio/), PyMuPDF and fontTools on Pyodide.
// Everything runs here, in the visitor's browser — no document ever leaves the page.
//
// Requests arrive as messages and run one at a time (Python is single-threaded). Two
// lanes: API calls first, then images (page renders, thumbnails), so a long scroll never
// delays an edit; an image the page no longer wants is cancelled before it is drawn.

let py = null;
let handle = null;
let takeFsDirty = null;
let persist = false;
let ready = false;
let failed = false;
let pillow = null;
const lanes = { api: [], media: [] };
const cancelled = new Set();
let draining = false;
const tick = new MessageChannel();
tick.port1.onmessage = () => drain();

const post = (msg, transfer) => self.postMessage(msg, transfer || []);
let lastActivity = performance.now();
const stage = (key, label) => { lastActivity = performance.now(); post({ type: 'stage', key, label }); };
const fail = (err) => {
  if (ready || failed) return;
  failed = true;
  post({ type: 'failed', error: String((err && err.message) || err) });
};

self.onmessage = (e) => {
  const m = e.data;
  if (m.type === 'init') {
    boot(m.runtime).catch(fail);
  } else if (m.type === 'call') {
    (m.lane === 'media' ? lanes.media : lanes.api).push(m);
    schedule();
  } else if (m.type === 'cancel') {
    cancelled.add(m.id);
  }
};

function schedule() {
  if (draining || !ready) return;
  draining = true;
  tick.port2.postMessage(null);
}

async function drain() {
  for (;;) {
    const job = lanes.api.shift() || lanes.media.shift();
    if (!job) { draining = false; cancelled.clear(); return; }
    if (cancelled.delete(job.id)) continue;
    await run(job);
    // yield, so cancels and new API calls that arrived meanwhile are seen first
    tick.port2.postMessage(null);
    return;
  }
}

// Routes that may read an image format MuPDF can't (WebP…): Pillow converts those,
// with EXIF rotation. Loaded on first need (about 1 MB).
const PILLOW_ROUTES = /^\/api\/(images-to-pdf|merge|doc\/[^/]+\/pages\/insert-file)/;
const isPdf = (u8) => u8.length >= 5 && u8[0] === 0x25 && u8[1] === 0x50 && u8[2] === 0x44 && u8[3] === 0x46 && u8[4] === 0x2d;
// Signatures and settings live in IndexedDB, shared by every open copy of the editor:
// read what other tabs saved before changing it, write it back after.
const SHARED_ROUTES = /^\/api\/(signatures|settings)/;

async function run(job) {
  const t0 = performance.now();
  const raw = job.raw ? new Uint8Array(job.raw) : undefined;
  try {
    const path = job.url.split('?')[0];
    if (job.method === 'POST' && (PILLOW_ROUTES.test(path) || (path === '/api/upload' && raw && !isPdf(raw)))) {
      pillow = pillow || py.loadPackage('pillow').catch(() => {});
      await pillow;
    }
    if (persist && SHARED_ROUTES.test(path)) await syncfs(true).catch(() => {});
    // absent arguments go as `undefined` (Python None); a JS null would arrive as JsNull
    const files = job.files ? job.files.map((f) => [f.name, new Uint8Array(f.data)]) : undefined;
    const res = handle(job.method, job.url, job.body ?? undefined, raw, files);
    let out;
    try { out = res.toJs({ dict_converter: Object.fromEntries }); } finally { res.destroy(); }
    const [status, ctype, payload, meta] = out;
    const bytes = payload instanceof Uint8Array ? payload : new Uint8Array(payload || []);
    const buf = bytes.byteOffset === 0 && bytes.byteLength === bytes.buffer.byteLength ? bytes.buffer : bytes.slice().buffer;
    post({ type: 'result', id: job.id, status, ctype, meta: meta ?? null, body: buf, ms: Math.round(performance.now() - t0) }, [buf]);
  } catch (err) {
    const msg = JSON.stringify({ error: `The PDF engine failed: ${String((err && err.message) || err).split('\n').slice(-2).join(' ')}` });
    const buf = new TextEncoder().encode(msg).buffer;
    post({ type: 'result', id: job.id, status: 500, ctype: 'application/json', meta: null, body: buf }, [buf]);
  }
  try {
    if (persist && takeFsDirty && takeFsDirty()) await syncfs(false);
  } catch { /* storage is best effort: the edit itself is done */ }
}

function syncfs(populate) {
  return new Promise((resolve, reject) => py.FS.syncfs(populate, (err) => (err ? reject(err) : resolve())));
}

// Download progress for the big files, measured against the sizes the build recorded.
function watchDownloads(sizes) {
  const loaded = new Map();
  const total = Object.values(sizes).reduce((a, b) => a + b, 0);
  const real = self.fetch.bind(self);
  let last = 0;
  const report = () => {
    const now = performance.now();
    lastActivity = now;
    if (now - last < 120) return;
    last = now;
    let got = 0;
    for (const v of loaded.values()) got += v;
    post({ type: 'progress', loaded: Math.min(got, total), total });
  };
  self.fetch = async (input, init) => {
    const res = await real(input, init);
    lastActivity = performance.now();
    try {
      // Pyodide passes strings, URL objects and Requests; counting must never break a download
      const url = input instanceof Request ? input.url : String(input);
      const name = decodeURIComponent(url.split('?')[0].split('/').pop() || '');
      if (!(name in sizes) || !res.ok || !res.body) return res;
      let got = 0;
      const counted = res.body.pipeThrough(new TransformStream({
        transform(chunk, ctl) { got += chunk.byteLength; loaded.set(name, Math.min(got, sizes[name])); report(); ctl.enqueue(chunk); },
        flush() { loaded.set(name, sizes[name]); report(); },
      }));
      return new Response(counted, { status: res.status, statusText: res.statusText, headers: res.headers });
    } catch {
      return res;
    }
  };
}

async function fetchBytes(url) {
  const r = await fetch(url);
  if (!r.ok) throw new Error(`Couldn't download ${url.split('/').pop()} (HTTP ${r.status}).`);
  return new Uint8Array(await r.arrayBuffer());
}

// Pyodide only logs a failed WebAssembly start (a cut-off download, a 404 page served
// as wasm) and never settles: nothing moving for this long during start-up is a failure.
const STALL_MS = 60_000;

async function boot(rt) {
  const t0 = performance.now();
  const watchdog = setInterval(() => {
    if (ready || failed) { clearInterval(watchdog); return; }
    if (performance.now() - lastActivity > STALL_MS) {
      clearInterval(watchdog);
      fail(new Error('The PDF engine stopped loading. Check your connection and reload the page to try again.'));
    }
  }, 5_000);
  watchDownloads(rt.sizes || {});
  stage('runtime', 'Starting the PDF engine');
  const folioZip = fetchBytes(rt.folio);
  const fontsZip = fetchBytes(rt.fonts);
  folioZip.catch(() => {});
  fontsZip.catch(() => {});
  const { loadPyodide } = await import(/* @vite-ignore */ `${rt.pyodide}pyodide.mjs`);
  py = await loadPyodide({ indexURL: rt.pyodide, stdout: () => {}, stderr: (s) => console.warn('[engine]', s) });
  stage('packages', 'Loading PyMuPDF');
  await py.loadPackage(['pymupdf', 'fonttools'], { messageCallback: () => {}, errorCallback: (s) => console.warn('[engine]', s) });
  stage('files', 'Unpacking the editor');
  py.unpackArchive(await folioZip, 'zip', { extractDir: '/home/pyodide/editor' });
  py.FS.mkdirTree('/fonts');
  py.unpackArchive(await fontsZip, 'zip', { extractDir: '/fonts' });
  // Signatures, settings and the font index survive visits in IndexedDB (when allowed).
  py.FS.mkdirTree('/folio_data');
  try {
    py.FS.mount(py.FS.filesystems.IDBFS, {}, '/folio_data');
    await syncfs(true);
    persist = true;
  } catch (err) {
    console.warn('[engine] no persistent storage, signatures last this visit only', err);
  }
  py.runPython("import sys\nsys.path.insert(0, '/home/pyodide/editor')");
  const web = py.pyimport('folio_web');
  handle = web.handle;
  takeFsDirty = web.take_fs_dirty;
  stage('fonts', 'Preparing fonts');
  const warm = web.warm();
  const info = warm.toJs({ dict_converter: Object.fromEntries });
  warm.destroy();
  if (persist) await syncfs(false).catch(() => {});
  if (failed) return;  // the watchdog gave up; the page was told
  ready = true;
  clearInterval(watchdog);
  post({ type: 'ready', info, ms: Math.round(performance.now() - t0) });
  schedule();
}

// The browser shell around Folio's UI: files are picked with the page's file chooser and
// leave as downloads, and when the editor runs inside ResuTailor (an <iframe> opened with
// ?embed) the finished PDF goes back to that page instead.

export const embedded = window.parent !== window && new URLSearchParams(location.search).has('embed');

/** The browser's file chooser. Resolves [] when the chooser is dismissed. */
export function pickFiles({ accept = '', multiple = false } = {}) {
  const inp = document.createElement('input');
  inp.type = 'file';
  inp.accept = accept;
  inp.multiple = multiple;
  inp.hidden = true;
  document.body.appendChild(inp);
  return new Promise((resolve) => {
    const done = (files) => { inp.remove(); resolve(files); };
    inp.addEventListener('change', () => done([...inp.files]), { once: true });
    inp.addEventListener('cancel', () => done([]), { once: true });
    inp.click();
  });
}

/** Save bytes as a file through the browser's download. */
export function download(bytes, name, type = 'application/octet-stream') {
  const url = URL.createObjectURL(new Blob([bytes], { type }));
  const a = document.createElement('a');
  a.href = url;
  a.download = name;
  a.rel = 'noopener';
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 60_000);
}

// ------------------------------------------------------------------ inside ResuTailor
const handlers = new Set();

export function toParent(msg, transfer = []) {
  if (embedded) window.parent.postMessage({ source: 'folio-editor', ...msg }, location.origin, transfer);
}

export function onParent(fn) {
  handlers.add(fn);
  return () => handlers.delete(fn);
}

window.addEventListener('message', (e) => {
  if (!embedded || e.source !== window.parent || e.origin !== location.origin) return;
  const m = e.data;
  if (!m || m.source !== 'resutailor') return;
  for (const fn of handlers) fn(m);
});

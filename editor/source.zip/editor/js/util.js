// Small DOM toolkit, icons, menus, modals and toasts. No dependencies.

export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

/** h('div.cls#id', {attrs, on: {click}}, ...children) */
export function h(tag, props, ...kids) {
  const m = /^([a-z0-9-]+)?((?:[.#][\w-]+)*)$/i.exec(tag);
  const el = document.createElement((m && m[1]) || 'div');
  if (m && m[2]) {
    for (const part of m[2].match(/[.#][\w-]+/g)) {
      if (part[0] === '.') el.classList.add(part.slice(1)); else el.id = part.slice(1);
    }
  }
  if (props && (typeof props !== 'object' || props instanceof Node || Array.isArray(props))) { kids.unshift(props); props = null; }
  for (const [k, v] of Object.entries(props || {})) {
    if (v == null || v === false) continue;
    if (k === 'on') { for (const [ev, fn] of Object.entries(v)) el.addEventListener(ev, fn); }
    else if (k === 'style' && typeof v === 'object') Object.assign(el.style, v);
    else if (k === 'class') el.className = [el.className, v].filter(Boolean).join(' ');
    else if (k === 'dataset') Object.assign(el.dataset, v);
    else if (k in el && typeof v !== 'string') el[k] = v;
    else if (k === 'html') el.innerHTML = v;
    else el.setAttribute(k, v === true ? '' : v);
  }
  append(el, kids);
  return el;
}
function append(el, kids) {
  for (const k of kids.flat(Infinity)) {
    if (k == null || k === false) continue;
    el.appendChild(k instanceof Node ? k : document.createTextNode(String(k)));
  }
}

// ---------------------------------------------------------------- icons (24px, stroked)
const P = {
  open: 'M3 7.5A2.5 2.5 0 0 1 5.5 5H9l2 2h7.5A2.5 2.5 0 0 1 21 9.5v7a2.5 2.5 0 0 1-2.5 2.5h-13A2.5 2.5 0 0 1 3 16.5z',
  save: 'M5 4h11l4 4v11a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1z M8 4v5h7V4 M8 20v-6h8v6',
  undo: 'M9 14L4 9l5-5 M4 9h10.5a5.5 5.5 0 0 1 0 11H11',
  redo: 'M15 14l5-5-5-5 M20 9H9.5a5.5 5.5 0 0 0 0 11H13',
  select: 'M6 3.5l12 7.2-5.3 1.4 3 5.6-2.4 1.3-3-5.6L6.5 17z',
  edittext: 'M4 7V5h11v2 M9.5 5v14 M7.5 19h4 M18 8v11 M16 8h4 M16 19h4',
  addtext: 'M4 6V4h12v2 M10 4v15 M8 19h4 M18.5 12.5v7 M15 16h7',
  sign: 'M15.5 4.5l4 4L9.5 18.5 5 19.5l1-4.5z M13.5 6.5l4 4 M3 21.5h18',
  image: 'M4 5.5A1.5 1.5 0 0 1 5.5 4h13A1.5 1.5 0 0 1 20 5.5v13a1.5 1.5 0 0 1-1.5 1.5h-13A1.5 1.5 0 0 1 4 18.5z M9 11a2 2 0 1 0 0-4 2 2 0 0 0 0 4z M20 15.5l-4.5-4.5L6 20',
  draw: 'M3 16.5c2.5-1.5 3.7-7.5 6.3-7.5 2.6 0 1.7 7 4.4 7s3-9 6.8-9.5',
  shape: 'M3.5 3.5h8v8h-8z M16.5 21a4.5 4.5 0 1 0 0-9 4.5 4.5 0 0 0 0 9z M17 3l4 7h-8z',
  mark: 'M4.5 12.5l4.5 4.5L19.5 6.5',
  whiteout: 'M4 6.5A1.5 1.5 0 0 1 5.5 5h13A1.5 1.5 0 0 1 20 6.5v8a1.5 1.5 0 0 1-1.5 1.5h-13A1.5 1.5 0 0 1 4 14.5z M9 16v4 M15 16v4 M7.5 9.5l3 3 M11 9.5l3 3 M14.5 9.5l2 2',
  erase: 'M15.5 3.5l5 5-10.5 10.5H5.5l-2.5-2.5z M9 10l5.5 5.5 M10 19h11',
  redact: 'M4 9.5h16v5H4z M4 5.5h9 M4 18.5h12',
  highlight: 'M9 15l-4.5 4.5h6.5l1.5-1.5 M14.5 3.5l6 6-7.5 7.5-6-6z',
  note: 'M4 5.5A1.5 1.5 0 0 1 5.5 4h13A1.5 1.5 0 0 1 20 5.5v9a1.5 1.5 0 0 1-1.5 1.5H10l-6 4z M8 9h8 M8 12h5',
  find: 'M11 18a7 7 0 1 0 0-14 7 7 0 0 0 0 14z M20 20l-4-4',
  tools: 'M4 4h6v6H4z M14 4h6v6h-6z M4 14h6v6H4z M17 14v6 M14 17h6',
  plus: 'M12 5v14 M5 12h14',
  minus: 'M5 12h14',
  close: 'M6.5 6.5l11 11 M17.5 6.5l-11 11',
  rotcw: 'M19.5 11.5a7.5 7.5 0 1 1-2.2-5.3 M20 4.5v5h-5',
  rotccw: 'M4.5 11.5a7.5 7.5 0 1 0 2.2-5.3 M4 4.5v5h5',
  trash: 'M4 7h16 M9.5 7V4.5h5V7 M6.5 7l1 12.5h9l1-12.5 M10 11v5 M14 11v5',
  dup: 'M8.5 8.5h11v11h-11z M15.5 8.5v-4h-11v11h4',
  pageadd: 'M6 3h8l4 4v14H6z M14 3v4h4 M12 11v6 M9 14h6',
  pdf: 'M6 3h8l5 5v13H6z M14 3v5h5 M9 13h6 M9 16.5h4',
  merge: 'M7 4v5a4 4 0 0 0 4 4h8 M15.5 9.5L19 13l-3.5 3.5 M7 20v-3',
  split: 'M6 9a3 3 0 1 0 0-6 3 3 0 0 0 0 6z M6 21a3 3 0 1 0 0-6 3 3 0 0 0 0 6z M8.4 7.6L20 18 M8.4 16.4L20 6',
  compress: 'M4 14.5h5.5V20 M20 9.5h-5.5V4 M14.5 9.5L20.5 3.5 M3.5 20.5l6-6',
  word: 'M6 3h8l5 5v13H6z M14 3v5h5 M8.5 12l1.5 5.5 2-3.5 2 3.5 1.5-5.5',
  lock: 'M6 11h12v9.5H6z M8.5 11V8a3.5 3.5 0 0 1 7 0v3',
  unlock: 'M6 11h12v9.5H6z M8.5 11V8a3.5 3.5 0 0 1 6.8-1.2',
  info: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18z M12 11v5 M12 8h.01',
  hash: 'M5 9h14 M5 15h14 M10 4L8 20 M16 4l-2 16',
  drop: 'M12 3.5s6 6.3 6 10.5a6 6 0 0 1-12 0c0-4.2 6-10.5 6-10.5z',
  eyeoff: 'M3 3l18 18 M10.6 6.1c.5-.1.9-.1 1.4-.1 5 0 9 6 9 6a16 16 0 0 1-3.1 3.6 M6.6 6.6C4.3 8.1 3 12 3 12s4 6 9 6a9 9 0 0 0 4.4-1.1 M9.9 9.9a3 3 0 0 0 4.2 4.2',
  layers: 'M12 3.5l9 5-9 5-9-5z M3 13.5l9 5 9-5',
  print: 'M7 9V3.5h10V9 M7 17H4v-7.5h16V17h-3 M7 14h10v6.5H7z',
  chev: 'M6 9l6 6 6-6',
  chevr: 'M9 6l6 6-6 6',
  sun: 'M12 16.5a4.5 4.5 0 1 0 0-9 4.5 4.5 0 0 0 0 9z M12 2v2 M12 20v2 M4.9 4.9l1.4 1.4 M17.7 17.7l1.4 1.4 M2 12h2 M20 12h2 M4.9 19.1l1.4-1.4 M17.7 6.3l1.4-1.4',
  moon: 'M20.5 13.5A8.5 8.5 0 1 1 10.5 3.5a6.6 6.6 0 0 0 10 10z',
  auto: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18z M12 3v18',
  hand: 'M7 11V6.5a1.5 1.5 0 0 1 3 0V10 M10 10V4.5a1.5 1.5 0 0 1 3 0V10 M13 10V5.5a1.5 1.5 0 0 1 3 0V11 M16 9.5a1.5 1.5 0 0 1 3 0V14a7 7 0 0 1-7 7h-1a6 6 0 0 1-5.2-3l-2.3-4.3a1.5 1.5 0 0 1 2.6-1.5L7 14',
  fitw: 'M3 12h18 M7 8l-4 4 4 4 M17 8l4 4-4 4',
  side: 'M4 4.5h16v15H4z M9.5 4.5v15',
  panel: 'M4 4.5h16v15H4z M14.5 4.5v15',
  ok: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18z M8 12.2l2.8 2.8L16 9.5',
  warn: 'M12 3.5l9.5 16.5h-19z M12 10v4.5 M12 17.5h.01',
  upload: 'M12 16V4 M7 9l5-5 5 5 M4 20h16',
  more: 'M5 12h.01 M12 12h.01 M19 12h.01',
  dot: 'M12 15.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7z',
  line: 'M5 19L19 5',
  arrow: 'M5 19L19 5 M10 5h9v9',
  rect: 'M4 6.5h16v11H4z',
  ellipse: 'M12 18.5c4.4 0 8-2.9 8-6.5s-3.6-6.5-8-6.5-8 2.9-8 6.5 3.6 6.5 8 6.5z',
  underline: 'M7 4v6a5 5 0 0 0 10 0V4 M5 20h14',
  strike: 'M4 12h16 M16 6.8C15.3 5.2 13.8 4.3 12 4.3c-2.2 0-4 1.2-4 3.1 0 1.5 1.1 2.4 2.7 3 M8 17.2c.7 1.6 2.2 2.5 4 2.5 2.2 0 4-1.2 4-3.1 0-.8-.3-1.5-.8-2',
  alignl: 'M4 6h16 M4 10h10 M4 14h16 M4 18h10',
  alignc: 'M4 6h16 M7 10h10 M4 14h16 M7 18h10',
  alignr: 'M4 6h16 M10 10h10 M4 14h16 M10 18h10',
  folder: 'M3 7.5A2.5 2.5 0 0 1 5.5 5H9l2 2h7.5A2.5 2.5 0 0 1 21 9.5v7a2.5 2.5 0 0 1-2.5 2.5h-13A2.5 2.5 0 0 1 3 16.5z',
  cross: 'M6.5 6.5l11 11 M17.5 6.5l-11 11',
  check: 'M4.5 12.5l4.5 4.5L19.5 6.5',
  images: 'M7 7.5A1.5 1.5 0 0 1 8.5 6h11A1.5 1.5 0 0 1 21 7.5v10a1.5 1.5 0 0 1-1.5 1.5h-11A1.5 1.5 0 0 1 7 17.5z M4 9v10.5A1.5 1.5 0 0 0 5.5 21H17 M17 11.5a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3z M21 15l-4-3.5-7.5 7.5',
  backup: 'M3 12a9 9 0 1 0 3-6.7 M3 4v5h5 M12 7.5V12l3 2',
  rename: 'M4 20h4L19 9l-4-4L4 16z M13.5 6.5l4 4',
  pages: 'M8 3.5h10a1.5 1.5 0 0 1 1.5 1.5v12 M5 7h10a1.5 1.5 0 0 1 1.5 1.5v11a1.5 1.5 0 0 1-1.5 1.5H5A1.5 1.5 0 0 1 3.5 19.5v-11A1.5 1.5 0 0 1 5 7z',
  keyboard: 'M3.5 6.5h17v11h-17z M7 10h.01 M10 10h.01 M13 10h.01 M16 10h.01 M8 14h8',
};
export function icon(name, cls = '') {
  const d = P[name] || P.info;
  const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  svg.setAttribute('viewBox', '0 0 24 24');
  svg.setAttribute('class', 'i ' + cls);
  svg.setAttribute('aria-hidden', 'true');
  for (const seg of d.split(' M')) {
    const p = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    p.setAttribute('d', seg.startsWith('M') ? seg : 'M' + seg);
    if (name === 'more') p.setAttribute('stroke-width', '3');
    svg.appendChild(p);
  }
  return svg;
}

// ---------------------------------------------------------------- formatting & colours
export const fmtBytes = (n) => n < 1024 ? `${n} bytes` : n < 1048576 ? `${(n / 1024).toFixed(0)} KB` : `${(n / 1048576).toFixed(n < 10485760 ? 2 : 1)} MB`;
export const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
export const debounce = (fn, ms) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };
export function basename(p) { return (p || '').split(/[\\/]/).pop(); }
export function dirname(p) { const parts = (p || '').split(/[\\/]/); parts.pop(); return parts.join('\\'); }
export function timeAgo(ts) {
  const s = Date.now() / 1000 - ts;
  if (s < 60) return 'just now';
  if (s < 3600) return `${Math.floor(s / 60)} min ago`;
  if (s < 86400) return `${Math.floor(s / 3600)} h ago`;
  if (s < 86400 * 7) return `${Math.floor(s / 86400)} d ago`;
  return new Date(ts * 1000).toLocaleDateString();
}
export function escapeHtml(s) { return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }

/** Ctrl shortcuts that work everywhere, even while typing in an editor or the find box
    (main.js handles them; inputs must let them bubble). */
const GLOBAL_KEYS = new Set(['s', 'o', 'w', 'g', 'p', 'f', 'h', '=', '+', '-', '0', 'tab']);
export const isGlobalShortcut = (e) => (e.ctrlKey || e.metaKey) && !e.altKey && GLOBAL_KEYS.has(e.key.toLowerCase());

export const COLORS = ['#000000', '#3d3f46', '#1f4e99', '#2f6bff', '#0f8a5f', '#c2410c', '#d93d42', '#7c3aed', '#ffffff'];
export const HL_COLORS = ['#ffe14d', '#7ee787', '#7cc7ff', '#ff9fd1', '#ffb35c'];

export function swatches(colors, value, onPick, { custom = true } = {}) {
  const box = h('div.swatches');
  const draw = (val) => {
    val = typeof val === 'string' ? val : '';
    box.replaceChildren(...colors.map((c) => h('button.sw', {
      class: c.toLowerCase() === val.toLowerCase() ? 'on' : '', title: c, style: { background: c },
      on: { click: () => { draw(c); onPick(c); } },
    })));
    if (custom) {
      const inp = h('input', { type: 'color', value: /^#[0-9a-f]{6}$/i.test(val || '') ? val : '#000000' });
      // apply once when the picker closes (not on every drag tick: each would be an edit)
      inp.addEventListener('change', () => { draw(inp.value); onPick(inp.value); });
      const on = !colors.some((c) => c.toLowerCase() === (val || '').toLowerCase());
      box.appendChild(h('div.sw.custom', { class: on ? 'on' : '', title: 'Custom colour' }, inp));
    }
  };
  draw(value);
  return box;
}

export function seg(options, value, onPick) {
  const box = h('div.seg');
  const draw = (val) => box.replaceChildren(...options.map((o) => h('button', {
    class: o.value === val ? 'on' : '', title: o.title || o.label || '',
    on: { click: () => { draw(o.value); onPick(o.value); } },
  }, o.icon ? icon(o.icon, 'sm') : o.label)));
  draw(value);
  return box;
}

// ---------------------------------------------------------------- toasts
export function toast(msg, opts = {}) {
  const { type = 'info', action, onAction, ms = type === 'error' ? 6500 : 3200, spinner } = opts;
  const root = $('#toasts');
  const el = h('div.toast', { class: type, role: type === 'error' ? 'alert' : 'status' },
    spinner ? h('div.spin') : type === 'ok' ? icon('ok') : type === 'error' ? icon('warn') : null,
    h('span', msg),
    action ? h('button', { on: { click: () => { onAction && onAction(); close(); } } }, action) : null);
  root.appendChild(el);
  let timer = spinner ? null : setTimeout(close, ms);
  function close() { clearTimeout(timer); el.remove(); }
  return { close, update(text) { el.querySelector('span').textContent = text; } };
}

// ---------------------------------------------------------------- menus
let openMenu = null;
export function closeMenu() {
  if (!openMenu) return;
  openMenu.remove();
  openMenu = null;
  document.removeEventListener('pointerdown', outside, true);
  document.removeEventListener('keydown', menuKey, true);
}
export const menuOpen = () => !!openMenu;
function outside(e) { if (openMenu && !openMenu.contains(e.target)) closeMenu(); }
function menuKey(e) { if (e.key === 'Escape' && openMenu) { e.preventDefault(); e.stopPropagation(); closeMenu(); } }
export function menu(anchorOrPoint, items) {
  closeMenu();
  const el = h('div.menu', { role: 'menu' });
  for (const it of items) {
    if (!it) continue;
    if (it === '-') { el.appendChild(h('div.msep')); continue; }
    if (it.header) { el.appendChild(h('div.mh', it.header)); continue; }
    el.appendChild(h('button.mi', {
      class: it.danger ? 'danger' : '', disabled: it.disabled, role: 'menuitem',
      on: { click: () => { closeMenu(); it.run && it.run(); } },
    }, it.icon ? icon(it.icon, 'sm') : h('span', { style: { width: '15px' } }), it.label, it.key ? h('span.k', it.key) : null));
  }
  $('#menu-root').appendChild(el);
  let x, y;
  if (anchorOrPoint instanceof Element) {
    const r = anchorOrPoint.getBoundingClientRect();
    x = r.left; y = r.bottom + 4;
  } else ({ x, y } = anchorOrPoint);
  const mr = el.getBoundingClientRect();
  x = Math.min(x, innerWidth - mr.width - 8);
  y = y + mr.height > innerHeight - 8 ? Math.max(8, y - mr.height - (anchorOrPoint instanceof Element ? anchorOrPoint.getBoundingClientRect().height + 8 : 0)) : y;
  // taller than the space either way: pin to the top and let it scroll (max-height in CSS)
  if (y + Math.min(mr.height, innerHeight - 16) > innerHeight - 8) y = 8;
  el.style.left = `${Math.max(8, x)}px`;
  el.style.top = `${y}px`;
  openMenu = el;
  setTimeout(() => document.addEventListener('pointerdown', outside, true), 0);
  document.addEventListener('keydown', menuKey, true);
  return el;
}

// ---------------------------------------------------------------- modals
let modalStack = [];
export function modal({ title, body, buttons = [], wide = false, onClose, dismissable = true, enterId = null }) {
  return new Promise((resolve) => {
    const wrap = h('div.modal-wrap');
    const box = h('div.modal', { class: wide ? 'wide' : '', role: 'dialog', 'aria-modal': 'true', 'aria-label': title });
    const footer = h('footer');
    const done = (val) => {
      wrap.remove();
      modalStack = modalStack.filter((m) => m !== wrap);
      document.removeEventListener('keydown', onKey, true);
      onClose && onClose(val);
      resolve(val);
    };
    for (const b of buttons) {
      const btn = h('button.btn', {
        class: [b.primary ? 'primary' : '', b.danger ? 'danger' : '', b.left ? 'left' : '', b.ghost ? 'ghost' : ''].join(' '),
        on: { click: async () => {
          if (b.run) {
            btn.disabled = true;
            try { const r = await b.run(); if (r === false) { btn.disabled = false; return; } done(r === undefined ? b.value : r); }
            catch (e) { btn.disabled = false; toast(e.message || String(e), { type: 'error' }); }
          } else done(b.value);
        } },
      }, b.label);
      if (b.id) btn.id = b.id;
      footer.appendChild(btn);
    }
    box.append(h('header', h('h2', title)), h('div.body', body), footer);
    wrap.appendChild(box);
    wrap.addEventListener('pointerdown', (e) => { if (e.target === wrap && dismissable) done(null); });
    function onKey(e) {
      if (modalStack[modalStack.length - 1] !== wrap) return;
      if (e.key === 'Escape' && dismissable) { e.preventDefault(); e.stopPropagation(); done(null); }
      // Enter = the dialog's main action, but never when a button has focus (Enter on
      // "Cancel" must cancel) and never in a multi-line field.
      if (e.key === 'Enter' && !e.shiftKey && e.target.tagName !== 'TEXTAREA' && e.target.tagName !== 'BUTTON') {
        const target = enterId ? footer.querySelector(`#${enterId}`) : footer.querySelector('.btn.primary');
        if (target && !target.disabled) { e.preventDefault(); e.stopPropagation(); target.click(); }
      }
    }
    document.addEventListener('keydown', onKey, true);
    $('#modal-root').appendChild(wrap);
    modalStack.push(wrap);
    const first = box.querySelector('input:not([type=hidden]):not([type=color]), textarea, select');
    setTimeout(() => (first || footer.querySelector('.btn.primary') || box).focus(), 20);
  });
}
export const isModalOpen = () => modalStack.length > 0;

export function confirmBox(title, message, { ok = 'OK', danger = false, cancel = 'Cancel' } = {}) {
  return modal({ title, body: h('p', message), buttons: [
    { label: cancel, value: false },
    { label: ok, value: true, primary: !danger, danger },
  ] }).then((v) => !!v);
}

export function promptBox(title, { label = '', value = '', placeholder = '', ok = 'OK', type = 'text', hint } = {}) {
  const inp = h('input.input', { type, value, placeholder, autocomplete: 'off', spellcheck: false });
  return modal({ title, body: [label ? h('div.row.stack', h('label', label), inp) : inp, hint ? h('p.hint', { style: { marginTop: '8px' } }, hint) : null],
    buttons: [{ label: 'Cancel', value: null }, { label: ok, primary: true, run: () => inp.value }] });
}

export function busy(label) {
  const t = toast(label, { spinner: true });
  document.body.style.cursor = 'progress';
  return () => { t.close(); document.body.style.cursor = ''; };
}

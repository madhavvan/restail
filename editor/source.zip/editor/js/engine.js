// The page's side of the editor engine (worker.js): requests in, answers out, plus the
// image cache that stands in for the desktop server's URLs (/r/ page renders, /o/ object
// images, /font editor fonts). The answers are exactly what Folio's HTTP server sends.
import RT from 'virtual:editor-runtime';

const base = new URL(import.meta.env.BASE_URL, location.href);
const abs = (p) => new URL(p, base).href;
const runtime = {
  pyodide: abs(RT.pyodide),
  folio: abs(RT.folio),
  fonts: abs(RT.fonts),
  sizes: RT.sizes,
};

const worker = new Worker(new URL('../worker.js', import.meta.url), { type: 'module', name: 'folio-engine' });
const pending = new Map();
let seq = 0;
const listeners = { stage: new Set(), progress: new Set() };
let readyResolve; let readyReject;
export const ready = new Promise((res, rej) => { readyResolve = res; readyReject = rej; });
ready.catch(() => {});
export const status = { stage: 'Starting the PDF engine', loaded: 0, total: Object.values(RT.sizes).reduce((a, b) => a + b, 0), info: null, error: null };

worker.onmessage = (e) => {
  const m = e.data;
  if (m.type === 'result') {
    const p = pending.get(m.id);
    if (!p) return;
    pending.delete(m.id);
    p.resolve(m);
  } else if (m.type === 'stage') {
    status.stage = m.label;
    for (const fn of listeners.stage) fn(m);
  } else if (m.type === 'progress') {
    status.loaded = m.loaded;
    status.total = m.total;
    for (const fn of listeners.progress) fn(m);
  } else if (m.type === 'ready') {
    status.info = m.info;
    readyResolve(m);
  } else if (m.type === 'failed') {
    status.error = m.error;
    readyReject(new Error(m.error));
  }
};
worker.onerror = (e) => {
  status.error = e.message || 'The PDF engine stopped.';
  readyReject(new Error(status.error));
  // nothing more will answer: settle every request still waiting, as an engine error
  const body = new TextEncoder().encode(JSON.stringify({ error: `The PDF engine stopped (${status.error}). Reload the page to start it again.` })).buffer;
  for (const [id, p] of pending) { pending.delete(id); p.resolve({ status: 500, ctype: 'application/json', meta: null, body: body.slice(0) }); }
};
worker.postMessage({ type: 'init', runtime });

export function on(kind, fn) { listeners[kind].add(fn); return () => listeners[kind].delete(fn); }

/** One request to the engine: { status, ctype, meta, body: ArrayBuffer }. */
export function request(method, url, { body, raw, files, lane = 'api', signal } = {}) {
  const id = ++seq;
  return new Promise((resolve, reject) => {
    pending.set(id, { resolve, reject });
    const msg = { type: 'call', id, method, url, lane, body: body === undefined ? null : JSON.stringify(body) };
    if (raw) msg.raw = raw instanceof ArrayBuffer ? raw : raw.buffer.slice(raw.byteOffset, raw.byteOffset + raw.byteLength);
    if (files) msg.files = files;  // [{ name, data: ArrayBuffer }] — copied, the caller keeps its buffers
    worker.postMessage(msg);
    if (signal) {
      signal.addEventListener('abort', () => {
        if (!pending.has(id)) return;
        pending.delete(id);
        worker.postMessage({ type: 'cancel', id });
        reject(new DOMException('aborted', 'AbortError'));
      }, { once: true });
    }
  });
}

const decoder = new TextDecoder();
export const json = (res) => {
  const text = decoder.decode(res.body);
  try { return text ? JSON.parse(text) : {}; } catch { return { error: text }; }
};

// ------------------------------------------------------------------ images
// One object URL per engine URL (those carry a version, so an answer never goes stale),
// least recently used first out once the cache passes its budget.
const BUDGET = 160 * 1024 * 1024;
const cache = new Map();   // url -> { href, size }
const inflight = new Map(); // url -> Promise<href>
let cached = 0;

function remember(url, href, size) {
  cache.set(url, { href, size });
  cached += size;
  while (cached > BUDGET && cache.size > 1) {
    const [k, v] = cache.entries().next().value;
    cache.delete(k);
    cached -= v.size;
    URL.revokeObjectURL(v.href);
  }
}

/** An object URL for an engine image or font URL ('/r/…', '/o/…', '/font?…'). */
export function media(url, { signal } = {}) {
  const hit = cache.get(url);
  if (hit) { cache.delete(url); cache.set(url, hit); return Promise.resolve(hit.href); }
  let pr = inflight.get(url);
  if (!pr) {
    const ctl = new AbortController();
    pr = request('GET', url, { lane: url.startsWith('/font') ? 'api' : 'media', signal: ctl.signal }).then((res) => {
      if (res.status !== 200) throw new Error(json(res).error || `HTTP ${res.status}`);
      const href = URL.createObjectURL(new Blob([res.body], { type: res.ctype }));
      remember(url, href, res.body.byteLength);
      return href;
    }).finally(() => inflight.delete(url));
    pr.abort = () => ctl.abort();
    pr.waiters = 0;
    inflight.set(url, pr);
  }
  if (!signal) { pr.waiters = Infinity; return pr; }
  // Several callers can wait for one render; it is cancelled only when all have given up.
  pr.waiters++;
  return new Promise((resolve, reject) => {
    signal.addEventListener('abort', () => {
      reject(new DOMException('aborted', 'AbortError'));
      if (--pr.waiters <= 0 && inflight.get(url) === pr) pr.abort();
    }, { once: true });
    pr.then(resolve, reject);
  });
}

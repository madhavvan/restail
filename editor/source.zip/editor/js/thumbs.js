// Page thumbnails: navigate, multi-select, drag to reorder, page actions.
import { $, h, icon, toast, menu, confirmBox } from './util.js';
import { bus, activeDoc, run, undoIfLast } from './state.js';
import { V, goToPage } from './viewer.js';
import { docTools } from './dialogs.js';
import { media } from './engine.js';

const root = $('#thumbs');
const countEl = $('#page-count');
let items = [];
let anchor = null;
let dragFrom = null;

// As in the main view, thumbnails that only fly past in a fast scroll are not rendered.
let lastScroll = 0;
root.addEventListener('scroll', () => { lastScroll = performance.now(); }, { passive: true });
const io = new IntersectionObserver((entries) => {
  for (const en of entries) {
    const t = en.target._t;
    t.vis = en.isIntersecting;
    clearTimeout(t.wake);
    if (!t.vis) continue;
    if (performance.now() - lastScroll > 150) load(t);
    else t.wake = setTimeout(() => { if (t.vis) load(t); }, 140);
  }
}, { root, rootMargin: '400px 0px' });

function scaleFor(p) {
  const dpr = window.devicePixelRatio || 1;
  return Math.max(0.05, Math.round(((128 * dpr) / Math.max(p.w, p.h * 0.77)) * 100) / 100);
}

function load(t) {
  const doc = activeDoc();
  if (!doc) return;
  const p = doc.pages[t.n];
  if (!p) return;
  const url = `/r/${doc.id}/${t.n}?s=${scaleFor(p)}&v=${p.v}`;
  if (t.img.dataset.src === url) return;
  t.img.dataset.src = url;
  media(url).then((href) => { if (t.img.dataset.src === url) t.img.src = href; }, () => {});
}

export function renderThumbs() {
  const doc = activeDoc();
  for (const t of items) { io.unobserve(t.el); clearTimeout(t.wake); }
  items = [];
  anchor = null;
  root.replaceChildren();
  if (!doc) { countEl.textContent = ''; return; }
  for (const n of [...doc.selPages]) if (n >= doc.pages.length) doc.selPages.delete(n);
  countEl.textContent = String(doc.pages.length);
  doc.pages.forEach((p, n) => {
    const w = 128;
    const hgt = Math.round((p.h / p.w) * w);
    const fw = hgt > 170 ? Math.round((170 / hgt) * w) : w;
    const fh = Math.min(hgt, 170);
    const img = h('img', { alt: `Page ${n + 1}`, draggable: 'false', loading: 'lazy' });
    const frame = h('div.tframe', { style: { width: `${fw}px`, height: `${fh}px` } }, img);
    const acts = h('div.tacts',
      h('button', { title: 'Rotate right', on: { click: (e) => { e.stopPropagation(); rotate(doc, [n], 90); } } }, icon('rotcw')),
      h('button', { title: 'Delete page', on: { click: (e) => { e.stopPropagation(); remove(doc, [n]); } } }, icon('trash')));
    const el = h('div.thumb', { draggable: 'true', dataset: { n } }, frame, acts, h('div.num', String(n + 1)));
    const t = { n, el, img };
    el._t = t;
    el.addEventListener('click', (e) => clickThumb(doc, n, e));
    el.addEventListener('contextmenu', (e) => { e.preventDefault(); if (!doc.selPages.has(n)) { doc.selPages = new Set([n]); paintSel(doc); } pageMenu(doc, { x: e.clientX, y: e.clientY }); });
    el.addEventListener('dragstart', (e) => {
      if (!doc.selPages.has(n)) { doc.selPages = new Set([n]); paintSel(doc); }
      dragFrom = [...doc.selPages].sort((a, b) => a - b);
      e.dataTransfer.effectAllowed = 'move';
      e.dataTransfer.setData('text/x-folio-pages', dragFrom.join(','));
      for (const i of dragFrom) items[i] && items[i].el.classList.add('dragging');
    });
    el.addEventListener('dragend', () => { dragFrom = null; clearDrop(); for (const i of items) i.el.classList.remove('dragging'); });
    el.addEventListener('dragover', (e) => {
      if (!dragFrom) return;
      e.preventDefault();
      clearDrop();
      const r = el.getBoundingClientRect();
      el.classList.add(e.clientY < r.top + r.height / 2 ? 'drop-before' : 'drop-after');
    });
    el.addEventListener('drop', (e) => {
      if (!dragFrom) return;
      e.preventDefault();
      const r = el.getBoundingClientRect();
      const before = e.clientY < r.top + r.height / 2;
      let target = before ? n : n + 1;
      const moving = dragFrom;
      clearDrop();
      target -= moving.filter((p) => p < target).length;
      if (moving.length === 1 && moving[0] === target) return;
      movePages(doc, moving, target);
    });
    items.push(t);
    root.appendChild(el);
    io.observe(el);
  });
  paintSel(doc);
  paintCurrent(V.current);
}

function clearDrop() { for (const t of items) t.el.classList.remove('drop-before', 'drop-after'); }

function clickThumb(doc, n, e) {
  if (e.shiftKey && anchor != null) {
    const [a, b] = [Math.min(anchor, n), Math.max(anchor, n)];
    doc.selPages = new Set(Array.from({ length: b - a + 1 }, (_, i) => a + i));
  } else if (e.ctrlKey || e.metaKey) {
    if (doc.selPages.has(n)) doc.selPages.delete(n); else doc.selPages.add(n);
    anchor = n;
  } else {
    doc.selPages = new Set([n]);
    anchor = n;
    goToPage(n);
  }
  paintSel(doc);
  bus.emit('page-selection');
}

function paintSel(doc) {
  for (const t of items) t.el.classList.toggle('selected', doc.selPages.has(t.n) && doc.selPages.size > 0);
}

function paintCurrent(n) {
  for (const t of items) t.el.classList.toggle('current', t.n === n);
  const cur = items[n];
  if (cur) {
    const r = cur.el.getBoundingClientRect();
    const rr = root.getBoundingClientRect();
    if (r.top < rr.top || r.bottom > rr.bottom) cur.el.scrollIntoView({ block: 'nearest' });
  }
}

function targets(doc) {
  return doc.selPages.size ? [...doc.selPages].sort((a, b) => a - b) : [V.current];
}

export async function rotate(doc, pages, delta) {
  try { await run(doc, '/pages/rotate', { pages, delta }); } catch (e) { toast(e.message, { type: 'error' }); }
}

export async function remove(doc, pages) {
  if (pages.length >= doc.pages.length) { toast('A PDF needs at least one page.'); return; }
  if (pages.length > 1 && !(await confirmBox('Delete pages?', `Delete ${pages.length} pages? You can undo this.`, { ok: 'Delete', danger: true }))) return;
  try {
    await run(doc, '/pages/delete', { pages });
    doc.selPages.clear();
    const label = doc.info.undo_label;
    toast(`Deleted ${pages.length} page${pages.length === 1 ? '' : 's'}.`, { action: 'Undo', onAction: () => undoIfLast(doc, label) });
  }
  catch (e) { toast(e.message, { type: 'error' }); }
}

async function movePages(doc, pages, to) {
  try {
    const r = await run(doc, '/pages/move', { pages, to });
    doc.selPages = new Set(r.pages || []);
    paintSel(doc);
  } catch (e) { toast(e.message, { type: 'error' }); }
}

export function pageMenu(doc, at) {
  const sel = targets(doc);
  const label = sel.length > 1 ? `${sel.length} pages` : `page ${sel[0] + 1}`;
  menu(at, [
    { header: label },
    { label: 'Rotate right', icon: 'rotcw', run: () => rotate(doc, sel, 90) },
    { label: 'Rotate left', icon: 'rotccw', run: () => rotate(doc, sel, 270) },
    { label: 'Duplicate', icon: 'dup', run: () => run(doc, '/pages/duplicate', { pages: sel }).catch((e) => toast(e.message, { type: 'error' })) },
    '-',
    { label: 'Insert blank page after', icon: 'pageadd', run: () => run(doc, '/pages/blank', { at: sel[sel.length - 1] + 1 }).catch((e) => toast(e.message, { type: 'error' })) },
    { label: 'Insert pages from file after…', icon: 'merge', run: () => docTools.insertFile(doc, sel[sel.length - 1] + 1) },
    { label: `Extract ${label} as PDF…`, icon: 'split', run: () => docTools.extract(doc, sel) },
    '-',
    { label: `Delete ${label}`, icon: 'trash', danger: true, run: () => remove(doc, sel) },
  ]);
}

export function initThumbs() {
  bus.on('active', () => renderThumbs());
  bus.on('doc-info', ({ doc, structural, changed }) => {
    if (doc !== activeDoc()) return;
    if (structural) { renderThumbs(); return; }
    for (const n of changed) if (items[n]) load(items[n]);
  });
  bus.on('current-page', (n) => paintCurrent(n));
  root.addEventListener('keydown', (e) => {
    const doc = activeDoc();
    if (!doc) return;
    // these act on pages here; they must not also reach the selected object on the page
    if (e.key === 'Delete' || e.key === 'Backspace') { e.preventDefault(); e.stopPropagation(); remove(doc, targets(doc)); }
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'a') { e.preventDefault(); doc.selPages = new Set(doc.pages.map((_, i) => i)); paintSel(doc); }
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
      e.preventDefault();
      e.stopPropagation();
      const n = Math.max(0, Math.min(doc.pages.length - 1, V.current + (e.key === 'ArrowDown' ? 1 : -1)));
      doc.selPages = new Set([n]); anchor = n; paintSel(doc); goToPage(n);
    }
  });
  $('#side-add').replaceChildren(icon('pageadd', 'sm'));
  $('#side-add').addEventListener('click', () => { const doc = activeDoc(); if (doc) docTools.insertFile(doc, doc.pages.length); });
}

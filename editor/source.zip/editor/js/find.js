// Find & replace across the whole document.
import { $, h, icon, toast, debounce, isGlobalShortcut } from './util.js';
import { api, docUrl } from './api.js';
import { bus, activeDoc, run, undoIfLast } from './state.js';
import { V, refreshUI, scrollRectIntoView } from './viewer.js';

const bar = $('#findbar');
let q; let r; let count; let caseBtn; let wholeBtn; let replaceRow;
const st = { open: false, case: false, whole: false, replace: false, seq: 0 };

function build() {
  q = h('input.input', { placeholder: 'Find in document', spellcheck: false, 'aria-label': 'Find' });
  r = h('input.input', { placeholder: 'Replace with', spellcheck: false, 'aria-label': 'Replace with' });
  count = h('span.count', '');
  caseBtn = h('button.tog', { title: 'Match case', on: { click: () => { st.case = !st.case; caseBtn.classList.toggle('on', st.case); search(); } } }, 'Aa');
  wholeBtn = h('button.tog', { title: 'Whole words', on: { click: () => { st.whole = !st.whole; wholeBtn.classList.toggle('on', st.whole); search(); } } }, 'W');
  replaceRow = h('div.row', { hidden: true }, r,
    h('button.btn', { on: { click: replaceOne } }, 'Replace'),
    h('button.btn', { on: { click: replaceAll } }, 'All'));
  bar.replaceChildren(
    h('div.row', q, count, caseBtn, wholeBtn,
      h('button.icon-btn.small', { title: 'Previous (Shift+Enter)', style: { transform: 'rotate(180deg)' }, on: { click: () => step(-1) } }, icon('chev', 'sm')),
      h('button.icon-btn.small', { title: 'Next (Enter)', on: { click: () => step(1) } }, icon('chev', 'sm')),
      h('button.icon-btn.small', { title: 'Replace', on: { click: () => toggleReplace() } }, icon('rename', 'sm')),
      h('button.icon-btn.small', { title: 'Close (Esc)', on: { click: close } }, icon('close', 'sm'))),
    replaceRow);
  q.addEventListener('input', debounce(() => search(), 220));  // (not search(event): that would be the quiet re-search)
  q.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); step(e.shiftKey ? -1 : 1); }
    if (e.key === 'Escape') { e.preventDefault(); close(); }
    if (!isGlobalShortcut(e)) e.stopPropagation();
  });
  r.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); replaceOne(); }
    if (e.key === 'Escape') { e.preventDefault(); close(); }
    if (!isGlobalShortcut(e)) e.stopPropagation();
  });
}

function toggleReplace(on) {
  st.replace = on ?? !st.replace;
  replaceRow.hidden = !st.replace;
  if (st.replace) r.focus({ preventScroll: true });
}

export function openFind(replace = false) {
  if (!activeDoc()) return;
  if (!q) build();
  bar.hidden = false;
  st.open = true;
  toggleReplace(replace);
  const sel = getSelection().toString().trim();
  if (sel && sel.length < 80 && !sel.includes('\n')) { q.value = sel; search(); }
  (replace && q.value ? r : q).focus({ preventScroll: true });
  q.select();
}

export function close() {
  bar.hidden = true;
  st.open = false;
  V.search = { hits: [], cur: -1 };
  refreshUI();
}

/** `quiet`: re-run after the document changed — keep the place, don't scroll the view. */
async function search(quiet = false) {
  const doc = activeDoc();
  const query = q.value;
  const my = ++st.seq;
  if (!doc || !query) { V.search = { hits: [], cur: -1 }; count.textContent = ''; refreshUI(); return; }
  const was = V.search.hits[V.search.cur];
  try {
    const res = await api.get(docUrl(doc.id, `/search?q=${encodeURIComponent(query)}&case=${st.case ? 1 : 0}&whole=${st.whole ? 1 : 0}`));
    if (my !== st.seq) return;
    const hits = res.hits;
    let cur;
    if (quiet && was) {
      // the same match if it is still there, else the next one after where it was
      cur = hits.findIndex((x) => x.page > was.page || (x.page === was.page && (x.rect[1] > was.rect[1] + 1 ||
        (Math.abs(x.rect[1] - was.rect[1]) <= 1 && x.rect[0] >= was.rect[0] - 1))));
    } else {
      // start from the first hit at/after the current page
      cur = hits.findIndex((x) => x.page >= V.current);
    }
    if (cur < 0) cur = hits.length ? 0 : -1;
    V.search = { hits, cur };
    paint(!quiet);
  } catch (e) { toast(e.message, { type: 'error' }); }
}

function paint(scroll = true) {
  const { hits, cur } = V.search;
  count.textContent = hits.length ? `${cur + 1} of ${hits.length}${hits.length >= 5000 ? '+' : ''}` : (q.value ? 'No results' : '');
  refreshUI();
  if (scroll && cur >= 0) scrollRectIntoView(hits[cur].page, hits[cur].rect);
}

function step(d) {
  const { hits } = V.search;
  if (!hits.length) { search(); return; }
  V.search.cur = (V.search.cur + d + hits.length) % hits.length;
  paint();
}

async function replaceOne() {
  const doc = activeDoc();
  const hit = V.search.hits[V.search.cur];
  if (!doc || !hit) return;
  try {
    const res = await run(doc, '/replace', { q: q.value, r: r.value, case: st.case, whole: st.whole, one: true, page: hit.page, line: hit.line, idx: hit.idx });
    if (!res.count) toast('Couldn’t replace that match (the text may be angled or hidden).');
    await search(true);
    paint();
  } catch (e) { toast(e.message, { type: 'error' }); }
}

async function replaceAll() {
  const doc = activeDoc();
  if (!doc || !q.value) return;
  try {
    const res = await run(doc, '/replace', { q: q.value, r: r.value, case: st.case, whole: st.whole });
    const label = doc.info.undo_label;
    toast(res.count ? `Replaced ${res.count} match${res.count === 1 ? '' : 'es'}.` : 'Nothing to replace.', { type: res.count ? 'ok' : 'info', action: res.count ? 'Undo' : null, onAction: () => undoIfLast(doc, label) });
    await search();
  } catch (e) { toast(e.message, { type: 'error' }); }
}

export function initFind() {
  bus.on('active', () => { if (st.open) close(); });
  bus.on('doc-info', ({ doc }) => { if (st.open && doc === activeDoc() && q && q.value) refreshSoon(); });
  bus.on('search-preview', () => refreshUI());
}
const refreshSoon = debounce(() => search(true), 300);
export const findOpen = () => st.open;

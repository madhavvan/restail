// The page canvas: lazy page rendering, zoom, the selectable text layer and per-page
// overlays (added objects, comments, form fields, search hits, editable lines).
import { $, h, clamp } from './util.js';
import { store, bus, getLayer, getText } from './state.js';
import { media } from './engine.js';

export const PX = 96 / 72;
const viewport = $('#viewport');
const pagesEl = $('#pages');
const STEPS = [0.25, 0.4, 0.5, 0.67, 0.75, 0.9, 1, 1.1, 1.25, 1.5, 1.75, 2, 2.5, 3, 4, 5, 6];

export const V = {
  doc: null,
  k: 1,
  pes: [],
  current: 0,
  search: { hits: [], cur: -1 },
  lift: null,        // { n, id, img } object lifted out of the page render while it moves
  unlift: null,      // { n, id, img } keep painting it until the fresh render lands
  needText: false,
};

const measure = document.createElement('canvas').getContext('2d');

// ------------------------------------------------------------------ zoom
function fitZoom(doc, mode) {
  const vw = Math.max(200, viewport.clientWidth - 56);
  const vh = Math.max(200, viewport.clientHeight - 56);
  const maxW = Math.max(...doc.pages.map((p) => p.w));
  if (mode === 'fit-width') return clamp(vw / (maxW * PX), 0.1, 6);
  const p = doc.pages[V.current] || doc.pages[0];
  return clamp(Math.min(vw / (p.w * PX), vh / (p.h * PX)), 0.1, 6);
}
export const zoomPercent = () => Math.round((V.doc ? V.doc.view.zoom : 1) * 100);

export function setZoom(mode, anchor) {
  const doc = V.doc;
  if (!doc) return;
  let z;
  if (mode === 'in' || mode === 'out') {
    const cur = doc.view.zoom;
    z = mode === 'in' ? (STEPS.find((s) => s > cur + 0.001) || 6) : ([...STEPS].reverse().find((s) => s < cur - 0.001) || 0.25);
    doc.view.zoomMode = 'custom';
  } else if (typeof mode === 'number') {
    z = clamp(mode, 0.1, 6);
    doc.view.zoomMode = 'custom';
  } else {
    doc.view.zoomMode = mode;
    z = fitZoom(doc, mode);
  }
  applyZoom(z, anchor);
}

function applyZoom(z, anchor) {
  const doc = V.doc;
  const rect = viewport.getBoundingClientRect();
  const ax = anchor ? anchor.x - rect.left : viewport.clientWidth / 2;
  const ay = anchor ? anchor.y - rect.top : viewport.clientHeight / 3;
  const pe = pageAtY(viewport.scrollTop + ay) || V.pes[0];
  const oldK = V.k;
  let ptX = 0; let ptY = 0;
  if (pe) {
    ptY = (viewport.scrollTop + ay - pe.el.offsetTop) / oldK;
    ptX = (viewport.scrollLeft + ax - pe.el.offsetLeft) / oldK;
  }
  doc.view.zoom = z;
  V.k = z * PX;
  for (const p of V.pes) sizePage(p);
  if (pe) {
    viewport.scrollTop = pe.el.offsetTop + ptY * V.k - ay;
    viewport.scrollLeft = pe.el.offsetLeft + ptX * V.k - ax;
  }
  for (const p of V.pes) if (p.visible) { renderUI(p); if (p.lines) buildTextLayer(p, p.lines); }
  reloadImagesSoon();
  bus.emit('zoom', z);
}

let reloadTimer = null;
function reloadImagesSoon() {
  clearTimeout(reloadTimer);
  reloadTimer = setTimeout(() => { for (const p of V.pes) if (p.visible) loadImg(p); }, 140);
}

// ------------------------------------------------------------------ building pages
const io = new IntersectionObserver((entries) => {
  for (const en of entries) {
    const pe = en.target._pe;
    if (!pe) continue;
    pe.visible = en.isIntersecting;
    if (pe.visible) wake(pe);
    else {
      clearTimeout(pe.wake);
      cancelLoad(pe);
      if (V.pes.length > 60) unload(pe);
    }
  }
}, { root: viewport, rootMargin: '1200px 0px' });

// Pages that only fly past in a fast scroll aren't worth rendering: while the view is
// moving, work starts for a page only if it is still near the screen a moment later.
let lastScroll = 0;
function wake(pe) {
  clearTimeout(pe.wake);
  if (performance.now() - lastScroll > 150) { activate(pe); return; }
  pe.wake = setTimeout(() => { if (pe.visible && V.pes[pe.n] === pe) activate(pe); }, 120);
}
function cancelLoad(pe) {
  if (pe.pre && pe.pre.pending) {
    pe.pre.pending = false;
    if (pe.pre.abort) pe.pre.abort();  // a render still queued in the engine is skipped
    pe.pre.src = '';  // drop the request; the page asks again when it comes back
    pe.src = null;
  }
}

export function showDoc(doc) {
  if (V.doc && V.doc !== doc) {
    V.doc.view.scrollTop = viewport.scrollTop;
    V.doc.view.scrollLeft = viewport.scrollLeft;
    V.doc.view.current = V.current;
  }
  V.doc = doc;
  V.lift = null;
  V.search = { hits: [], cur: -1 };
  build();
  if (doc) {
    viewport.scrollTop = doc.view.scrollTop;
    viewport.scrollLeft = doc.view.scrollLeft;
    V.current = doc.view.current || 0;
    onScroll();
  }
}

function build() {
  for (const pe of V.pes) io.unobserve(pe.el);
  pagesEl.replaceChildren();
  V.pes = [];
  const doc = V.doc;
  if (!doc) return;
  const z = doc.view.zoomMode === 'custom' ? doc.view.zoom : fitZoom(doc, doc.view.zoomMode);
  doc.view.zoom = z;
  V.k = z * PX;
  doc.pages.forEach((p, n) => {
    const el = h('div.page', { dataset: { n } });
    const img = h('img.render', { alt: '', draggable: 'false', decoding: 'async' });
    const tl = h('div.textlayer');
    const ui = h('div.ui');
    el.append(h('div.ph', String(n + 1)), img, tl, ui);
    const pe = { n, el, img, tl, ui, p, src: null, visible: false, layer: null, lines: null, layerKey: null, textKey: null };
    el._pe = pe;
    sizePage(pe);
    pagesEl.appendChild(el);
    V.pes.push(pe);
    io.observe(el);
  });
  bus.emit('view-built', doc);
}

function sizePage(pe) {
  pe.el.style.width = `${pe.p.w * V.k}px`;
  pe.el.style.height = `${pe.p.h * V.k}px`;
}

function unload(pe) {
  pe.img.removeAttribute('src');
  pe.src = null;
  pe.tl.replaceChildren();
  pe.lines = null;
  pe.textKey = null;
}

function activate(pe) {
  loadImg(pe);
  ensureLayer(pe);
  if (V.needText) ensureText(pe);
}

function renderScale() {
  const s = V.k * (window.devicePixelRatio || 1);
  return Math.min(6, Math.ceil(s * 4) / 4);
}

export function imgUrl(pe, hide) {
  return `/r/${V.doc.id}/${pe.n}?s=${renderScale()}&v=${pe.p.v}${hide ? `&hide=${hide}` : ''}`;
}

export function loadImg(pe) {
  if (!pe.visible || !V.doc) return;
  const hide = V.lift && V.lift.n === pe.n ? V.lift.id : '';
  const url = imgUrl(pe, hide);
  if (pe.src === url) return;
  pe.src = url;
  const pre = new Image();
  pre.decoding = 'async';
  pre.pending = true;
  pre.onload = () => { pre.pending = false; if (pe.src === url) { pe.img.src = pre.src; pe.el.classList.add('loaded'); bus.emit('page-rendered', pe); } };
  pre.onerror = () => { pre.pending = false; if (pe.src === url) pe.src = null; };
  pe.pre = pre;
  // `url` names the render; the engine (a worker) answers it with an object URL
  const ctl = new AbortController();
  pre.abort = () => ctl.abort();
  media(url, { signal: ctl.signal }).then((href) => { if (pre.pending && pe.src === url) pre.src = href; },
    () => { if (pre.pending) { pre.pending = false; if (pe.src === url) pe.src = null; } });
}

export async function ensureLayer(pe) {
  const doc = V.doc;
  const key = `${pe.p.xref}:${pe.p.v}`;
  if (pe.layerKey === key && pe.layer) { renderUI(pe); return pe.layer; }
  pe.layerKey = key;
  try {
    const layer = await getLayer(doc, pe.n);
    if (V.doc !== doc || pe.layerKey !== key) return null;
    pe.layer = layer;
    renderUI(pe);
    bus.emit('layer', pe);
    return layer;
  } catch (e) { pe.layerKey = null; return null; }
}

export async function ensureText(pe) {
  const doc = V.doc;
  const key = `${pe.p.xref}:${pe.p.v}`;
  if (pe.textKey === key && pe.lines) {
    if (pe.tlK !== V.k) buildTextLayer(pe, pe.lines);  // zoomed while it was off screen
    return pe.lines;
  }
  pe.textKey = key;
  try {
    const lines = await getText(doc, pe.n);
    if (V.doc !== doc || pe.textKey !== key) return null;
    pe.lines = lines;
    buildTextLayer(pe, lines);
    renderUI(pe);
    return lines;
  } catch (e) { pe.textKey = null; return null; }
}

export function setNeedText(on) {
  V.needText = on;
  if (on) for (const pe of V.pes) if (pe.visible) ensureText(pe);
}

// ------------------------------------------------------------------ document updates
bus.on('doc-info', ({ doc, structural, changed }) => {
  if (doc !== V.doc) return;
  if (structural) {
    const st = viewport.scrollTop;
    build();
    viewport.scrollTop = st;
    onScroll();
    return;
  }
  for (const n of changed) {
    const pe = V.pes[n];
    if (!pe) continue;
    pe.p = doc.pages[n];
    if (pe.visible) activate(pe);
  }
  bus.emit('pages-changed', changed);
});

// ------------------------------------------------------------------ scrolling & current page
export function pageAtY(y) {
  let best = null;
  for (const pe of V.pes) {
    if (pe.el.offsetTop <= y + 8) best = pe; else break;
  }
  return best;
}
let scrollRaf = 0;
function onScroll() {
  scrollRaf = 0;
  const pe = pageAtY(viewport.scrollTop + viewport.clientHeight * 0.4);
  const n = pe ? pe.n : 0;
  if (n !== V.current) { V.current = n; bus.emit('current-page', n); }
}
viewport.addEventListener('scroll', () => {
  lastScroll = performance.now();
  if (!scrollRaf) scrollRaf = requestAnimationFrame(onScroll);
}, { passive: true });

export function goToPage(n, { smooth = false, y = null } = {}) {
  const pe = V.pes[clamp(n, 0, V.pes.length - 1)];
  if (!pe) return;
  const top = pe.el.offsetTop - 16 + (y != null ? y * V.k - viewport.clientHeight * 0.3 : 0);
  viewport.scrollTo({ top: Math.max(0, top), behavior: smooth ? 'smooth' : 'auto' });
  V.current = pe.n;
  bus.emit('current-page', pe.n);
}

export function scrollRectIntoView(n, rect) {
  const pe = V.pes[n];
  if (!pe) return;
  const top = pe.el.offsetTop + rect[1] * V.k;
  const bottom = pe.el.offsetTop + rect[3] * V.k;
  if (top < viewport.scrollTop + 60 || bottom > viewport.scrollTop + viewport.clientHeight - 60) {
    viewport.scrollTop = top - viewport.clientHeight * 0.35;
  }
  const left = pe.el.offsetLeft + rect[0] * V.k;
  if (left < viewport.scrollLeft || left > viewport.scrollLeft + viewport.clientWidth - 80) viewport.scrollLeft = left - 80;
}

let resizeTimer;
new ResizeObserver(() => {
  clearTimeout(resizeTimer);
  resizeTimer = setTimeout(() => {
    const doc = V.doc;
    if (doc && doc.view.zoomMode !== 'custom') {
      const z = fitZoom(doc, doc.view.zoomMode);
      if (Math.abs(z - doc.view.zoom) > 0.002) applyZoom(z);
    }
  }, 60);
}).observe(viewport);

viewport.addEventListener('wheel', (e) => {
  if (!e.ctrlKey || !V.doc) return;
  e.preventDefault();
  const factor = Math.exp(-e.deltaY * 0.0022);
  V.doc.view.zoomMode = 'custom';
  applyZoom(clamp(V.doc.view.zoom * factor, 0.1, 6), { x: e.clientX, y: e.clientY });
}, { passive: false });

// ------------------------------------------------------------------ text layer
function buildTextLayer(pe, lines) {
  const k = V.k;
  const frag = document.createDocumentFragment();
  for (const ln of lines) {
    if (!ln.xs || !ln.text.trim()) continue;
    const [x0, y0, x1, y1] = ln.bbox;
    const fs = Math.max(1, (y1 - y0) * k * 0.86);
    const span = document.createElement('span');
    span.textContent = ln.text;
    span.dataset.key = ln.key;
    measure.font = `${fs}px sans-serif`;
    const natural = measure.measureText(ln.text).width || 1;
    span.style.left = `${x0 * k}px`;
    span.style.top = `${y0 * k}px`;
    span.style.fontSize = `${fs}px`;
    span.style.height = `${(y1 - y0) * k}px`;
    span.style.lineHeight = `${(y1 - y0) * k}px`;
    span.style.transform = `scaleX(${((x1 - x0) * k) / natural})`;
    span._ln = ln;
    frag.appendChild(span);
  }
  pe.tl.replaceChildren(frag);
  pe.tlK = k;
}

function utf16ToChar(text) {
  // map UTF-16 offset -> code point index (lines are code-point arrays server-side)
  const map = [];
  let ci = 0;
  for (const ch of text) { for (let i = 0; i < ch.length; i++) map.push(ci); ci++; }
  map.push(ci);
  return map;
}

/** Current text selection on the pages, as rects per page (display points). */
export function selectionRects() {
  const sel = getSelection();
  if (!sel || sel.isCollapsed || !sel.rangeCount) return null;
  const range = sel.getRangeAt(0);
  const out = new Map();
  let text = '';
  for (const pe of V.pes) {
    if (!pe.lines || !pe.tl.firstChild) continue;
    if (!range.intersectsNode(pe.tl)) continue;
    for (const span of pe.tl.children) {
      if (!range.intersectsNode(span)) continue;
      const tn = span.firstChild;
      if (!tn) continue;
      const len = tn.length;
      let a = 0;
      let b = len;
      if (range.startContainer === tn) a = range.startOffset;
      else if (range.startContainer === span) a = range.startOffset ? len : 0;
      if (range.endContainer === tn) b = range.endOffset;
      else if (range.endContainer === span) b = range.endOffset ? len : 0;
      if (b <= a) continue;
      const ln = span._ln;
      const m = utf16ToChar(ln.text);
      const ca = m[a];
      const cb = m[b] - 1;
      if (cb < ca || !ln.xs[ca] || !ln.xs[cb]) continue;
      const r = [ln.xs[ca][0], ln.bbox[1], ln.xs[cb][1], ln.bbox[3]];
      if (!out.has(pe.n)) out.set(pe.n, []);
      out.get(pe.n).push(r);
      text += (text ? '\n' : '') + ln.text.slice(a, b);
    }
  }
  if (!out.size) return null;
  return { pages: out, text };
}

// ------------------------------------------------------------------ overlays
const uiHooks = [];
/** Tools register renderers that add their own overlay elements for a page. */
export function onRenderUI(fn) { uiHooks.push(fn); }

export function renderUI(pe) {
  if (!pe || !V.doc) return;
  const k = V.k;
  const keep = new Map();
  for (const el of pe.ui.querySelectorAll(':scope > [data-keep]')) keep.set(el.dataset.keep, el);
  const out = [];
  // search hits
  V.search.hits.forEach((hit, i) => {
    if (hit.page !== pe.n) return;
    out.push(box('div.search-hit', hit.rect, k, i === V.search.cur ? 'current' : ''));
  });
  const L = pe.layer;
  if (L) {
    for (const a of L.annots) {
      const el = box('div.annot-hit', a.rect, k, store.selection && store.selection.kind === 'annot' && store.selection.id === a.xref && store.selection.n === pe.n ? 'selected' : '');
      el.dataset.annot = a.xref;
      el.title = a.kind === 'text' ? (a.content || 'Note') : a.kind;
      out.push(el);
    }
    for (const o of L.objects) {
      const sel = store.selection && store.selection.kind === 'object' && store.selection.id === o.id && store.selection.n === pe.n;
      const el = box('div.obj', o.rect, k, `${o.type}${sel ? ' selected' : ''}`);
      el.dataset.obj = o.id;
      el._obj = o;
      if (sel) {
        const hs = o.type === 'text' ? ['e', 'w'] : ['nw', 'n', 'ne', 'e', 'se', 's', 'sw', 'w'];
        for (const d of hs) el.appendChild(h('div.h', { class: d, dataset: { h: d } }));
      }
      const lifted = V.lift && V.lift.n === pe.n && V.lift.id === o.id && V.lift.img ? V.lift.img
        : (V.unlift && V.unlift.n === pe.n && V.unlift.id === o.id ? V.unlift.img : null);
      if (lifted) {
        el.classList.add('lifted');
        el.style.backgroundImage = `url("${lifted}")`;
      }
      out.push(el);
    }
    // form fields — persistent elements so typing/tabbing never loses focus
    for (const f of L.fields) {
      const key = `f:${f.xref}`;
      let el = keep.get(key);
      if (!el) el = makeField(pe, f);
      if (!el) continue;
      keep.delete(key);
      placeField(el, f, k);
      out.push(el);
    }
  }
  for (const fn of uiHooks) {
    const extra = fn(pe, k);
    if (extra) out.push(...[].concat(extra));
  }
  for (const [key, el] of keep) if (!key.startsWith('f:')) out.push(el);
  // Update in place: elements that stay (form fields, open editors) are never detached,
  // so a refresh arriving while the user types can't steal focus or end an edit early.
  const wanted = new Set(out);
  for (const child of [...pe.ui.children]) if (!wanted.has(child)) child.remove();
  for (const el of out) if (el.parentNode !== pe.ui) pe.ui.appendChild(el);
}

export function box(tag, rect, k, cls = '') {
  const el = h(tag, { class: cls });
  el.style.left = `${rect[0] * k}px`;
  el.style.top = `${rect[1] * k}px`;
  el.style.width = `${Math.max(1, (rect[2] - rect[0]) * k)}px`;
  el.style.height = `${Math.max(1, (rect[3] - rect[1]) * k)}px`;
  return el;
}

export function refreshUI(n) {
  if (n == null) { for (const pe of V.pes) if (pe.visible) renderUI(pe); }
  else if (V.pes[n]) renderUI(V.pes[n]);
}

// ------------------------------------------------------------------ form fields
let fieldCommit = null;
export function onFieldCommit(fn) { fieldCommit = fn; }

const CHECK_SVG = '<svg viewBox="0 0 24 24"><path d="M4.5 12.5l4.5 4.5L19.5 6.5"/></svg>';
const DOT_SVG = '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="5" fill="#111" stroke="none"/></svg>';

function makeField(pe, f) {
  const k = f.kind;
  let el;
  if (k === 'text') {
    el = f.multiline ? h('textarea.field') : h('input.field', { type: f.password ? 'password' : 'text' });
    el.value = f.value || '';
    if (f.maxlen) el.maxLength = f.maxlen;
    el.spellcheck = false;
    el.addEventListener('change', () => fieldCommit && fieldCommit(pe.n, el._f, el.value));
    el.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !f.multiline) { e.preventDefault(); el.blur(); }
      if (e.key === 'Escape') { el.value = el._f.value || ''; el.blur(); }
    });
  } else if (k === 'checkbox' || k === 'radio') {
    el = h('div.field.check', { class: k === 'radio' ? 'radio' : '', tabindex: 0, role: k, title: f.name });
    const toggle = () => { if (!el._f.readonly) fieldCommit && fieldCommit(pe.n, el._f, k === 'radio' ? true : !el._f.checked); };
    el.addEventListener('click', toggle);
    el.addEventListener('keydown', (e) => { if (e.key === ' ' || e.key === 'Enter') { e.preventDefault(); toggle(); } });
  } else if (k === 'combo' || k === 'list') {
    el = h('select.field');
    // [value stored in the file, text shown]
    for (const o of f.options || []) {
      const [val, label] = Array.isArray(o) ? o : [o, o];
      el.appendChild(h('option', { value: val }, label));
    }
    el.value = f.value || '';
    el.addEventListener('change', () => fieldCommit && fieldCommit(pe.n, el._f, el.value));
  } else {
    return null;
  }
  el.dataset.keep = `f:${f.xref}`;
  el.title = f.label || f.name;
  return el;
}

function placeField(el, f, k) {
  el._f = f;
  const [x0, y0, x1, y1] = f.rect;
  el.style.left = `${x0 * k}px`;
  el.style.top = `${y0 * k}px`;
  el.style.width = `${(x1 - x0) * k}px`;
  el.style.height = `${(y1 - y0) * k}px`;
  const fs = f.fontsize ? f.fontsize * k : Math.min((y1 - y0) * k * 0.7, 14 * k);
  el.style.fontSize = `${Math.max(7, fs)}px`;
  el.classList.toggle('ro', !!f.readonly);
  if (f.kind === 'checkbox' || f.kind === 'radio') {
    el.innerHTML = f.checked ? (f.kind === 'radio' ? DOT_SVG : CHECK_SVG) : '';
    el.setAttribute('aria-checked', f.checked ? 'true' : 'false');
  } else if (document.activeElement !== el) {
    el.value = f.value || '';
  }
}

// ------------------------------------------------------------------ helpers for tools
export function pageFromEvent(e) {
  const el = e.target.closest && e.target.closest('.page');
  return el ? el._pe : null;
}
export function ptIn(pe, e) {
  const r = pe.el.getBoundingClientRect();
  return { x: (e.clientX - r.left) / V.k, y: (e.clientY - r.top) / V.k };
}
export function sampleBg(pe, rect) {
  // average colour just outside a rect on the rendered page (for editors that cover text)
  try {
    const img = pe.img;
    if (!img.complete || !img.naturalWidth) return '#ffffff';
    const c = $('#sampler');
    const ctx = c.getContext('2d', { willReadFrequently: true });
    const sx = img.naturalWidth / (pe.p.w);
    const pts = [[rect[0] - 2, rect[1] + 1], [rect[2] + 2, rect[1] + 1], [rect[0] - 2, rect[3] - 1], [rect[2] + 2, rect[3] - 1],
      [(rect[0] + rect[2]) / 2, rect[1] - 1.5], [(rect[0] + rect[2]) / 2, rect[3] + 1.5]];
    const counts = new Map();
    for (const [x, y] of pts) {
      ctx.clearRect(0, 0, 1, 1);
      ctx.drawImage(img, Math.round(clamp(x, 0, pe.p.w - 1) * sx), Math.round(clamp(y, 0, pe.p.h - 1) * sx), 1, 1, 0, 0, 1, 1);
      const d = ctx.getImageData(0, 0, 1, 1).data;
      const key = `${d[0] >> 3},${d[1] >> 3},${d[2] >> 3}`;
      const prev = counts.get(key) || { n: 0, c: d };
      prev.n += 1;
      counts.set(key, prev);
    }
    const best = [...counts.values()].sort((a, b) => b.n - a.n)[0].c;
    return `rgb(${best[0]},${best[1]},${best[2]})`;
  } catch { return '#ffffff'; }
}

export function setLift(n, id, objImgUrl) {
  const prev = V.lift;
  V.lift = id ? { n, id, img: objImgUrl } : null;
  if (prev && V.pes[prev.n]) loadImg(V.pes[prev.n]);
  if (V.lift && V.pes[n]) loadImg(V.pes[n]);
}

export { viewport, pagesEl };

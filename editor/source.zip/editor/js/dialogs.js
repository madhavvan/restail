// Whole-document tools, each as a small dialog.
// Browser build: files come from the page's file chooser and results download.
import { h, toast, modal, confirmBox, busy, fmtBytes, swatches } from './util.js';
import { api, docUrl } from './api.js';
import { bus, run, upsertDoc, undoIfLast } from './state.js';
import { V } from './viewer.js';
import { media } from './engine.js';
import { pickFiles, download } from './web.js';

const PDF_ACCEPT = '.pdf,application/pdf';
const IMAGE_ACCEPT = '.png,.jpg,.jpeg,.gif,.bmp,.tif,.tiff,.webp,image/*';

function choice(name, value, title, desc, checked) {
  const inp = h('input', { type: 'radio', name, value, checked });
  const el = h('label.choice', { class: checked ? 'on' : '' }, inp, h('div', h('b', title), desc ? h('span', desc) : null));
  inp.addEventListener('change', () => {
    for (const c of el.parentElement.querySelectorAll('.choice')) c.classList.toggle('on', c.querySelector('input').checked);
  });
  return el;
}
const picked = (root, name) => (root.querySelector(`input[name="${name}"]:checked`) || {}).value;

/** Run a route that answers with a file and download what it made. */
async function downloadFrom(path, body, label) {
  const r = await withBusy(label, () => api.file(path, body));
  download(r.bytes, r.name, r.type);
  return r;
}

function pageScope(doc, name = 'scope') {
  const range = h('input.input', { placeholder: 'e.g. 1-3, 5', style: { marginTop: '6px' } });
  const box = h('div',
    choice(name, 'all', 'All pages', null, true),
    choice(name, 'current', `Current page (${V.current + 1})`, null, false),
    doc.selPages.size > 1 ? choice(name, 'selected', `Selected pages (${doc.selPages.size})`, null, false) : null,
    choice(name, 'range', 'Pages…', null, false), range);
  range.addEventListener('focus', () => { box.querySelector(`input[value="range"]`).checked = true; box.querySelector(`input[value="range"]`).dispatchEvent(new Event('change')); });
  box.pages = () => {
    const v = picked(box, name);
    const n = doc.pages.length;
    if (v === 'current') return [V.current];
    if (v === 'selected') return [...doc.selPages].sort((a, b) => a - b);
    if (v === 'range') return parseRange(range.value, n);
    return null;
  };
  return box;
}

export function parseRange(spec, n) {
  const out = new Set();
  for (const part of spec.split(/[,;]/)) {
    const p = part.trim();
    if (!p) continue;
    const m = /^(\d*)\s*-\s*(\d*)$/.exec(p);
    let a; let b;
    if (m) { a = m[1] ? +m[1] : 1; b = m[2] ? +m[2] : n; } else if (/^\d+$/.test(p)) { a = b = +p; } else throw new Error(`Can't read the page range "${p}".`);
    for (let i = Math.max(1, a); i <= Math.min(n, b); i++) out.add(i - 1);
  }
  if (!out.size) throw new Error('That page range is empty.');
  return [...out].sort((x, y) => x - y);
}

/** A dialog's main button: a bad page range keeps the dialog open with the message. */
function validScope(scope) {
  try { scope.pages(); return true; } catch (e) { toast(e.message); return false; }
}

async function withBusy(label, fn) {
  const done = busy(label);
  try { return await fn(); } finally { done(); }
}

export const docTools = {
  // ---------------------------------------------------------------- compress
  async compress(doc) {
    const sizeEl = h('b', '…');
    api.get(docUrl(doc.id, '/size')).then((r) => { sizeEl.textContent = fmtBytes(r.size); }).catch(() => {});
    const target = h('input.input.num', { type: 'number', min: 0.1, step: 0.1, value: 2 });
    const gray = h('input', { type: 'checkbox' });
    const body = h('div',
      h('p', 'Current size: ', sizeEl, '. Images are re-sampled and re-compressed; text and drawings stay sharp.'),
      choice('cmode', 'balanced', 'Balanced', 'Good quality, much smaller — best for most files.', true),
      choice('cmode', 'light', 'Light', 'Keeps images crisp; smaller savings.', false),
      choice('cmode', 'strong', 'Strong', 'Smallest while still readable.', false),
      h('label.choice', h('input', { type: 'radio', name: 'cmode', value: 'target' }), h('div', h('b', 'Fit under a size limit'), h('span', 'For upload forms that reject big files.'),
        h('div.row', { style: { marginTop: '8px', marginBottom: 0 } }, target, h('span', 'MB')))),
      h('label', { style: { display: 'flex', alignItems: 'center', gap: '8px', marginTop: '6px', cursor: 'pointer' } }, gray, 'Also convert images to grayscale'));
    target.addEventListener('focus', () => { body.querySelector('input[value="target"]').checked = true; body.querySelector('input[value="target"]').dispatchEvent(new Event('change')); });
    for (const inp of body.querySelectorAll('input[name=cmode]')) {
      inp.addEventListener('change', () => body.querySelectorAll('.choice').forEach((c) => c.classList.toggle('on', c.querySelector('input').checked)));
    }
    const mode = await modal({ title: 'Compress PDF', body, buttons: [{ label: 'Cancel', value: null }, { label: 'Compress', primary: true, run: () => picked(body, 'cmode') }] });
    if (!mode) return;
    const req = mode === 'target' ? { target_mb: parseFloat(target.value) || 2, gray: gray.checked } : { preset: mode, gray: gray.checked };
    try {
      const r = await withBusy('Compressing…', () => run(doc, '/compress', req));
      const saved = r.before - r.after;
      if (saved <= 0) { toast('This PDF is already as small as Folio can make it without losing quality.'); return; }
      const pct = Math.round((saved / r.before) * 100);
      const msg = `${r.before_h} → ${r.after_h} (−${pct}%)` + (mode === 'target' && !r.reached ? ' — still above your limit; try grayscale or remove pages.' : '');
      const label = doc.info.undo_label;
      toast(`Compressed: ${msg}. Save to keep it.`, { type: 'ok', ms: 7000, action: 'Undo', onAction: () => undoIfLast(doc, label) });
    } catch (e) { toast(e.message, { type: 'error' }); }
  },

  // ---------------------------------------------------------------- convert
  async exportImages(doc) {
    const scope = pageScope(doc, 'iscope');
    const body = h('div',
      h('div.row', h('label', 'Format'), h('select.input#ifmt', h('option', { value: 'png' }, 'PNG (sharp, larger)'), h('option', { value: 'jpg' }, 'JPEG (photos, smaller)'))),
      h('div.row', h('label', 'Quality'), h('select.input#idpi', h('option', { value: 96 }, 'Screen (96 dpi)'), h('option', { value: 150, selected: true }, 'Standard (150 dpi)'), h('option', { value: 300 }, 'Print (300 dpi)'))),
      h('h3', { style: { margin: '14px 0 8px', fontSize: '12px', textTransform: 'uppercase', color: 'var(--text-3)' } }, 'Pages'), scope);
    const ok = await modal({ title: 'Export pages as images', body, buttons: [{ label: 'Cancel', value: null }, { label: 'Export', primary: true, run: () => validScope(scope) }] });
    if (!ok) return;
    try {
      const pages = scope.pages();
      const r = await downloadFrom(docUrl(doc.id, '/export-images'), { fmt: body.querySelector('#ifmt').value, dpi: +body.querySelector('#idpi').value, ...(pages ? { pages } : {}) }, 'Exporting…');
      const n = r.meta.count || 1;
      toast(`Downloaded ${n} image${n === 1 ? '' : 's'}${n > 1 ? ' (in one .zip)' : ''}.`, { type: 'ok', ms: 5000 });
    } catch (e) { toast(e.message, { type: 'error' }); }
  },

  // ---------------------------------------------------------------- pages
  async insertFile(doc, at) {
    const files = await pickFiles({ accept: `${PDF_ACCEPT},${IMAGE_ACCEPT}` });
    if (!files.length) return;
    try {
      const [path] = await api.stage(files);
      const r = await withBusy('Inserting…', () => run(doc, '/pages/insert-file', { at: at ?? doc.pages.length, path }));
      toast(`Inserted ${r.pages.length} page${r.pages.length === 1 ? '' : 's'}.`, { type: 'ok' });
    } catch (e) { toast(e.message, { type: 'error' }); }
  },

  async split(doc) {
    const n = doc.pages.length;
    const ranges = h('input.input', { placeholder: 'e.g. 1-3, 4-6, 7', spellcheck: false });
    const every = h('input.input.num', { type: 'number', min: 1, max: n, value: 1 });
    const body = h('div',
      h('label.choice.on', h('input', { type: 'radio', name: 'smode', value: 'extract', checked: true }), h('div', h('b', 'Extract pages into one new PDF'), h('span', 'Uses the pages you type below (or the pages selected in the sidebar).'))),
      h('label.choice', h('input', { type: 'radio', name: 'smode', value: 'ranges' }), h('div', h('b', 'Split into several PDFs'), h('span', 'One file per range below.'))),
      h('div.row.stack', { style: { margin: '4px 0 12px' } }, h('label', 'Page ranges'), ranges),
      h('label.choice', h('input', { type: 'radio', name: 'smode', value: 'every' }), h('div', h('b', 'Split every N pages'),
        h('div.row', { style: { marginTop: '8px', marginBottom: 0 } }, h('span', 'Every'), every, h('span', 'page(s)')))));
    for (const inp of body.querySelectorAll('input[name=smode]')) inp.addEventListener('change', () => body.querySelectorAll('.choice').forEach((c) => c.classList.toggle('on', c.querySelector('input').checked)));
    if (doc.selPages.size) ranges.value = compactRanges([...doc.selPages]);
    const mode = await modal({ title: 'Split or extract pages', body, buttons: [{ label: 'Cancel', value: null }, { label: 'Continue…', primary: true, run: () => {
      const m = picked(body, 'smode');
      if (m === 'every') return m;
      if (m === 'extract' && !ranges.value.trim()) {
        if (doc.selPages.size) return m;
        toast('Type the pages to extract, e.g. 2-4.');
        return false;
      }
      try { parseRange(ranges.value, n); return m; } catch (e) { toast(m === 'ranges' && !ranges.value.trim() ? 'Type the page ranges, e.g. 1-3, 4-6.' : e.message); return false; }
    } }] });
    if (!mode) return;
    try {
      if (mode === 'extract') {
        const pages = ranges.value.trim() ? parseRange(ranges.value, n) : (doc.selPages.size ? [...doc.selPages].sort((a, b) => a - b) : null);
        if (!pages) { toast('Type the pages to extract, e.g. 2-4.'); return; }
        const r = await downloadFrom(docUrl(doc.id, '/pages/extract'), { pages }, 'Extracting…');
        toast(`Downloaded ${r.name}`, { type: 'ok', ms: 5000 });
      } else {
        const r = await downloadFrom(docUrl(doc.id, '/pages/split'), mode === 'every' ? { mode: 'every', k: +every.value || 1 } : { mode: 'ranges', spec: ranges.value }, 'Splitting…');
        const n = r.meta.count || 1;
        toast(n > 1 ? `Downloaded ${n} PDFs in ${r.name}` : `Downloaded ${r.name}`, { type: 'ok', ms: 5000 });
      }
    } catch (e) { toast(e.message, { type: 'error' }); }
  },

  async extract(doc, pages) {
    try {
      const r = await downloadFrom(docUrl(doc.id, '/pages/extract'), { pages }, 'Extracting…');
      toast(`Downloaded ${r.name}`, { type: 'ok', ms: 5000 });
    } catch (e) { toast(e.message, { type: 'error' }); }
  },

  // ---------------------------------------------------------------- security
  async protect(doc) {
    const pw = h('input.input', { type: 'password', autocomplete: 'new-password', placeholder: 'Password' });
    const pw2 = h('input.input', { type: 'password', autocomplete: 'new-password', placeholder: 'Repeat password' });
    const allowCopy = h('input', { type: 'checkbox', checked: true });
    const allowEdit = h('input', { type: 'checkbox', checked: true });
    const body = h('div',
      h('p', 'Anyone opening the file will need this password. Folio uses AES-256 encryption.'),
      h('div.row.stack', pw, pw2),
      h('label', { style: { display: 'flex', gap: '8px', alignItems: 'center', margin: '8px 0 4px' } }, allowCopy, 'Allow copying text'),
      h('label', { style: { display: 'flex', gap: '8px', alignItems: 'center' } }, allowEdit, 'Allow editing and form filling'),
      doc.info.protected ? h('p.hint', { style: { marginTop: '12px' } }, 'This document is currently saved with a password.') : null);
    const buttons = [{ label: 'Cancel', value: null }];
    if (doc.info.protected) buttons.push({ label: 'Remove password', danger: true, left: true, value: 'remove' });
    buttons.push({ label: 'Set password', primary: true, run: () => {
      if (!pw.value) { toast('Type a password.'); return false; }
      if (pw.value !== pw2.value) { toast('The passwords don’t match.'); return false; }
      return 'set';
    } });
    const r = await modal({ title: doc.info.protected ? 'Password' : 'Protect with a password', body, buttons });
    if (!r) return;
    try {
      if (r === 'remove') await run(doc, '/protect', { remove: true });
      else await run(doc, '/protect', { password: pw.value, allow_copy: allowCopy.checked, allow_edit: allowEdit.checked });
      toast(r === 'remove' ? 'Password will be removed when you save.' : 'Password will be applied when you save.', { type: 'ok', ms: 5000, action: 'Save now', onAction: () => bus.emit('cmd', 'save') });
    } catch (e) { toast(e.message, { type: 'error' }); }
  },

  // ---------------------------------------------------------------- stamping
  async pageNumbers(doc) {
    const fmt = h('select.input', ['Page {n} of {N}', '{n}', '{n} / {N}', '- {n} -', 'Page {n}'].map((f) => h('option', { value: f }, f.replace('{n}', '3').replace('{N}', String(doc.pages.length)))));
    const pos = h('select.input', [['bottom-center', 'Bottom centre'], ['bottom-right', 'Bottom right'], ['bottom-left', 'Bottom left'], ['top-center', 'Top centre'], ['top-right', 'Top right'], ['top-left', 'Top left']].map(([v, l]) => h('option', { value: v }, l)));
    const size = h('input.input.num', { type: 'number', min: 6, max: 36, value: 10 });
    const start = h('input.input.num', { type: 'number', min: 0, value: 1 });
    const scope = pageScope(doc, 'pnscope');
    const body = h('div', h('div.row', h('label', 'Format'), fmt), h('div.row', h('label', 'Position'), pos),
      h('div.row', h('label', 'Size'), size, h('span.muted', 'pt'), h('div.spacer'), h('label', { style: { width: 'auto' } }, 'Start at'), start),
      h('h3', { style: { margin: '14px 0 8px', fontSize: '12px', textTransform: 'uppercase', color: 'var(--text-3)' } }, 'Pages'), scope,
      h('p.hint', { style: { marginTop: '10px' } }, 'Each number is added as a text box you can move or delete later.'));
    const ok = await modal({ title: 'Add page numbers', body, buttons: [{ label: 'Cancel', value: null }, { label: 'Add', primary: true, run: () => validScope(scope) }] });
    if (!ok) return;
    try {
      const pages = scope.pages();
      await withBusy('Numbering pages…', () => run(doc, '/page-numbers', { fmt: fmt.value, position: pos.value, size: +size.value || 10, start: +start.value || 1, ...(pages ? { pages } : {}) }));
      toast('Page numbers added.', { type: 'ok' });
    } catch (e) { toast(e.message, { type: 'error' }); }
  },

  async watermark(doc) {
    const text = h('input.input', { value: 'CONFIDENTIAL' });
    const size = h('input.input.num', { type: 'number', min: 10, max: 200, value: 64 });
    const op = h('input', { type: 'range', min: 5, max: 80, value: 22, style: { flex: 1 } });
    let color = '#888888';
    const scope = pageScope(doc, 'wmscope');
    const body = h('div', h('div.row', h('label', 'Text'), text), h('div.row', h('label', 'Size'), size, h('span.muted', 'pt')),
      h('div.row', h('label', 'Opacity'), op), h('div.row.stack', h('label', 'Colour'), swatches(['#888888', '#d93d42', '#2f6bff', '#000000'], color, (c) => { color = c; })),
      h('h3', { style: { margin: '14px 0 8px', fontSize: '12px', textTransform: 'uppercase', color: 'var(--text-3)' } }, 'Pages'), scope);
    const ok = await modal({ title: 'Add watermark', body, buttons: [{ label: 'Cancel', value: null }, { label: 'Add', primary: true, run: () => {
      if (!text.value.trim()) { toast('Type the watermark text.'); return false; }
      return validScope(scope);
    } }] });
    if (!ok) return;
    try {
      const pages = scope.pages();
      await withBusy('Adding watermark…', () => run(doc, '/watermark', { text: text.value, size: +size.value || 64, opacity: +op.value / 100, color, ...(pages ? { pages } : {}) }));
      toast('Watermark added. Ctrl+Z to undo.', { type: 'ok' });
    } catch (e) { toast(e.message, { type: 'error' }); }
  },

  // ---------------------------------------------------------------- redact by search
  async redactSearch(doc) {
    const q = h('input.input', { placeholder: 'Word, name or number to remove', spellcheck: false });
    const regex = h('input', { type: 'checkbox' });
    const caseS = h('input', { type: 'checkbox' });
    const status = h('div.result-box', { hidden: true });
    let preset = null;
    const presets = [['ssn', 'SSNs'], ['email', 'Emails'], ['phone', 'Phone numbers'], ['card', 'Card numbers'], ['date', 'Dates']];
    const chips = h('div.row', { style: { flexWrap: 'wrap', gap: '6px' } }, presets.map(([v, l]) => h('button.btn', { on: { click: (e) => {
      preset = preset === v ? null : v;
      for (const b of chips.children) b.classList.toggle('primary', b === e.currentTarget && preset === v);
      q.disabled = !!preset;
      status.hidden = true;
    } } }, l)));
    const body = h('div', h('p', 'Find every match in the document, then black it out and remove it permanently.'),
      h('div.row.stack', h('label', 'Common patterns'), chips), h('div.row.stack', h('label', 'Or your own text'), q),
      h('div.row', { style: { gap: '16px' } }, h('label', { style: { display: 'flex', gap: '6px', width: 'auto', alignItems: 'center' } }, caseS, 'Match case'),
        h('label', { style: { display: 'flex', gap: '6px', width: 'auto', alignItems: 'center' } }, regex, 'Regular expression')), status);
    let found = 0;
    const req = () => (preset ? { preset } : { q: q.value, regex: regex.checked, case: caseS.checked });
    const res = await modal({ title: 'Redact by search', body, enterId: 'rs-find', buttons: [
      { label: 'Cancel', value: null },
      { label: 'Find', id: 'rs-find', run: async () => {
        if (!preset && !q.value.trim()) { toast('Pick a pattern or type something.'); return false; }
        const r = await api.post(docUrl(doc.id, '/redact-search'), { ...req(), preview: true });
        found = r.count;
        status.hidden = false;
        status.replaceChildren(h('div.big', `${r.count} match${r.count === 1 ? '' : 'es'}`), r.count ? h('div.hint', `On page${r.pages.length === 1 ? '' : 's'} ${r.pages.slice(0, 20).map((p) => p + 1).join(', ')}${r.pages.length > 20 ? '…' : ''}: ${r.hits.slice(0, 4).map((x) => `“${x.text}”`).join(', ')}${r.hits.length > 4 ? '…' : ''}`) : null);
        V.search = { hits: r.hits.map((x) => ({ page: x.page, rect: x.rect })), cur: -1 };
        bus.emit('search-preview');
        return false;
      } },
      { label: 'Redact all', primary: true, danger: false, run: async () => {
        if (!preset && !q.value.trim()) { toast('Pick a pattern or type something.'); return false; }
        return true;
      } },
    ] });
    V.search = { hits: [], cur: -1 };
    bus.emit('search-preview');
    if (!res) return;
    try {
      const r = await withBusy('Redacting…', () => run(doc, '/redact-search', req()));
      toast(r.count ? `Redacted ${r.count} match${r.count === 1 ? '' : 'es'}. Save to make it permanent.` : 'Nothing matched — nothing was redacted.', { type: r.count ? 'ok' : 'info', ms: 6000 });
    } catch (e) { toast(e.message, { type: 'error' }); }
    void found;
  },

  // ---------------------------------------------------------------- print
  async print(doc) {
    // Pages are rendered at print resolution (~216 dpi) into a hidden frame and handed to
    // the system print dialog, so printing never depends on another PDF app.
    const done = busy(`Preparing ${doc.pages.length} page${doc.pages.length === 1 ? '' : 's'} for printing…`);
    const frame = h('iframe', { title: 'print', style: { position: 'fixed', right: '0', bottom: '0', width: '0', height: '0', border: '0', visibility: 'hidden' } });
    document.body.appendChild(frame);
    try {
      const fd = frame.contentDocument;
      const first = doc.pages[0];
      fd.open();
      fd.write('<!doctype html><html><head><meta charset="utf-8"><title></title></head><body></body></html>');
      fd.close();
      const st = fd.createElement('style');
      st.textContent = `@page { size: ${first.w}pt ${first.h}pt; margin: 0 } html, body { margin: 0; padding: 0; background: #fff }
        .pg { break-after: page; display: flex; align-items: center; justify-content: center; overflow: hidden }
        .pg:last-child { break-after: auto } .pg img { display: block; max-width: 100%; max-height: 100% }`;
      fd.head.appendChild(st);
      const loads = [];
      for (const [n, p] of doc.pages.entries()) {
        const box = fd.createElement('div');
        box.className = 'pg';
        box.style.width = `${first.w}pt`;
        box.style.height = `${first.h}pt`;
        const img = fd.createElement('img');
        img.src = await media(`/r/${doc.id}/${n}?s=3&v=${p.v}`);
        if (Math.abs(p.w / p.h - first.w / first.h) > 0.01) img.style.objectFit = 'contain';
        box.appendChild(img);
        fd.body.appendChild(box);
        loads.push(img.decode().catch(() => {}));
      }
      await Promise.all(loads);
      done();
      frame.contentWindow.focus();
      frame.contentWindow.print();
    } catch (e) {
      done();
      toast(`Couldn’t print: ${e.message}`, { type: 'error' });
    } finally {
      setTimeout(() => frame.remove(), 1000);
    }
  },

  // ---------------------------------------------------------------- misc
  async flatten(doc) {
    const ok = await confirmBox('Flatten form?', 'Filled-in fields become regular page content: they look the same everywhere but can’t be edited as fields anymore. You can undo this until you close the file.', { ok: 'Flatten' });
    if (!ok) return;
    try { await run(doc, '/flatten', { what: 'forms' }); toast('Form flattened.', { type: 'ok' }); }
    catch (e) { toast(e.message, { type: 'error' }); }
  },

  async flattenAll(doc) {
    const ok = await confirmBox('Flatten everything?', 'Form fields AND comments/highlights become part of the page. Useful before sending a final copy.', { ok: 'Flatten' });
    if (!ok) return;
    try { await run(doc, '/flatten', { what: 'all' }); toast('Flattened.', { type: 'ok' }); }
    catch (e) { toast(e.message, { type: 'error' }); }
  },

  async properties(doc) {
    const m = doc.info.meta || {};
    const fields = ['title', 'author', 'subject', 'keywords'].map((k) => [k, h('input.input', { value: m[k] || '' })]);
    const body = h('div', fields.map(([k, inp]) => h('div.row', h('label', k[0].toUpperCase() + k.slice(1)), inp)));
    const ok = await modal({ title: 'Document properties', body, buttons: [{ label: 'Cancel', value: null }, { label: 'Apply', primary: true, run: () => true }] });
    if (!ok) return;
    try { await run(doc, '/metadata', Object.fromEntries(fields.map(([k, inp]) => [k, inp.value]))); toast('Properties updated.', { type: 'ok' }); }
    catch (e) { toast(e.message, { type: 'error' }); }
  },

  async scrub(doc) {
    const ok = await confirmBox('Remove hidden data?', 'Removes author/title metadata, embedded attachments, JavaScript and page thumbnails. The visible content doesn’t change.', { ok: 'Remove' });
    if (!ok) return;
    try { await run(doc, '/scrub'); toast('Hidden data removed. Save to keep it.', { type: 'ok' }); }
    catch (e) { toast(e.message, { type: 'error' }); }
  },
};

export const fileTools = {
  async imagesToPdf() {
    const body = h('div', h('p', 'Pick one or more images. Each becomes a page, in the order you select them.'),
      choice('psize', 'letter', 'Letter', '8.5 × 11 in, image fitted with a small margin', true),
      choice('psize', 'a4', 'A4', '210 × 297 mm', false),
      choice('psize', 'fit', 'Same shape as the image', 'No margins', false));
    const size = await modal({ title: 'Images to PDF', body, buttons: [{ label: 'Cancel', value: null }, { label: 'Choose images…', primary: true, run: () => picked(body, 'psize') }] });
    if (!size) return;
    const files = await pickFiles({ accept: IMAGE_ACCEPT, multiple: true });
    if (!files.length) return;
    try {
      const paths = await api.stage(files);
      const r = await withBusy('Creating PDF…', () => api.post('/api/images-to-pdf', { size, paths }));
      if (r.doc) upsertDoc(r.doc);
    } catch (e) { toast(e.message, { type: 'error' }); }
  },
  async merge() {
    const files = await pickFiles({ accept: `${PDF_ACCEPT},${IMAGE_ACCEPT}`, multiple: true });
    if (!files.length) return;
    if (files.length < 2) toast('Pick two or more files to merge (hold Ctrl or Shift to pick several).');
    try {
      const paths = await api.stage(files);
      const r = await withBusy('Merging…', () => api.post('/api/merge', { paths }));
      if (r.doc) { upsertDoc(r.doc); toast(`Merged into ${r.doc.pages.length} pages. Drag thumbnails to reorder, then save.`, { type: 'ok', ms: 6000 }); }
    } catch (e) { toast(e.message, { type: 'error' }); }
  },
};

export function compactRanges(nums) {
  const s = [...new Set(nums)].sort((a, b) => a - b);
  const out = [];
  for (let i = 0; i < s.length; i++) {
    let j = i;
    while (j + 1 < s.length && s[j + 1] === s[j] + 1) j++;
    out.push(i === j ? `${s[i] + 1}` : `${s[i] + 1}-${s[j] + 1}`);
    i = j;
  }
  return out.join(', ');
}

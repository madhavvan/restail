// Everything the pointer and keyboard do on the pages.
import { $, h, icon, toast, clamp, promptBox, menu, isGlobalShortcut } from './util.js';
import { media } from './engine.js';
import { store, bus, run, setTool, select, getLayer } from './state.js';
import {
  V, pageFromEvent, ptIn, renderUI, refreshUI, box, setNeedText, selectionRects,
  sampleBg, onRenderUI, onFieldCommit, viewport, pagesEl, loadImg,
} from './viewer.js';

const TEXT_TOOLS = new Set(['select', 'edittext', 'highlight']);
const RECT_TOOLS = new Set(['whiteout', 'erase', 'redact', 'shape']);
let draft = null;          // in-progress rectangle / line
let ink = null;            // { n, paths: [[{x,y}]], cur }
let editor = null;         // open line or text-box editor
let drag = null;           // object move/resize in progress
let ghost = null;          // signature/image placement preview
let inflight = null;       // the commit of the last closed editor, until it lands
let busyNow = false;
function setBusy() {
  // work in progress that closing the page would lose (see the beforeunload guard)
  const b = !!(editor || ink || inflight);
  if (b === busyNow) return;
  busyNow = b;
  document.body.dataset.busy = b ? '1' : '';
}
const floatbar = $('#floatbar');

// ------------------------------------------------------------------ fonts for editors
const faceRules = new Map();
export function cssFamily(css) {
  if (!css) return 'Arial, sans-serif';
  const generic = /times|georgia|garamond|cambria|serif|roman|book/i.test(css.family) ? 'serif' : 'sans-serif';
  if (css.system !== false || !css.key) return `"${css.family}", ${generic}`;
  let fam = faceRules.get(css.key);
  if (!fam) {
    fam = `folio-f${faceRules.size}`;
    faceRules.set(css.key, fam);
    // the editor fonts come from the engine; until one arrives the stack's next name shows
    media(`/font?key=${encodeURIComponent(css.key)}`).then((href) => {
      const st = document.createElement('style');
      st.textContent = `@font-face{font-family:"${fam}";src:url("${href}") format("truetype");}`;
      document.head.appendChild(st);
    }, () => {});
  }
  return `"${fam}", "${css.family}", ${generic}`;
}
/** CSS font stack for a family name; Office cloud fonts are served by Folio itself. */
export function familyStack(family) {
  const f = (store.fonts || []).find((x) => x.family === family);
  if (f && f.system === false && f.key) return cssFamily({ family, system: false, key: f.key });
  return `"${family}", ${/times|georgia|garamond|cambria|serif|roman|book/i.test(family) ? 'serif' : 'sans-serif'}`;
}

// ------------------------------------------------------------------ tool switching
export function initTools() {
  bus.on('tool', ({ tool }) => {
    for (const c of [...document.body.classList]) if (c.startsWith('tool-')) document.body.classList.remove(c);
    document.body.classList.add(`tool-${tool}`);
    if (tool !== 'place') clearGhost();
    commitInk();
    closeEditor(true);
    if (tool !== 'select') deselect();
    hideFloatbar();
    setNeedText(TEXT_TOOLS.has(tool));
    refreshUI();
  });
  document.body.classList.add('tool-select');
  setNeedText(true);
  pagesEl.addEventListener('pointerdown', onPointerDown);
  pagesEl.addEventListener('pointermove', onHover);
  pagesEl.addEventListener('pointerleave', () => { if (ghost) ghost.el.remove(); });
  pagesEl.addEventListener('dblclick', onDblClick);
  pagesEl.addEventListener('contextmenu', onContextMenu);
  document.addEventListener('pointerup', onSelectionEnd);
  bus.on('page-rendered', (pe) => {
    if (V.unlift && V.unlift.n === pe.n) { V.unlift = null; renderUI(pe); }
  });
  // switching documents keeps what was typed or drawn: it is saved into the document it
  // belongs to (V.doc still points there while this runs)
  bus.on('active', () => { closeEditor(true); deselect(); commitInk(); hideFloatbar(); });
  bus.on('selection', () => refreshUI());
  bus.on('zoom', () => { if (editor) closeEditor(true); });
  bus.on('doc-info', refreshSelection);
  onRenderUI(toolOverlay);
  onFieldCommit(commitField);
  viewport.addEventListener('scroll', () => { if (!floatbar.hidden && !floatbar.dataset.sticky) hideFloatbar(); }, { passive: true });
}

function toolOverlay(pe, k) {
  const out = [];
  if (store.tool === 'edittext' && pe.lines) {
    for (const ln of pe.lines) {
      if (!ln.text.trim()) continue;
      const b = ln.bbox;
      const el = box('div.linebox', [b[0] - 1, b[1], b[2] + 1, b[3]], k, ln.editable ? '' : 'locked');
      el._ln = ln;
      el.title = ln.editable ? '' : (ln.reason || (ln.object ? 'Added text — switch to Select and double-click it' : ln.invisible ? 'Hidden OCR text' : 'Angled text can’t be edited'));
      out.push(el);
    }
  }
  if (ink && ink.n === pe.n) out.push(inkSvg(pe, k));
  return out;
}

// ------------------------------------------------------------------ selection of added objects / comments
/** After any change (undo, redo, an edit elsewhere) the selected thing's data comes from
    the document again: a nudge, restyle or delete must act on what is there now. */
async function refreshSelection({ doc, structural, changed }) {
  const s = store.selection;
  if (!s || doc !== V.doc) return;
  if (structural) { deselect(); return; }  // pages moved, appeared or vanished: its page number is stale
  if (!changed.includes(s.n)) return;
  try {
    const layer = await getLayer(doc, s.n);
    if (store.selection !== s) return;
    const fresh = s.kind === 'object' ? layer.objects.find((o) => o.id === s.id) : layer.annots.find((a) => a.xref === s.id);
    if (fresh) select({ ...s, data: fresh }); else deselect();
  } catch { /* the page re-renders and the next change refreshes it */ }
}

export function deselect() {
  if (!store.selection) return;
  const s = store.selection;
  if (s.kind === 'object' && V.lift && V.lift.id === s.id) endLift(s.n);
  select(null);
}

function selectObject(pe, obj) {
  select({ n: pe.n, kind: 'object', id: obj.id, data: obj });
}

function objImgUrl(n, id) {
  const p = V.doc.pages[n];
  const s = Math.min(6, Math.ceil(V.k * (window.devicePixelRatio || 1) * 4) / 4);
  return `/o/${V.doc.id}/${n}/${id}?s=${s}&v=${p.v}`;
}

function startLift(pe, obj) {
  const lift = { n: pe.n, id: obj.id, img: null };
  V.lift = lift;
  media(objImgUrl(pe.n, obj.id)).then((href) => {
    if (V.lift !== lift) return;
    lift.img = href;
    const pre = new Image();
    pre.onload = () => { if (V.lift === lift) { loadImg(pe); renderUI(pe); } };
    pre.src = href;
  }, () => {});
}

function endLift(n) {
  if (!V.lift) return;
  const { id, img } = V.lift;
  V.lift = null;
  const pe = V.pes[n];
  if (pe) { V.unlift = { n, id, img }; loadImg(pe); }
}

// ------------------------------------------------------------------ pointer dispatch
function onPointerDown(e) {
  if (e.button !== 0) return;
  const pe = pageFromEvent(e);
  if (!pe) return;
  if (editor && !editor.el.contains(e.target)) { closeEditor(true); if (store.tool === 'edittext' || store.tool === 'addtext') { e.preventDefault(); return; } }
  if (editor && editor.el.contains(e.target)) return;
  if (e.target.closest('.field')) return;
  hideFloatbar();
  const t = store.tool;
  const objEl = e.target.closest('.obj');
  const annEl = e.target.closest('.annot-hit');

  if (t === 'select' || (t === 'addtext' && objEl && objEl._obj.type === 'text')) {
    if (objEl) {
      e.preventDefault();
      const obj = objEl._obj;
      if (!(store.selection && store.selection.id === obj.id && store.selection.n === pe.n)) selectObject(pe, obj);
      beginDrag(pe, obj, e.target.dataset.h || null, e);
      return;
    }
    if (annEl) {
      e.preventDefault();
      const a = pe.layer.annots.find((x) => x.xref === Number(annEl.dataset.annot));
      select({ n: pe.n, kind: 'annot', id: a.xref, data: a });
      return;
    }
    deselect();
    return; // let native text selection happen
  }
  if (t === 'edittext') {
    const lb = e.target.closest('.linebox');
    if (lb && lb._ln.editable) { e.preventDefault(); openLineEditor(pe, lb._ln); }
    else if (lb) toast(lb.title || 'This text can’t be edited here.');
    return;
  }
  if (t === 'addtext') {
    e.preventDefault();
    const pt = ptIn(pe, e);
    openTextEditor(pe, { point: pt });
    return;
  }
  if (t === 'place') { e.preventDefault(); placeAt(pe, ptIn(pe, e)); return; }
  if (t === 'mark') { e.preventDefault(); placeMark(pe, ptIn(pe, e)); return; }
  if (t === 'note') { e.preventDefault(); addNote(pe, ptIn(pe, e)); return; }
  if (t === 'draw') { e.preventDefault(); beginInk(pe, e); return; }
  if (RECT_TOOLS.has(t)) { e.preventDefault(); beginDraft(pe, e); return; }
}

function onHover(e) {
  if (store.tool !== 'place' || !store.pendingSig) return;
  const pe = pageFromEvent(e);
  if (!pe) return;
  const pt = ptIn(pe, e);
  const { w, h: hh } = placeSize(pe);
  if (!ghost || ghost.n !== pe.n || !ghost.el.isConnected) {
    clearGhost();
    const el = h('div.draft.ghost');
    el.style.backgroundImage = `url("${store.pendingSig.url}")`;
    pe.ui.appendChild(el);
    ghost = { n: pe.n, el };
  }
  const k = V.k;
  Object.assign(ghost.el.style, { left: `${(pt.x - w / 2) * k}px`, top: `${(pt.y - hh / 2) * k}px`, width: `${w * k}px`, height: `${hh * k}px` });
}
function clearGhost() { if (ghost) ghost.el.remove(); ghost = null; }

function onDblClick(e) {
  const pe = pageFromEvent(e);
  if (!pe) return;
  const objEl = e.target.closest('.obj');
  if (objEl && objEl._obj.type === 'text' && (store.tool === 'select' || store.tool === 'addtext')) {
    e.preventDefault();
    openTextEditor(pe, { obj: objEl._obj });
    return;
  }
  if (store.tool === 'select' && e.target.closest('.textlayer span')) {
    const ln = e.target.closest('.textlayer span')._ln;
    if (ln && ln.editable) {
      getSelection().removeAllRanges();
      setTool('edittext');
      setTimeout(() => openLineEditor(pe, ln), 30);
    } else if (ln && ln.reason) toast(ln.reason);
  }
}

function onContextMenu(e) {
  const objEl = e.target.closest('.obj');
  const pe = pageFromEvent(e);
  if (!objEl || !pe) return;
  e.preventDefault();
  const obj = objEl._obj;
  selectObject(pe, obj);
  menu({ x: e.clientX, y: e.clientY }, [
    obj.type === 'text' ? { label: 'Edit text', icon: 'addtext', run: () => openTextEditor(pe, { obj }) } : null,
    { label: 'Duplicate', icon: 'dup', key: 'Ctrl+D', run: () => duplicateSelected() },
    '-',
    { label: 'Delete', icon: 'trash', key: 'Del', danger: true, run: () => deleteSelected() },
  ]);
}

// ------------------------------------------------------------------ moving / resizing objects
function beginDrag(pe, obj, handle, e) {
  const start = ptIn(pe, e);
  const r0 = obj.rect.slice();
  const el = pe.ui.querySelector(`.obj[data-obj="${obj.id}"]`);
  drag = { pe, obj, handle, start, r0, rect: r0.slice(), el, moved: false };
  const move = (ev) => {
    const p = ptIn(pe, ev);
    let dx = p.x - start.x;
    let dy = p.y - start.y;
    if (!drag.moved && Math.hypot(dx * V.k, dy * V.k) < 3) return;
    if (!drag.moved) { drag.moved = true; startLift(pe, obj); }
    let [x0, y0, x1, y1] = r0;
    if (!handle) {
      if (ev.shiftKey) { if (Math.abs(dx) > Math.abs(dy)) dy = 0; else dx = 0; }
      x0 += dx; x1 += dx; y0 += dy; y1 += dy;
    } else {
      if (handle.includes('w')) x0 = Math.min(x1 - 4, x0 + dx);
      if (handle.includes('e')) x1 = Math.max(x0 + 4, x1 + dx);
      if (handle.includes('n')) y0 = Math.min(y1 - 4, y0 + dy);
      if (handle.includes('s')) y1 = Math.max(y0 + 4, y1 + dy);
      const keepRatio = (obj.type === 'image' || obj.type === 'check' || obj.type === 'cross' || obj.type === 'dot') !== ev.shiftKey;
      if (keepRatio && handle.length === 2) {
        const ratio = (r0[2] - r0[0]) / (r0[3] - r0[1]);
        const w = x1 - x0;
        const hh = w / ratio;
        if (handle.includes('n')) y0 = y1 - hh; else y1 = y0 + hh;
      }
    }
    drag.rect = [x0, y0, x1, y1];
    const k = V.k;
    const cur = pe.ui.querySelector(`.obj[data-obj="${obj.id}"]`) || el;
    Object.assign(cur.style, { left: `${x0 * k}px`, top: `${y0 * k}px`, width: `${(x1 - x0) * k}px`, height: `${(y1 - y0) * k}px` });
  };
  const up = async () => {
    window.removeEventListener('pointermove', move);
    window.removeEventListener('pointerup', up);
    const d = drag;
    drag = null;
    if (!d || !d.moved) return;
    obj.rect = d.rect;  // until the new layer arrives, any repaint shows it where it was dropped
    try {
      const r = await run(V.doc, `/page/${pe.n}/object/${obj.id}`, { changes: { rect: d.rect } });
      if (r.object) select({ n: pe.n, kind: 'object', id: r.object.id, data: r.object });
    } catch (err) {
      obj.rect = d.r0;  // the move didn't happen: show it where it still is
      toast(err.message, { type: 'error' });
    } finally { endLift(pe.n); }
  };
  window.addEventListener('pointermove', move);
  window.addEventListener('pointerup', up);
}

let nudgeTimer = null;
let nudgeRect = null;
let nudgeStart = null;
export function nudgeSelected(dx, dy) {
  const s = store.selection;
  if (!s || s.kind !== 'object') return false;
  const pe = V.pes[s.n];
  const el = pe && pe.ui.querySelector(`.obj[data-obj="${s.id}"]`);
  if (!el) return false;
  if (!nudgeRect) { nudgeRect = s.data.rect.slice(); nudgeStart = nudgeRect.slice(); startLift(pe, s.data); }
  nudgeRect = [nudgeRect[0] + dx, nudgeRect[1] + dy, nudgeRect[2] + dx, nudgeRect[3] + dy];
  const k = V.k;
  el.style.left = `${nudgeRect[0] * k}px`;
  el.style.top = `${nudgeRect[1] * k}px`;
  clearTimeout(nudgeTimer);
  nudgeTimer = setTimeout(async () => {
    const rect = nudgeRect;
    const start = nudgeStart;
    nudgeRect = null;
    s.data.rect = rect;
    try {
      const r = await run(V.doc, `/page/${s.n}/object/${s.id}`, { changes: { rect } });
      if (r.object) select({ n: s.n, kind: 'object', id: r.object.id, data: r.object });
    } catch (err) {
      s.data.rect = start;
      toast(err.message, { type: 'error' });
    } finally { endLift(s.n); }
  }, 450);
  return true;
}

export async function deleteSelected() {
  const s = store.selection;
  if (!s) return false;
  try {
    if (s.kind === 'object') await run(V.doc, `/page/${s.n}/object/${s.id}/delete`);
    else if (s.kind === 'annot') await run(V.doc, `/page/${s.n}/annot/${s.id}/delete`);
    V.lift = null;
    select(null);
  } catch (err) { toast(err.message, { type: 'error' }); }
  return true;
}

export async function duplicateSelected() {
  const s = store.selection;
  if (!s || s.kind !== 'object') return false;
  try {
    const r = await run(V.doc, `/page/${s.n}/object/${s.id}/duplicate`);
    if (r.object) select({ n: s.n, kind: 'object', id: r.object.id, data: r.object });
  } catch (err) { toast(err.message, { type: 'error' }); }
  return true;
}

/** Apply style changes to the selected object (from the inspector). */
export async function updateSelected(changes) {
  const s = store.selection;
  if (!s || s.kind !== 'object') return;
  try {
    const r = await run(V.doc, `/page/${s.n}/object/${s.id}`, { changes: { ...changes, type: s.data.type } });
    if (r.object) select({ n: s.n, kind: 'object', id: r.object.id, data: r.object });
    else select(null);
  } catch (err) { toast(err.message, { type: 'error' }); }
}

// ------------------------------------------------------------------ editing existing text
export function openLineEditor(pe, ln) {
  closeEditor(true);
  const k = V.k;
  const cps = Array.from(ln.text);
  let end = cps.length;
  while (end > 0 && /\s/.test(cps[end - 1])) end--;
  const original = cps.slice(0, end).join('');
  const [x0, y0, x1, y1] = ln.bbox;
  const el = h('div.line-editor', { contenteditable: 'plaintext-only', spellcheck: 'false', dataset: { keep: 'editor' } });
  for (const sp of ln.spans) {
    const a = Math.min(sp.start, end);
    const b = Math.min(sp.end, end);
    if (b <= a) continue;
    const s = h('span', cps.slice(a, b).join(''));
    s.style.fontFamily = cssFamily(sp.css);
    s.style.fontSize = `${sp.size * k}px`;
    s.style.fontWeight = sp.bold ? '700' : (sp.css && sp.css.weight) || '400';
    s.style.fontStyle = sp.italic ? 'italic' : 'normal';
    s.style.color = sp.color;
    el.appendChild(s);
  }
  if (!el.firstChild) el.appendChild(h('span', ''));
  const main = ln.spans[0];
  Object.assign(el.style, {
    left: `${x0 * k - 1}px`, top: `${y0 * k}px`, height: `${(y1 - y0) * k}px`, lineHeight: `${(y1 - y0) * k}px`,
    minWidth: `${(x1 - x0) * k + 2}px`, background: sampleBg(pe, ln.bbox), fontSize: `${main.size * k}px`,
    fontFamily: cssFamily(main.css), color: main.color,
  });
  pe.ui.appendChild(el);
  editor = { kind: 'line', el, pe, ln, original, closing: false };
  setBusy();
  el.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); closeEditor(true); }
    else if (e.key === 'Escape') { e.preventDefault(); closeEditor(false); }
    else if (e.key === 'Tab' && !e.ctrlKey) { e.preventDefault(); const next = neighbourLine(pe, ln, e.shiftKey ? -1 : 1); closeEditor(true).then(() => next && openLineEditor(pe, next)); }
    if (!isGlobalShortcut(e)) e.stopPropagation();
  });
  el.addEventListener('blur', () => setTimeout(() => { if (editor && editor.el === el && !el.contains(document.activeElement)) closeEditor(true); }, 0));
  el.focus();
  // caret at the end
  const r = document.createRange();
  r.selectNodeContents(el);
  r.collapse(false);
  const sel = getSelection();
  sel.removeAllRanges();
  sel.addRange(r);
  bus.emit('editor', editor);
}

function neighbourLine(pe, ln, dir) {
  const lines = (pe.lines || []).filter((l) => l.editable).sort((a, b) => (a.bbox[1] - b.bbox[1]) || (a.bbox[0] - b.bbox[0]));
  const i = lines.findIndex((l) => l.key === ln.key);
  return lines[i + dir] || null;
}

async function commitLine(ed) {
  const text = ed.el.innerText.replace(/[\r\n]+/g, ' ').replace(/ /g, ' ').replace(/\s+$/, '');
  if (text === ed.original) { ed.el.remove(); return; }
  ed.el.classList.add('busy');
  ed.el.setAttribute('contenteditable', 'false');
  try {
    const r = await run(V.doc, `/page/${ed.pe.n}/edit-line`, { ref: { bbox: ed.ln.bbox, text: ed.ln.text }, text });
    V.doc.lastReport = r.report;
    bus.emit('report', r.report);
    const sub = (r.report.fonts || []).find((f) => f.quality !== 'exact');
    if (r.report.overflow) {
      toast('That line now runs past the edge of the page. Shorten it, or press Ctrl+Z to undo.', { type: 'error', ms: 7000 });
    } else if (sub) {
      const used = sub.used.replace(/ \(.*/, '');
      // the PDF's own font lacked a letter you typed, so the editor wrote the line in one of its fonts
      const msg = sub.quality === 'similar' ? `${sub.original} isn’t available here — used ${used}, which has the same letter widths.`
        : sub.quality === 'family' ? `Used ${used}, the closest style of ${sub.original} available here.`
          : `${sub.original} isn’t available here — used ${used} instead.`;
      toast(msg, { type: 'info', ms: 6000 });
    }
    await waitRender(ed.pe, 1500);
  } catch (err) {
    toast(err.message, { type: 'error' });
  } finally {
    ed.el.remove();
  }
}

function waitRender(pe, ms) {
  return new Promise((res) => {
    const off = bus.on('page-rendered', (p) => { if (p === pe) { off(); res(); } });
    setTimeout(() => { off(); res(); }, ms);
  });
}

// ------------------------------------------------------------------ text boxes (added text)
export function openTextEditor(pe, { point, obj }) {
  closeEditor(true);
  const st = obj ? {
    family: obj.font.family, bold: !!obj.font.bold, italic: !!obj.font.italic, size: obj.size, color: obj.color,
    align: obj.align || 'left', lh: obj.lh || 1.2,
  } : { ...store.opts.text, lh: 1.2 };
  const el = h('div.text-editor', { contenteditable: 'plaintext-only', spellcheck: 'true', dataset: { keep: 'editor', placeholder: 'Type here' } });
  let x; let y; let wrap = null;
  if (obj) {
    [x, y] = obj.rect;
    wrap = obj.w || null;
    el.textContent = obj.text;
    select({ n: pe.n, kind: 'object', id: obj.id, data: obj });
    V.lift = { n: pe.n, id: obj.id, img: null };
    loadImg(pe);
  } else {
    x = point.x;
    y = point.y - st.size * 0.62;
  }
  editor = { kind: 'text', el, pe, obj, st, x, y, wrap, closing: false };
  setBusy();
  styleTextEditor();
  pe.ui.appendChild(el);
  el.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') { e.preventDefault(); closeEditor(false); }
    else if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); closeEditor(true); }
    if (!isGlobalShortcut(e)) e.stopPropagation();
  });
  el.addEventListener('blur', () => setTimeout(() => {
    const ae = document.activeElement;
    if (editor && editor.el === el && !el.contains(ae) && !(ae && ae.closest && ae.closest('#inspector'))) closeEditor(true);
  }, 0));
  el.focus();
  const r = document.createRange();
  r.selectNodeContents(el);
  r.collapse(false);
  getSelection().removeAllRanges();
  getSelection().addRange(r);
  bus.emit('editor', editor);
}

export function styleTextEditor() {
  if (!editor || editor.kind !== 'text') return;
  const { el, st, x, y, wrap } = editor;
  const k = V.k;
  Object.assign(el.style, {
    left: `${x * k}px`, top: `${y * k}px`, fontFamily: familyStack(st.family), fontSize: `${st.size * k}px`,
    fontWeight: st.bold ? '700' : '400', fontStyle: st.italic ? 'italic' : 'normal', color: st.color,
    textAlign: st.align, lineHeight: String(st.lh || 1.2), width: wrap ? `${wrap * k}px` : 'auto',
  });
  el.classList.toggle('autow', !wrap);
}

export function currentTextStyle() { return editor && editor.kind === 'text' ? editor.st : null; }
export function setEditorStyle(patch) {
  if (!editor || editor.kind !== 'text') return false;
  Object.assign(editor.st, patch);
  styleTextEditor();
  editor.el.focus();
  return true;
}

async function commitText(ed) {
  const text = ed.el.innerText.replace(/ /g, ' ').replace(/\n$/, '');
  const st = ed.st;
  const pe = ed.pe;
  ed.el.classList.add('busy');
  try {
    if (ed.obj) {
      const same = text === ed.obj.text && st.family === ed.obj.font.family && st.size === ed.obj.size && st.color === ed.obj.color &&
        !!st.bold === !!ed.obj.font.bold && !!st.italic === !!ed.obj.font.italic && st.align === ed.obj.align;
      if (!same) {
        const r = await run(V.doc, `/page/${pe.n}/object/${ed.obj.id}`, { changes: {
          type: 'text', text, size: st.size, color: st.color, align: st.align,
          font: { family: st.family, bold: st.bold, italic: st.italic } } });
        if (r.object) select({ n: pe.n, kind: 'object', id: r.object.id, data: r.object }); else select(null);
        await waitRender(pe, 1200);
      }
    } else if (text.trim()) {
      const k = V.k;
      const w = ed.el.offsetWidth / k;
      const hh = ed.el.offsetHeight / k;
      const r = await run(V.doc, `/page/${pe.n}/object`, {
        spec: { type: 'text', text, size: st.size, color: st.color, align: st.align, lh: st.lh || 1.2,
          font: { family: st.family, bold: st.bold, italic: st.italic } },
        rect: [ed.x, ed.y, ed.x + w, ed.y + hh], wrap: ed.wrap,
      });
      await waitRender(pe, 1200);
      if (r.object && store.tool === 'select') select({ n: pe.n, kind: 'object', id: r.object.id, data: r.object });
    }
  } catch (err) {
    toast(err.message, { type: 'error' });
  } finally {
    ed.el.remove();
    if (V.lift && ed.obj && V.lift.id === ed.obj.id) { V.lift = null; loadImg(pe); }
  }
}

export function closeEditor(commit) {
  const ed = editor;
  if (!ed || ed.closing) return inflight || Promise.resolve();
  ed.closing = true;
  editor = null;
  bus.emit('editor', null);
  if (!commit) {
    ed.el.remove();
    if (ed.kind === 'text' && ed.obj) { V.lift = null; loadImg(ed.pe); }
    setBusy();
    return inflight || Promise.resolve();
  }
  const pr = (ed.kind === 'line' ? commitLine(ed) : commitText(ed)).finally(() => {
    if (inflight === pr) inflight = null;
    setBusy();
  });
  inflight = pr;
  setBusy();
  return pr;
}

/** Finish everything in progress (open editor, drawing) and wait until it is saved. */
export async function flushEdits() {
  await closeEditor(true);
  await commitInk();
  if (inflight) await inflight;
}
export const editorOpen = () => !!editor;

// ------------------------------------------------------------------ rectangles: whiteout / erase / redact / shapes
function beginDraft(pe, e) {
  const t = store.tool;
  const kind = t === 'shape' ? store.opts.shape.kind : t;
  const start = ptIn(pe, e);
  const lineLike = kind === 'line' || kind === 'arrow';
  let el;
  if (lineLike) {
    el = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    el.setAttribute('class', 'ink-draft');
    const ln = document.createElementNS('http://www.w3.org/2000/svg', 'line');
    ln.setAttribute('stroke', store.opts.shape.stroke || '#d93d42');
    ln.setAttribute('stroke-width', String(store.opts.shape.width * V.k));
    ln.setAttribute('stroke-linecap', 'round');
    el.appendChild(ln);
  } else {
    el = h('div.draft', { class: t === 'shape' ? 'rect' : t });
    if (t === 'shape') {
      el.style.border = `${Math.max(1, store.opts.shape.width * V.k)}px solid ${store.opts.shape.stroke || 'transparent'}`;
      el.style.background = store.opts.shape.fill || 'transparent';
      if (kind === 'ellipse') el.style.borderRadius = '50%';
    }
    if (t === 'whiteout') el.style.background = store.opts.whiteout.color;
  }
  pe.ui.appendChild(el);
  draft = { pe, start, end: start, el, kind, tool: t, lineLike };
  const move = (ev) => {
    let p = ptIn(pe, ev);
    p = { x: clamp(p.x, 0, pe.p.w), y: clamp(p.y, 0, pe.p.h) };
    if (ev.shiftKey && lineLike) {
      const dx = p.x - start.x; const dy = p.y - start.y;
      const ang = Math.round(Math.atan2(dy, dx) / (Math.PI / 4)) * (Math.PI / 4);
      const len = Math.hypot(dx, dy);
      p = { x: start.x + Math.cos(ang) * len, y: start.y + Math.sin(ang) * len };
    } else if (ev.shiftKey) {
      const s = Math.max(Math.abs(p.x - start.x), Math.abs(p.y - start.y));
      p = { x: start.x + Math.sign(p.x - start.x || 1) * s, y: start.y + Math.sign(p.y - start.y || 1) * s };
    }
    draft.end = p;
    const k = V.k;
    if (lineLike) {
      const l = el.firstChild;
      l.setAttribute('x1', start.x * k); l.setAttribute('y1', start.y * k); l.setAttribute('x2', p.x * k); l.setAttribute('y2', p.y * k);
    } else {
      const r = norm(start, p);
      Object.assign(el.style, { left: `${r[0] * k}px`, top: `${r[1] * k}px`, width: `${(r[2] - r[0]) * k}px`, height: `${(r[3] - r[1]) * k}px` });
    }
  };
  const up = async () => {
    window.removeEventListener('pointermove', move);
    window.removeEventListener('pointerup', up);
    const d = draft;
    draft = null;
    d.el.remove();
    const r = norm(d.start, d.end);
    const tiny = (r[2] - r[0]) * V.k < 4 && (r[3] - r[1]) * V.k < 4;
    if (tiny) return;
    try { await commitDraft(d, r); } catch (err) { toast(err.message, { type: 'error' }); }
  };
  window.addEventListener('pointermove', move);
  window.addEventListener('pointerup', up);
}

function norm(a, b) { return [Math.min(a.x, b.x), Math.min(a.y, b.y), Math.max(a.x, b.x), Math.max(a.y, b.y)]; }

async function commitDraft(d, r) {
  const n = d.pe.n;
  const doc = V.doc;
  if (d.tool === 'erase') { await run(doc, `/page/${n}/erase`, { rect: r }); toast('Erased — the content under the box is gone. Ctrl+Z to undo.', { type: 'ok' }); return; }
  if (d.tool === 'redact') { await run(doc, `/page/${n}/redact`, { rects: [r], color: store.opts.redact.color }); toast('Redacted — removed permanently once you save.', { type: 'ok' }); return; }
  if (d.tool === 'whiteout') {
    const res = await run(doc, `/page/${n}/object`, { spec: { type: 'whiteout', fill: store.opts.whiteout.color }, rect: r });
    return res;
  }
  const o = store.opts.shape;
  const spec = { type: d.kind, stroke: o.stroke || null, fill: o.fill || null, lw: o.width };
  let rect = r;
  if (d.lineLike) {
    const pad = Math.max(2, o.width * 2);
    rect = [r[0] - pad, r[1] - pad, r[2] + pad, r[3] + pad];
    const w = rect[2] - rect[0]; const hh = rect[3] - rect[1];
    spec.pts = [[(d.start.x - rect[0]) / w, (d.start.y - rect[1]) / hh], [(d.end.x - rect[0]) / w, (d.end.y - rect[1]) / hh]];
  }
  await run(doc, `/page/${n}/object`, { spec, rect });
}

// ------------------------------------------------------------------ freehand ink
function beginInk(pe, e) {
  if (ink && ink.n !== pe.n) commitInk();
  if (!ink) ink = { n: pe.n, paths: [] };
  const path = [ptIn(pe, e)];
  ink.paths.push(path);
  const svg = inkSvg(pe, V.k);
  const existing = pe.ui.querySelector('svg.ink-draft');
  if (existing) existing.replaceWith(svg); else pe.ui.appendChild(svg);
  const move = (ev) => {
    const evs = ev.getCoalescedEvents ? ev.getCoalescedEvents() : [ev];
    for (const ce of evs) {
      const p = ptIn(pe, ce);
      const last = path[path.length - 1];
      if (Math.hypot(p.x - last.x, p.y - last.y) > 0.35) path.push(p);
    }
    const s = pe.ui.querySelector('svg.ink-draft');
    if (s) s.lastChild.setAttribute('points', path.map((p) => `${p.x * V.k},${p.y * V.k}`).join(' '));
  };
  const up = () => {
    window.removeEventListener('pointermove', move);
    window.removeEventListener('pointerup', up);
    showInkBar();
    setBusy();
  };
  window.addEventListener('pointermove', move);
  window.addEventListener('pointerup', up);
}

function inkSvg(pe, k) {
  const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  svg.setAttribute('class', 'ink-draft');
  for (const path of (ink && ink.n === pe.n ? ink.paths : [])) {
    const pl = document.createElementNS('http://www.w3.org/2000/svg', 'polyline');
    pl.setAttribute('points', path.map((p) => `${p.x * k},${p.y * k}`).join(' '));
    pl.setAttribute('fill', 'none');
    pl.setAttribute('stroke', store.opts.draw.color);
    pl.setAttribute('stroke-width', String(store.opts.draw.width * k));
    pl.setAttribute('stroke-linecap', 'round');
    pl.setAttribute('stroke-linejoin', 'round');
    svg.appendChild(pl);
  }
  return svg;
}

function showInkBar() {
  floatbar.replaceChildren(
    h('button', { on: { click: () => commitInk() } }, icon('check', 'sm'), 'Done'),
    h('button', { on: { click: () => commitInk(true) } }, icon('close', 'sm'), 'Discard'),
  );
  const rect = viewport.getBoundingClientRect();
  floatbar.style.left = `${rect.left + rect.width / 2 - 80}px`;
  floatbar.style.top = `${rect.top + 12}px`;
  floatbar.dataset.sticky = '1';
  floatbar.hidden = false;
}

/** Ctrl+Z while a drawing is still open takes back its last stroke (not a document change). */
export function undoInkStroke() {
  if (!ink || !ink.paths.length) return false;
  ink.paths.pop();
  const pe = V.pes[ink.n];
  if (!ink.paths.length) { commitInk(true); return true; }
  const old = pe && pe.ui.querySelector('svg.ink-draft');
  if (old) old.replaceWith(inkSvg(pe, V.k));
  return true;
}

export async function commitInk(discard = false) {
  const cur = ink;
  ink = null;
  hideFloatbar();
  setBusy();
  if (!cur || !cur.paths.length) return;
  const pe = V.pes[cur.n];
  if (pe) for (const s of pe.ui.querySelectorAll('svg.ink-draft')) s.remove();
  if (discard || !V.doc) return;
  const lw = store.opts.draw.width;
  let x0 = Infinity; let y0 = Infinity; let x1 = -Infinity; let y1 = -Infinity;
  for (const path of cur.paths) for (const p of path) { x0 = Math.min(x0, p.x); y0 = Math.min(y0, p.y); x1 = Math.max(x1, p.x); y1 = Math.max(y1, p.y); }
  const pad = lw;
  x0 -= pad; y0 -= pad; x1 += pad; y1 += pad;
  const w = Math.max(1, x1 - x0); const hh = Math.max(1, y1 - y0);
  const paths = cur.paths.map((path) => simplify(path, 0.25).map((p) => [+((p.x - x0) / w).toFixed(5), +((p.y - y0) / hh).toFixed(5)]));
  try {
    await run(V.doc, `/page/${cur.n}/object`, { spec: { type: 'ink', paths, stroke: store.opts.draw.color, lw }, rect: [x0, y0, x1, y1] });
  } catch (err) { toast(err.message, { type: 'error' }); }
}

function simplify(pts, tol) {
  if (pts.length < 3) return pts;
  const keep = new Array(pts.length).fill(false);
  keep[0] = keep[pts.length - 1] = true;
  const stack = [[0, pts.length - 1]];
  while (stack.length) {
    const [a, b] = stack.pop();
    let md = 0; let mi = -1;
    const A = pts[a]; const B = pts[b];
    const dx = B.x - A.x; const dy = B.y - A.y; const L = Math.hypot(dx, dy) || 1e-9;
    for (let i = a + 1; i < b; i++) {
      const d = Math.abs(dy * pts[i].x - dx * pts[i].y + B.x * A.y - B.y * A.x) / L;
      if (d > md) { md = d; mi = i; }
    }
    if (md > tol && mi > 0) { keep[mi] = true; stack.push([a, mi], [mi, b]); }
  }
  return pts.filter((_, i) => keep[i]);
}

// ------------------------------------------------------------------ marks, notes, placement
async function placeMark(pe, pt) {
  const o = store.opts.mark;
  const s = o.size;
  const rect = [pt.x - s / 2, pt.y - s / 2, pt.x + s / 2, pt.y + s / 2];
  try { await run(V.doc, `/page/${pe.n}/object`, { spec: { type: o.kind, stroke: o.color }, rect }); }
  catch (err) { toast(err.message, { type: 'error' }); }
}

async function addNote(pe, pt) {
  const text = await promptBox('Add a comment', { placeholder: 'Your note', ok: 'Add comment' });
  if (text == null) return;
  try { await run(V.doc, `/page/${pe.n}/note`, { point: [pt.x, pt.y], text, color: store.opts.note.color }); }
  catch (err) { toast(err.message, { type: 'error' }); }
}

function placeSize(pe) {
  const s = store.pendingSig;
  const ratio = s.h / s.w;
  let w = s.kind === 'image' ? Math.min(s.w * 0.75, 300) : (s.sigKind === 'initials' ? 70 : 160);
  w = Math.min(w, pe.p.w * 0.9);
  return { w, h: w * ratio };
}

/** Arm the placement tool with a signature or an image. */
export function armPlacement(item) {
  store.pendingSig = item;
  setTool('place');
  toast(item.kind === 'image' ? 'Click on the page to place the image.' : 'Click where the signature goes. You can move and resize it after.', { ms: 3500 });
}

async function placeAt(pe, pt) {
  const s = store.pendingSig;
  if (!s) { setTool('select'); return; }
  const { w, h: hh } = placeSize(pe);
  const rect = [pt.x - w / 2, pt.y - hh / 2, pt.x + w / 2, pt.y + hh / 2];
  const body = { spec: { type: 'image' }, rect };
  if (s.kind === 'image') body.image = s.dataUrl; else body.signature = s.id;
  clearGhost();
  try {
    const r = await run(V.doc, `/page/${pe.n}/object`, body);
    store.pendingSig = null;
    setTool('select');
    if (r.object) select({ n: pe.n, kind: 'object', id: r.object.id, data: r.object });
  } catch (err) { toast(err.message, { type: 'error' }); }
}

// ------------------------------------------------------------------ text selection → highlight etc.
function onSelectionEnd(e) {
  if (!V.doc || (store.tool !== 'select' && store.tool !== 'highlight')) return;
  if (e.target.closest && (e.target.closest('#floatbar') || e.target.closest('#inspector') || e.target.closest('.modal'))) return;
  setTimeout(() => {
    const sel = selectionRects();
    if (!sel) { if (!floatbar.dataset.sticky) hideFloatbar(); return; }
    if (store.tool === 'highlight') { markup(sel, store.opts.highlight.kind, store.opts.highlight.color); return; }
    showSelectionBar(sel, e);
  }, 0);
}

async function markup(sel, kind, color) {
  getSelection().removeAllRanges();
  hideFloatbar();
  try {
    for (const [n, rects] of sel.pages) await run(V.doc, `/page/${n}/markup`, { kind, rects, color });
  } catch (err) { toast(err.message, { type: 'error' }); }
}

function showSelectionBar(sel, e) {
  const one = sel.pages.size === 1 && [...sel.pages.values()][0].length === 1;
  floatbar.replaceChildren(...[
    h('button', { title: 'Copy (Ctrl+C)', on: { click: () => { navigator.clipboard.writeText(sel.text).catch(() => document.execCommand('copy')); hideFloatbar(); toast('Copied', { type: 'ok', ms: 1200 }); } } }, icon('dup', 'sm'), 'Copy'),
    h('button', { title: 'Highlight', on: { click: () => markup(sel, 'highlight', store.opts.highlight.color) } }, h('span.dot', { style: { background: store.opts.highlight.color } }), 'Highlight'),
    h('button', { title: 'Underline', on: { click: () => markup(sel, 'underline', '#2f6bff') } }, icon('underline', 'sm')),
    h('button', { title: 'Strike out', on: { click: () => markup(sel, 'strike', '#d93d42') } }, icon('strike', 'sm')),
    h('button', { title: 'Redact (remove permanently)', on: { click: async () => {
      getSelection().removeAllRanges(); hideFloatbar();
      try { for (const [n, rects] of sel.pages) await run(V.doc, `/page/${n}/redact`, { rects, color: store.opts.redact.color }); }
      catch (err) { toast(err.message, { type: 'error' }); }
    } } }, icon('redact', 'sm')),
    one ? h('button', { title: 'Edit this text', on: { click: () => {
      const n = [...sel.pages.keys()][0];
      const pe = V.pes[n];
      const r = sel.pages.get(n)[0];
      const ln = (pe.lines || []).find((l) => l.bbox[1] <= r[1] + 0.5 && l.bbox[3] >= r[3] - 0.5 && l.bbox[0] <= r[0] + 0.5 && l.bbox[2] >= r[2] - 0.5);
      getSelection().removeAllRanges(); hideFloatbar();
      if (ln && ln.editable) { setTool('edittext'); setTimeout(() => openLineEditor(pe, ln), 30); }
      else toast((ln && ln.reason) || 'This text can’t be edited.');
    } } }, icon('edittext', 'sm'), 'Edit') : null,
  ].filter(Boolean));
  delete floatbar.dataset.sticky;
  floatbar.hidden = false;
  const fr = floatbar.getBoundingClientRect();
  floatbar.style.left = `${clamp(e.clientX - fr.width / 2, 8, innerWidth - fr.width - 8)}px`;
  floatbar.style.top = `${clamp(e.clientY + 14, 8, innerHeight - fr.height - 8)}px`;
}

export function hideFloatbar() { floatbar.hidden = true; delete floatbar.dataset.sticky; }

// ------------------------------------------------------------------ form fields
async function commitField(n, f, value) {
  try {
    await run(V.doc, `/page/${n}/field/${f.xref}`, { value });
  } catch (err) { toast(err.message, { type: 'error' }); }
}

export { ink };

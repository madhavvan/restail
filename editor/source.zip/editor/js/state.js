// Application state: open documents, the active tool, tool options, selection.
import { api, docUrl } from './api.js';
import { HL_COLORS } from './util.js';

const handlers = new Map();
export const bus = {
  on(ev, fn) { if (!handlers.has(ev)) handlers.set(ev, new Set()); handlers.get(ev).add(fn); return () => handlers.get(ev).delete(fn); },
  emit(ev, data) { for (const fn of handlers.get(ev) || []) { try { fn(data); } catch (e) { console.error(ev, e); } } },
};

const OPTS_KEY = 'folio.opts.v1';
const defaults = {
  text: { family: 'Arial', size: 12, color: '#000000', bold: false, italic: false, align: 'left' },
  draw: { color: '#1f4e99', width: 2 },
  shape: { kind: 'rect', stroke: '#d93d42', fill: '', width: 2 },
  highlight: { kind: 'highlight', color: '#ffe14d' },
  mark: { kind: 'check', size: 12, color: '#000000' },
  whiteout: { color: '#ffffff' },
  redact: { color: '#000000' },
  note: { color: '#ffd23f' },
};
function loadOpts() {
  try {
    const saved = JSON.parse(localStorage.getItem(OPTS_KEY) || '{}');
    const out = {};
    for (const k of Object.keys(defaults)) out[k] = { ...defaults[k], ...(saved[k] || {}) };
    return out;
  } catch { return structuredClone(defaults); }
}
export function saveOpts() { try { localStorage.setItem(OPTS_KEY, JSON.stringify(store.opts)); } catch { /* private mode */ } }

// Highlighter colours are pale, pen colours are strong: switching between highlight and
// underline/strike-out takes the new kind's own default unless the colour suits both.
const MARKUP_DEFAULT = { highlight: '#ffe14d', underline: '#2f6bff', strike: '#d93d42' };
export function setMarkupKind(kind) {
  const o = store.opts.highlight;
  if (o.kind !== kind && (kind === 'highlight') !== HL_COLORS.includes((o.color || '').toLowerCase())) o.color = MARKUP_DEFAULT[kind];
  o.kind = kind;
  saveOpts();
}

export const store = {
  docs: new Map(),
  order: [],
  activeId: null,
  tool: 'select',
  opts: loadOpts(),
  selection: null,      // { n, kind: 'object'|'annot', id, data }
  fonts: null,
  sigs: [],
  settings: {},
  recent: [],
  word: false,
  seq: 0,
  pendingSig: null,     // signature/image waiting to be placed
};

export class Doc {
  constructor(info) {
    this.id = info.id;
    this.info = info;
    this.view = { zoomMode: 'fit-width', zoom: 1, scrollTop: 0, scrollLeft: 0, current: 0 };
    this.layers = new Map();   // `${xref}:${v}` -> Promise(layer)
    this.texts = new Map();    // `${xref}:${v}` -> Promise(lines)
    this.selPages = new Set();
    this.lastReport = null;
    this.size = null;
  }
  get pages() { return this.info.pages; }
  get name() { return this.info.name; }
}

export const activeDoc = () => store.docs.get(store.activeId) || null;

export function upsertDoc(info, { activate = true } = {}) {
  let d = store.docs.get(info.id);
  if (!d) {
    d = new Doc(info);
    store.docs.set(info.id, d);
    store.order.push(info.id);
    bus.emit('docs');
  } else {
    applyInfo(d, info);
  }
  if (activate) setActive(d.id);
  return d;
}

export function setActive(id) {
  if (store.activeId === id && store.docs.has(id)) return;
  store.activeId = store.docs.has(id) ? id : null;
  store.selection = null;
  if (store.activeId) api.post(docUrl(id, '/activate')).catch(() => {});
  bus.emit('active', activeDoc());
  bus.emit('docs');
}

export function removeDoc(id) {
  const idx = store.order.indexOf(id);
  store.docs.delete(id);
  store.order = store.order.filter((x) => x !== id);
  if (store.activeId === id) {
    const next = store.order[Math.min(idx, store.order.length - 1)];
    store.activeId = null;
    if (next) setActive(next); else { bus.emit('active', null); }
  }
  bus.emit('docs');
}

export function applyInfo(doc, info) {
  const old = doc.info;
  doc.info = info;
  const structural = old.pages.length !== info.pages.length ||
    old.pages.some((p, i) => p.xref !== info.pages[i].xref || p.rot !== info.pages[i].rot ||
      Math.abs(p.w - info.pages[i].w) > 0.01 || Math.abs(p.h - info.pages[i].h) > 0.01);
  const changed = [];
  info.pages.forEach((p, i) => { const o = old.pages[i]; if (!o || o.v !== p.v || o.xref !== p.xref) changed.push(i); });
  if (structural) doc.selPages.clear();
  doc.size = null;
  bus.emit('doc-info', { doc, structural, changed, oldDirty: old.dirty });
  bus.emit('docs');
}

/** Undo, but only if `label` is still the latest change (toasts offer "Undo"; if the user
    has done something else since, a blind undo would revert the wrong thing). */
export async function undoIfLast(doc, label) {
  if (!doc || doc.info.undo_label !== label) return false;
  await run(doc, '/undo');
  return true;
}

/** POST to a document endpoint and apply the returned document info. */
export async function run(doc, path, body = {}) {
  const r = await api.post(docUrl(doc.id, path), body);
  if (r && r.doc) applyInfo(doc, r.doc);
  return r;
}

function pageKey(doc, n) { const p = doc.pages[n]; return p ? `${p.xref}:${p.v}` : null; }

export function getLayer(doc, n) {
  const key = pageKey(doc, n);
  if (!key) return Promise.resolve({ objects: [], annots: [], fields: [] });
  if (!doc.layers.has(key)) {
    const pr = api.get(docUrl(doc.id, `/page/${n}/layer`)).catch((e) => { doc.layers.delete(key); throw e; });
    doc.layers.set(key, pr);
    if (doc.layers.size > 400) doc.layers.delete(doc.layers.keys().next().value);
  }
  return doc.layers.get(key);
}

export function getText(doc, n) {
  const key = pageKey(doc, n);
  if (!key) return Promise.resolve([]);
  if (!doc.texts.has(key)) {
    const pr = api.get(docUrl(doc.id, `/page/${n}/text`)).then((r) => r.lines).catch((e) => { doc.texts.delete(key); throw e; });
    doc.texts.set(key, pr);
    if (doc.texts.size > 200) doc.texts.delete(doc.texts.keys().next().value);
  }
  return doc.texts.get(key);
}

export function setTool(tool) {
  if (store.tool === tool) return;
  const prev = store.tool;
  store.tool = tool;
  bus.emit('tool', { tool, prev });
}

export function select(sel) {
  store.selection = sel;
  bus.emit('selection', sel);
}

export async function pollEvents() {
  for (;;) {
    try {
      const r = await api.get(`/api/events?since=${store.seq}`);
      for (const ev of r.events || []) {
        store.seq = Math.max(store.seq, ev.seq);
        bus.emit('server-event', ev);
      }
    } catch (e) {
      await new Promise((res) => setTimeout(res, 1500));
    }
  }
}

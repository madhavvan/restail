// Folio boot: toolbar, tabs, start screen, status bar, shortcuts, open/save/close.
// Browser build: files open through the page's file chooser and save as downloads; inside
// ResuTailor (?embed) a "Done" button hands the edited PDF back to it.
import { $, h, icon, toast, menu, modal, promptBox, isModalOpen, debounce, closeMenu, fmtBytes } from './util.js';
import { api, docUrl } from './api.js';
import { store, bus, activeDoc, upsertDoc, setActive, removeDoc, run, setTool, setMarkupKind, saveOpts } from './state.js';
import { V, showDoc, setZoom, zoomPercent, goToPage, refreshUI } from './viewer.js';
import { initTools, deselect, deleteSelected, duplicateSelected, nudgeSelected, closeEditor, armPlacement, flushEdits, undoInkStroke } from './tools.js';
import { initInspector } from './inspector.js';
import { initThumbs, pageMenu } from './thumbs.js';
import { initFind, openFind, findOpen, close as closeFind } from './find.js';
import { docTools, fileTools } from './dialogs.js';
import { openSignatureDialog } from './signature.js';
import { ready as engineReady, status as engineStatus, on as onEngine } from './engine.js';
import { embedded, pickFiles, download, toParent, onParent } from './web.js';

const app = $('#app');
app.classList.toggle('embedded', embedded);
const narrow = () => window.matchMedia('(max-width: 760px)').matches;
const OPEN_ACCEPT = '.pdf,application/pdf,.png,.jpg,.jpeg,.gif,.bmp,.tif,.tiff,.webp,.xps,.epub,image/*';

// ------------------------------------------------------------------ open / save / close
async function handleOpenResult(res, retry) {
  if (!res) return;
  if (res.cancelled) return;
  if (res.error) { toast(res.error, { type: 'error' }); return; }
  if (res.need_password) {
    const pw = await promptBox(res.bad ? 'Wrong password' : 'Password required', {
      label: res.bad ? `That password didn’t open “${res.name}”. Try again:` : `“${res.name}” is protected. Enter its password:`,
      type: 'password', ok: 'Open' });
    if (pw == null) return null;
    return handleOpenResult(await retry(pw), retry);
  }
  if (res.doc) {
    const d = upsertDoc(res.doc);
    try {
      const info = await api.get(docUrl(d.id));
      if (info.notice) toast(info.notice, { ms: 7000 });
    } catch { /* ignore */ }
    return d;
  }
  return null;
}

export async function openDialog() {
  const files = await pickFiles({ accept: OPEN_ACCEPT, multiple: true });
  for (const f of files) await uploadFile(f);
}

async function openBytes(name, buf) {
  const up = (pw) => api.upload(`/api/upload?name=${encodeURIComponent(name)}${pw ? `&password=${encodeURIComponent(pw)}` : ''}`, buf).catch((e) => ({ error: e.message }));
  return handleOpenResult(await up(), up);
}

async function uploadFile(file) {
  return openBytes(file.name, await file.arrayBuffer());
}

/** The document's finished PDF: { bytes, name, type } (marks it saved). */
async function exportDoc(doc) {
  await flushEdits();
  const r = await api.file(docUrl(doc.id, '/save'));
  upsertDoc(r.meta.doc, { activate: false });
  return r;
}

export async function save(doc = activeDoc(), as = false) {
  if (!doc) return false;
  let name = null;
  if (as) {
    name = await promptBox('Download as', { value: doc.name.replace(/\.pdf$/i, ''), ok: 'Download', label: 'File name' });
    if (name == null || !name.trim()) return false;
    name = `${name.trim().replace(/[\\/:*?"<>|]+/g, '_').replace(/\.pdf$/i, '')}.pdf`;
  }
  try {
    const r = await exportDoc(doc);
    download(r.bytes, name || r.name, r.type);
    toast(`Downloaded ${name || r.name} (${fmtBytes(r.bytes.byteLength)})`, { type: 'ok', ms: 2600 });
    return true;
  } catch (e) {
    toast(e.message, { type: 'error' });
    return false;
  }
}

/** The document ResuTailor sent: what "changed" is measured against. */
let embeddedId = null;

/** Inside ResuTailor: hand the finished PDF back and let it close the editor. With
 *  several documents open, the person picks the one that goes back. */
async function finish() {
  await flushEdits();
  const docs = store.order.map((id) => store.docs.get(id)).filter(Boolean);
  if (!docs.length) { toParent({ type: 'cancel' }); return; }
  let doc = activeDoc() || docs[0];
  if (docs.length > 1) {
    const pick = await modal({ title: 'Send which PDF back?', body: h('p', 'Several documents are open — ResuTailor takes one of them as your resume.'),
      buttons: [{ label: 'Cancel', value: null }, ...docs.map((d) => ({ label: `${d.name}${d.info.dirty ? ' (edited)' : ''}`, value: d.id, primary: d === doc }))] });
    if (!pick || !store.docs.has(pick)) return;
    doc = store.docs.get(pick);
  }
  // Another document than the one sent (merged, new, opened here) is a change; so is any
  // edit, downloaded since or not, and a password added or removed.
  const changed = doc.id !== embeddedId || !!doc.info.can_undo || !!doc.info.dirty;
  try {
    const r = await exportDoc(doc);
    toParent({ type: 'done', name: r.name, bytes: r.bytes, changed }, [r.bytes]);
  } catch (e) {
    toast(e.message, { type: 'error' });
  }
}

async function cancelEmbedded() {
  await flushEdits();
  const dirty = store.order.some((id) => store.docs.get(id)?.info.dirty);
  if (dirty) {
    const choice = await modal({ title: 'Leave the editor?', body: h('p', 'Your changes haven’t been sent back yet.'),
      buttons: [{ label: 'Keep editing', value: null }, { label: 'Discard changes', value: 'discard', danger: true }, { label: 'Use my changes', value: 'done', primary: true }] });
    if (!choice) return;
    if (choice === 'done') { await finish(); return; }
  }
  toParent({ type: 'cancel' });
}

async function closeDoc(doc) {
  if (!doc) return true;
  if (doc === activeDoc()) await flushEdits();  // a half-typed edit counts as a change
  if (doc.info.dirty) {
    const choice = await modal({ title: 'Save changes?', body: h('p', `“${doc.name}” has changes that aren’t saved yet.`),
      buttons: [{ label: 'Cancel', value: null }, { label: 'Don’t save', value: 'discard', danger: true }, { label: 'Save', value: 'save', primary: true }] });
    if (!choice) return false;
    if (choice === 'save' && !(await save(doc))) return false;
  }
  try { await api.post(docUrl(doc.id, '/close')); } catch { /* already gone */ }
  removeDoc(doc.id);
  return true;
}

async function undo(doc = activeDoc()) {
  if (!doc) return;
  if (undoInkStroke()) return;  // a drawing still in progress: take back its last stroke
  await closeEditor(false);
  try {
    const r = await run(doc, '/undo');
    if (r.label) toast(`Undid: ${r.label}`, { ms: 1400 });
  } catch (e) { toast(e.message, { type: 'error' }); }
}
async function redo(doc = activeDoc()) {
  if (!doc) return;
  try {
    const r = await run(doc, '/redo');
    if (r.label) toast(`Redid: ${r.label}`, { ms: 1400 });
  } catch (e) { toast(e.message, { type: 'error' }); }
}

// ------------------------------------------------------------------ toolbar
const TOOLS = [
  ['select', 'select', 'Select', 'V', 'Select, move and resize (V)'],
  ['edittext', 'edittext', 'Edit text', 'E', 'Edit the existing text (E)'],
  ['addtext', 'addtext', 'Add text', 'T', 'Type anywhere on the page (T)'],
  ['sign', 'sign', 'Sign', 'S', 'Add your signature (S)'],
  ['image', 'image', 'Image', 'I', 'Add a picture (I)'],
  ['draw', 'draw', 'Draw', 'D', 'Freehand drawing (D)'],
  ['shape', 'shape', 'Shapes', 'R', 'Rectangles, ellipses, lines, arrows (R)'],
  ['mark', 'mark', 'Marks', 'M', 'Check marks, crosses, dots (M)'],
  ['highlight', 'highlight', 'Highlight', 'H', 'Highlight, underline or strike text (H)'],
  ['note', 'note', 'Comment', 'N', 'Add a sticky-note comment (N)'],
  ['whiteout', 'whiteout', 'Whiteout', 'W', 'Cover something with a white box (W)'],
  ['erase', 'erase', 'Erase', 'X', 'Remove content inside a box for real (X)'],
  ['redact', 'redact', 'Redact', '', 'Black out and permanently remove'],
];
const toolBtns = new Map();
let undoBtn; let redoBtn; let zoomBtn; let saveBtn; let doneBtn = null;

function pickTool(tool) {
  if (!activeDoc()) return;
  if (tool === 'sign') {
    setTool('sign');
    if (!store.sigs.length) openSignatureDialog('signature');
    return;
  }
  if (tool === 'image') {
    setTool('image');
    setTimeout(() => { const b = $('#inspector .btn.primary'); if (b) b.click(); }, 30);
    return;
  }
  if (store.tool === tool && ['shape', 'mark', 'highlight'].includes(tool)) { subMenu(tool); return; }
  setTool(tool);
}

function subMenu(tool) {
  const btn = toolBtns.get(tool);
  const set = (key, kind) => { if (key === 'highlight') setMarkupKind(kind); else store.opts[key].kind = kind; saveOpts(); setTool(tool); bus.emit('tool', { tool, prev: tool }); };
  const items = {
    shape: [['rect', 'Rectangle', 'rect'], ['ellipse', 'Ellipse', 'ellipse'], ['line', 'Line', 'line'], ['arrow', 'Arrow', 'arrow']].map(([k, l, ic]) => ({ label: l, icon: ic, run: () => set('shape', k) })),
    mark: [['check', 'Check mark', 'check'], ['cross', 'Cross', 'cross'], ['dot', 'Dot', 'dot']].map(([k, l, ic]) => ({ label: l, icon: ic, run: () => set('mark', k) })),
    highlight: [['highlight', 'Highlight', 'highlight'], ['underline', 'Underline', 'underline'], ['strike', 'Strike out', 'strike']].map(([k, l, ic]) => ({ label: l, icon: ic, run: () => set('highlight', k) })),
  }[tool];
  menu(btn, items);
}

function toolsMenu(anchor) {
  const doc = activeDoc();
  const d = !doc;
  menu(anchor, [
    { header: 'Pages' },
    { label: 'Insert pages from a file…', icon: 'merge', disabled: d, run: () => docTools.insertFile(doc, V.current + 1) },
    { label: 'Insert blank page', icon: 'pageadd', disabled: d, run: () => run(doc, '/pages/blank', { at: V.current + 1 }).catch((e) => toast(e.message, { type: 'error' })) },
    { label: 'Split or extract pages…', icon: 'split', disabled: d, run: () => docTools.split(doc) },
    { label: 'Page actions…', icon: 'pages', disabled: d, run: () => pageMenu(doc, { x: anchor.getBoundingClientRect().left, y: anchor.getBoundingClientRect().bottom + 4 }) },
    '-',
    { header: 'Convert' },
    { label: 'Export pages as images…', icon: 'images', disabled: d, run: () => docTools.exportImages(doc) },
    { label: 'Images to PDF…', icon: 'image', run: () => fileTools.imagesToPdf() },
    { label: 'Merge PDFs into a new file…', icon: 'merge', run: () => fileTools.merge() },
    '-',
    { header: 'Optimise & protect' },
    { label: 'Compress…', icon: 'compress', disabled: d, run: () => docTools.compress(doc) },
    { label: doc && doc.info.protected ? 'Password…' : 'Protect with password…', icon: 'lock', disabled: d, run: () => docTools.protect(doc) },
    { label: 'Redact by search…', icon: 'redact', disabled: d, run: () => docTools.redactSearch(doc) },
    { label: 'Flatten form fields…', icon: 'layers', disabled: d || !doc.info.forms, run: () => docTools.flatten(doc) },
    { label: 'Flatten everything…', icon: 'layers', disabled: d, run: () => docTools.flattenAll(doc) },
    { label: 'Remove hidden data…', icon: 'eyeoff', disabled: d, run: () => docTools.scrub(doc) },
    '-',
    { header: 'Stamp' },
    { label: 'Page numbers…', icon: 'hash', disabled: d, run: () => docTools.pageNumbers(doc) },
    { label: 'Watermark…', icon: 'drop', disabled: d, run: () => docTools.watermark(doc) },
    '-',
    { label: 'Print…', icon: 'print', key: 'Ctrl+P', disabled: d, run: () => docTools.print(doc) },
    { label: 'Document properties…', icon: 'info', disabled: d, run: () => docTools.properties(doc) },
    { label: 'Keyboard shortcuts', icon: 'keyboard', run: () => shortcutsDialog() },
    { label: 'About Folio and its source code', icon: 'info', run: () => aboutDialog() },
  ]);
}

function saveMenu(anchor) {
  const doc = activeDoc();
  menu(anchor, [
    ...(embedded ? [{ label: 'Done — use this PDF', icon: 'check', disabled: !doc, run: () => finish() }, '-'] : []),
    { label: 'Download PDF', icon: 'save', key: 'Ctrl+S', disabled: !doc, run: () => save(doc) },
    { label: 'Download as…', icon: 'save', key: 'Ctrl+Shift+S', disabled: !doc, run: () => save(doc, true) },
    { label: 'Print…', icon: 'print', key: 'Ctrl+P', disabled: !doc, run: () => docTools.print(doc) },
    '-',
    { label: 'Close document', icon: 'close', key: 'Ctrl+W', disabled: !doc, run: () => closeDoc(doc) },
  ]);
}

function buildToolbar() {
  const tb = $('#toolbar');
  const tbtn = (ic, label, title, fn, cls = '') => h('button.tool', { class: cls, title, on: { click: fn } }, icon(ic), h('span', label));
  saveBtn = tbtn('save', 'Download', 'Download the PDF (Ctrl+S) — right-click for more', () => save());
  saveBtn.addEventListener('contextmenu', (e) => { e.preventDefault(); saveMenu(saveBtn); });
  const saveMore = h('button.icon-btn.small', { title: 'More save options', style: { width: '18px' }, on: { click: (e) => saveMenu(e.currentTarget) } }, icon('chev', 'sm'));
  undoBtn = h('button.icon-btn', { title: 'Undo (Ctrl+Z)', on: { click: () => undo() } }, icon('undo'));
  redoBtn = h('button.icon-btn', { title: 'Redo (Ctrl+Y)', on: { click: () => redo() } }, icon('redo'));
  const tools = TOOLS.map(([id, ic, label, , title]) => {
    const b = tbtn(ic, label, title, () => pickTool(id));
    if (['shape', 'mark', 'highlight'].includes(id)) {
      b.appendChild(icon('chev', 'caret'));
      b.addEventListener('contextmenu', (e) => { e.preventDefault(); setTool(id); subMenu(id); });
    }
    toolBtns.set(id, b);
    return b;
  });
  zoomBtn = h('button.zoom-val', { title: 'Zoom', on: { click: (e) => menu(e.currentTarget, [
    { label: 'Fit width', icon: 'fitw', key: 'Ctrl+0', run: () => setZoom('fit-width') },
    { label: 'Fit page', icon: 'pages', run: () => setZoom('fit-page') },
    '-',
    ...[0.5, 0.75, 1, 1.25, 1.5, 2, 3].map((z) => ({ label: `${Math.round(z * 100)}%`, run: () => setZoom(z) })),
  ]) } }, '100%');
  const findBtn = tbtn('find', 'Find', 'Find & replace (Ctrl+F)', () => openFind(false));
  const toolsBtn = tbtn('tools', 'Tools', 'More tools: compress, convert, split, protect…', (e) => toolsMenu(e.currentTarget));
  // on a phone the panels are drawers over the page (closed by default), elsewhere columns
  const panel = (which) => {
    if (narrow()) { app.classList.toggle(`show-${which}`); app.classList.remove(`show-${which === 'side' ? 'inspector' : 'side'}`); }
    else app.classList.toggle(`hide-${which}`);
  };
  const sideBtn = h('button.icon-btn.panel-toggle', { title: 'Show/hide pages panel', on: { click: () => panel('side') } }, icon('side'));
  const panelBtn = h('button.icon-btn.panel-toggle', { title: 'Show/hide properties panel', on: { click: () => panel('inspector') } }, icon('panel'));
  tb.replaceChildren(
    h('div.tb-group.always', tbtn('open', 'Open', 'Open a file (Ctrl+O)', () => openDialog(), 'always')),
    h('div.tb-group', saveBtn, saveMore),
    h('div.tb-sep'),
    h('div.tb-group.tb-undo', undoBtn, redoBtn),
    h('div.tb-sep'),
    h('div.tb-group.tb-edit', ...tools.slice(0, 3)),
    h('div.tb-sep'),
    h('div.tb-group', ...tools.slice(3, 10)),
    h('div.tb-sep'),
    h('div.tb-group', ...tools.slice(10)),
    h('div.tb-sep'),
    h('div.tb-group', findBtn, toolsBtn),
    h('div.spacer'),
    h('div.zoom', h('button.icon-btn', { title: 'Zoom out (Ctrl+-)', on: { click: () => setZoom('out') } }, icon('minus')), zoomBtn,
      h('button.icon-btn', { title: 'Zoom in (Ctrl+=)', on: { click: () => setZoom('in') } }, icon('plus')),
      h('button.icon-btn', { title: 'Fit width (Ctrl+0)', on: { click: () => setZoom('fit-width') } }, icon('fitw'))),
    h('div.tb-sep'),
    sideBtn, panelBtn,
    ...(embedded ? [
      h('div.tb-sep'),
      // the way back to ResuTailor: pinned to the right edge while the tools scroll under it
      // (phones, windows narrower than the whole toolbar), and usable with no document open
      h('div.tb-group.tb-embed.always',
        h('button.btn.tb-close', { title: 'Close the editor', 'aria-label': 'Close the editor', on: { click: () => cancelEmbedded() } }, icon('close', 'sm'), h('span', 'Close')),
        doneBtn = h('button.btn.primary', { title: 'Send this PDF back to ResuTailor', dataset: { testid: 'editor-done' }, on: { click: () => finish() } }, icon('check', 'sm'), 'Done')),
    ] : []),
  );
  paintToolbar();
}

function paintToolbar() {
  const placing = store.tool === 'place' ? (store.pendingSig && store.pendingSig.kind === 'image' ? 'image' : 'sign') : null;
  for (const [id, b] of toolBtns) b.classList.toggle('active', store.tool === id || placing === id);
  const doc = activeDoc();
  undoBtn.disabled = !doc || !doc.info.can_undo;
  redoBtn.disabled = !doc || !doc.info.can_redo;
  undoBtn.title = doc && doc.info.undo_label ? `Undo ${doc.info.undo_label} (Ctrl+Z)` : 'Undo (Ctrl+Z)';
  redoBtn.title = doc && doc.info.redo_label ? `Redo ${doc.info.redo_label} (Ctrl+Y)` : 'Redo (Ctrl+Y)';
  zoomBtn.textContent = `${zoomPercent()}%`;
  saveBtn.classList.toggle('active', !!(doc && doc.info.dirty));
  if (doneBtn) doneBtn.disabled = !doc;
}

// ------------------------------------------------------------------ tabs
function renderTabs() {
  const tabs = $('#tabs');
  tabs.replaceChildren(...store.order.map((id) => {
    const d = store.docs.get(id);
    const t = h('div.tab', { class: id === store.activeId ? 'active' : '', role: 'tab', title: d.info.path || d.name,
      on: {
        click: () => setActive(id),
        auxclick: (e) => { if (e.button === 1) closeDoc(d); },
      } },
    h('span.name', d.name), d.info.dirty ? h('span.dirty', { title: 'Unsaved changes' }) : null,
    h('button.x', { title: 'Close (Ctrl+W)', on: { click: (e) => { e.stopPropagation(); closeDoc(d); } } }, icon('close', 'sm')));
    return t;
  }));
  const act = tabs.querySelector('.tab.active');
  if (act) act.scrollIntoView({ block: 'nearest', inline: 'nearest' });
}

// ------------------------------------------------------------------ start screen
let engineUp = false;
let openingEmbedded = false;

function engineCard() {
  if (engineStatus.error) {
    return h('div.engine-card.failed', h('b', 'The PDF editor couldn’t start in this browser.'),
      h('span.muted', engineStatus.error), h('span.muted', 'Try a current Chrome, Edge, Firefox or Safari, or reload the page.'));
  }
  const total = engineStatus.total || 1;
  const pct = Math.min(100, Math.round((engineStatus.loaded / total) * 100));
  const downloading = engineStatus.loaded < total;
  return h('div.engine-card', { dataset: { testid: 'engine-loading' } },
    h('div.engine-row', h('span.spin'), h('b', downloading ? 'Loading the PDF editor' : `${engineStatus.stage}…`),
      h('span.muted', downloading ? `${fmtBytes(engineStatus.loaded)} of ${fmtBytes(total)}` : '')),
    h('div.engine-bar', h('div', { style: { width: `${downloading ? pct : 100}%` } })),
    h('span.muted', 'First visit only — about 30 MB, then your browser keeps it. Your PDF never leaves this page.'));
}

function renderStart() {
  const start = $('#start');
  const quick = (ic, title, sub, fn) => h('button', { disabled: !engineUp, on: { click: fn } }, h('div.qi', icon(ic)), h('b', title), h('span', sub));
  start.replaceChildren(h('div.start-card',
    h('div.start-hero', h('img', { src: new URL('../icon.svg', import.meta.url).href, alt: '' }), h('div', h('h1', 'Folio'), h('p', 'Edit any PDF — text, forms, signatures, pages. Everything stays in this browser.'))),
    engineUp && !openingEmbedded
      ? h('div.dropzone', h('div.dz-icon', icon('open')), h('div.dz-text', h('b', 'Open a PDF'), h('span.muted', 'or drop files anywhere in this window')),
        h('button.btn.primary.big', { on: { click: () => openDialog() } }, 'Choose file…'))
      : (engineUp ? h('div.engine-card', h('div.engine-row', h('span.spin'), h('b', 'Opening your PDF…'))) : engineCard()),
    embedded ? null : h('div.quick',
      quick('merge', 'Merge PDFs', 'Combine several files into one', () => fileTools.merge()),
      quick('images', 'Images to PDF', 'Photos or scans into one PDF', () => fileTools.imagesToPdf()),
      quick('compress', 'Compress a PDF', 'Make it small enough to upload', async () => {
        const before = store.order.length;
        await openDialog();
        const doc = activeDoc();
        if (doc && store.order.length > before) docTools.compress(doc);
      })),
    h('p.start-legal', 'Folio is free software (GNU AGPL v3) · ', sourceLink('source code'))));
}

// ------------------------------------------------------------------ status bar
function renderStatus() {
  const st = $('#status');
  const doc = activeDoc();
  if (!doc) { st.replaceChildren(h('span', engineUp ? 'Ready' : 'Starting…'), h('div.spacer'), h('span.muted', 'Folio · runs in your browser')); return; }
  const n = doc.pages.length;
  const pageBtn = h('span', { style: { cursor: 'pointer' }, title: 'Go to page (Ctrl+G)', on: { click: goToPrompt } }, `Page ${Math.min(V.current + 1, n)} of ${n}`);
  const state = doc.info.dirty ? h('span.warn', embedded ? '● Changes not sent back yet' : '● Not downloaded yet') : h('span.ok', '✓ No unsaved changes');
  const hint = store.tool !== 'select' ? h('span.muted', 'Esc to return to Select') : null;
  st.replaceChildren(...[pageBtn, h('div.sep'), h('span', `${zoomPercent()}%`), h('div.sep'), state, hint ? h('div.sep') : null, hint,
    h('div.spacer'), doc.info.undo_label ? h('span.muted', `Last change: ${doc.info.undo_label}`) : null].filter(Boolean));
}

async function goToPrompt() {
  const doc = activeDoc();
  if (!doc) return;
  const v = await promptBox('Go to page', { value: String(V.current + 1), type: 'number', ok: 'Go' });
  const n = parseInt(v, 10);
  if (n >= 1 && n <= doc.pages.length) goToPage(n - 1);
}

function shortcutsDialog() {
  const rows = [
    ['Open / Download / Download as', 'Ctrl+O · Ctrl+S · Ctrl+Shift+S'], ['Undo / Redo', 'Ctrl+Z · Ctrl+Y'], ['Find / Replace', 'Ctrl+F · Ctrl+H'],
    ['Zoom', 'Ctrl+scroll · Ctrl+= · Ctrl+- · Ctrl+0'], ['Select · Edit text · Add text', 'V · E · T'], ['Sign · Image · Draw · Shapes', 'S · I · D · R'],
    ['Marks · Highlight · Comment', 'M · H · N'], ['Whiteout · Erase', 'W · X'], ['Delete / Duplicate selected', 'Del · Ctrl+D'],
    ['Nudge selected', 'Arrow keys (Shift = 10pt)'], ['Pan', 'Hold Space and drag'], ['Next / previous document', 'Ctrl+Tab · Ctrl+Shift+Tab'],
    ['Go to page', 'Ctrl+G'], ['Print', 'Ctrl+P'], ['Close document', 'Ctrl+W'],
  ];
  modal({ title: 'Keyboard shortcuts', body: h('div', rows.map(([a, b]) => h('div.row', { style: { justifyContent: 'space-between' } }, h('span', a), h('span.kbd', b)))), buttons: [{ label: 'Close', primary: true }] });
}

// Built on PyMuPDF (AGPL-3.0): everyone who uses the editor is offered its complete source.
// The build serves it next to the editor (scripts/editor-runtime.mjs).
const SOURCE_URL = new URL('editor/source.zip', new URL(import.meta.env.BASE_URL, location.href)).href;
const sourceLink = (text) => h('a', { href: SOURCE_URL, target: '_blank', rel: 'noopener', dataset: { testid: 'editor-source' } }, text);

function aboutDialog() {
  modal({
    title: 'About Folio',
    body: h('div',
      h('p', 'Folio is the PDF editor on this page. It is built on PyMuPDF and MuPDF (Artifex Software) and is free software under the GNU Affero General Public License v3.0 or later.'),
      h('p', sourceLink('Download its complete source code'), ' (ZIP, with build instructions).')),
    buttons: [{ label: 'Close', primary: true }],
  });
}

// ------------------------------------------------------------------ theme
function applyTheme(t) {
  if (t === 'light' || t === 'dark') document.documentElement.dataset.theme = t; else delete document.documentElement.dataset.theme;
  $('#theme-btn').replaceChildren(icon(t === 'light' ? 'sun' : t === 'dark' ? 'moon' : 'auto'));
  $('#theme-btn').title = `Theme: ${t === 'system' ? 'follow your system' : t}`;
}

// ------------------------------------------------------------------ keyboard
let spaceDown = false;
function isTyping(t) {
  return t && (t.isContentEditable || ['INPUT', 'TEXTAREA', 'SELECT'].includes(t.tagName));
}
document.addEventListener('keydown', (e) => {
  if (isModalOpen()) return;
  const k = e.key;
  const ctrl = e.ctrlKey || e.metaKey;
  const typing = isTyping(e.target);
  const doc = activeDoc();
  if (ctrl && !e.altKey) {
    const kl = k.toLowerCase();
    if (kl === 'o') { e.preventDefault(); openDialog(); return; }
    if (kl === 's') { e.preventDefault(); save(doc, e.shiftKey); return; }
    if (kl === 'w') { e.preventDefault(); closeDoc(doc); return; }
    if (kl === 'f') { e.preventDefault(); openFind(false); return; }
    if (kl === 'h') { e.preventDefault(); openFind(true); return; }
    if (kl === 'g') { e.preventDefault(); goToPrompt(); return; }
    if (kl === 'p') { e.preventDefault(); if (doc) docTools.print(doc); return; }
    if (k === 'Tab') {
      e.preventDefault();
      if (store.order.length > 1) {
        const i = store.order.indexOf(store.activeId);
        setActive(store.order[(i + (e.shiftKey ? -1 : 1) + store.order.length) % store.order.length]);
      }
      return;
    }
    if (k === '=' || k === '+') { e.preventDefault(); setZoom('in'); return; }
    if (k === '-') { e.preventDefault(); setZoom('out'); return; }
    if (k === '0') { e.preventDefault(); setZoom('fit-width'); return; }
    if (typing) return;
    if (kl === 'z' && !e.shiftKey) { e.preventDefault(); undo(); return; }
    if (kl === 'y' || (kl === 'z' && e.shiftKey)) { e.preventDefault(); redo(); return; }
    if (kl === 'd') { e.preventDefault(); duplicateSelected(); return; }
    return;
  }
  if (typing || !doc) return;
  if (k === 'Escape') {
    if (findOpen()) { closeFind(); return; }
    if (store.selection) { deselect(); return; }
    if (store.tool !== 'select') { setTool('select'); return; }
    getSelection().removeAllRanges();
    return;
  }
  // keys pressed in the pages panel act on pages there, never on the selected object
  const inPanel = e.target.closest && e.target.closest('#sidebar');
  if ((k === 'Delete' || k === 'Backspace') && store.selection && !inPanel) { e.preventDefault(); deleteSelected(); return; }
  if (k.startsWith('Arrow') && store.selection && store.selection.kind === 'object' && !inPanel) {
    e.preventDefault();
    const step = e.shiftKey ? 10 : 1;
    nudgeSelected(k === 'ArrowLeft' ? -step : k === 'ArrowRight' ? step : 0, k === 'ArrowUp' ? -step : k === 'ArrowDown' ? step : 0);
    return;
  }
  const pressable = e.target.closest && e.target.closest('button, a, [role=button], [role=checkbox], [role=radio], [role=tab], .field');
  if (k === ' ' && !spaceDown && !pressable) { spaceDown = true; document.body.classList.add('tool-pan'); e.preventDefault(); return; }
  if (k === 'Home') { e.preventDefault(); goToPage(0); return; }
  if (k === 'End') { e.preventDefault(); goToPage(doc.pages.length - 1); return; }
  if (!e.altKey && k.length === 1) {
    const t = TOOLS.find((x) => x[3] && x[3].toLowerCase() === k.toLowerCase());
    if (t) { e.preventDefault(); pickTool(t[0]); }
  }
});
document.addEventListener('keyup', (e) => { if (e.key === ' ' && spaceDown) { spaceDown = false; document.body.classList.remove('tool-pan'); } });
// Working on the pages takes the keyboard there: after a click in the page panel (or the
// properties panel) Delete and the arrow keys must act on what is selected on the page,
// not on the panel. (Clicks on page objects don't move focus by themselves: they
// preventDefault to start a drag.)
$('#viewport').addEventListener('pointerdown', () => {
  if (narrow()) app.classList.remove('show-side', 'show-inspector');  // a tap on the page closes a drawer
  const a = document.activeElement;
  if (a && a !== document.body && !a.closest('#viewport')) $('#viewport').focus({ preventScroll: true });
}, true);
$('#viewport').addEventListener('pointerdown', (e) => {
  if (!spaceDown && e.button !== 1) return;
  e.preventDefault();
  e.stopPropagation();  // a pan, not a click for the active tool (no shape drawn, nothing erased)
  const vp = $('#viewport');
  const sx = e.clientX; const sy = e.clientY; const st = vp.scrollTop; const sl = vp.scrollLeft;
  const mv = (ev) => { vp.scrollTop = st - (ev.clientY - sy); vp.scrollLeft = sl - (ev.clientX - sx); };
  const up = () => { window.removeEventListener('pointermove', mv); window.removeEventListener('pointerup', up); };
  window.addEventListener('pointermove', mv);
  window.addEventListener('pointerup', up);
}, true);

// ------------------------------------------------------------------ drag & drop files
let dragDepth = 0;
const hasFiles = (e) => e.dataTransfer && [...e.dataTransfer.types].includes('Files');
document.body.addEventListener('dragenter', (e) => { if (hasFiles(e)) { dragDepth++; $('#drop-hint').hidden = false; } });
document.body.addEventListener('dragleave', (e) => { if (hasFiles(e)) { dragDepth = Math.max(0, dragDepth - 1); if (!dragDepth) $('#drop-hint').hidden = true; } });
document.body.addEventListener('dragover', (e) => { if (hasFiles(e)) e.preventDefault(); });
document.body.addEventListener('drop', (e) => {
  if (!hasFiles(e)) return;
  e.preventDefault();
  dragDepth = 0;
  $('#drop-hint').hidden = true;
  const files = [...e.dataTransfer.files];
  (async () => { for (const f of files) await uploadFile(f); })();
});

// ------------------------------------------------------------------ wiring
const setTitle = debounce(() => {
  const doc = activeDoc();
  document.title = doc ? `${doc.name}${doc.info.dirty ? ' •' : ''} — Folio` : 'Folio — PDF editor';
}, 150);

function onActive(doc) {
  app.classList.toggle('no-doc', !doc);
  showDoc(doc);
  bus.emit('current-page', V.current);  // the thumbnails mark the page this document is on
  if (!doc) { renderStart(); setTool('select'); }
  renderStatus();
  paintToolbar();
  setTitle();
}

const THEME_KEY = 'folio.theme';
function loadTheme() { try { return localStorage.getItem(THEME_KEY) || 'system'; } catch { return 'system'; } }

async function boot() {
  buildToolbar();
  $('#tab-add').replaceChildren(icon('plus', 'sm'));
  $('#tab-add').addEventListener('click', () => openDialog());
  initTools();
  initThumbs();
  initInspector();
  initFind();
  bus.on('docs', () => { renderTabs(); paintToolbar(); renderStatus(); setTitle(); });
  if (embedded) {
    // ResuTailor guards its page while there are edits it hasn't received
    let lastDirty = false;
    bus.on('docs', () => {
      const d = store.order.some((id) => store.docs.get(id)?.info.dirty);
      if (d !== lastDirty) { lastDirty = d; toParent({ type: 'dirty', dirty: d }); }
    });
  }
  bus.on('active', onActive);
  bus.on('tool', () => { paintToolbar(); renderStatus(); });
  bus.on('zoom', () => { paintToolbar(); renderStatus(); });
  bus.on('current-page', () => renderStatus());
  bus.on('cmd', (c) => { if (c === 'save') save(); });
  bus.on('sig-created', (s) => {
    const img = new Image();
    img.onload = () => armPlacement({ kind: 'signature', sigKind: s.kind, id: s.id, url: s.url, w: img.naturalWidth, h: img.naturalHeight });
    img.src = s.url;
  });
  let theme = loadTheme();
  applyTheme(theme);
  $('#theme-btn').addEventListener('click', () => {
    theme = theme === 'system' ? 'light' : theme === 'light' ? 'dark' : 'system';
    applyTheme(theme);
    try { localStorage.setItem(THEME_KEY, theme); } catch { /* private mode */ }
  });
  onActive(null);

  // The engine downloads and starts in the background; the start screen shows how far.
  const repaint = () => { if (!activeDoc()) renderStart(); };
  const offStage = onEngine('stage', repaint);
  const offProgress = onEngine('progress', repaint);
  if (embedded) {
    onParent(async (m) => {
      if (m.type !== 'open' || !m.bytes) return;
      openingEmbedded = true;
      repaint();
      try {
        await engineReady;
        const d = await openBytes(m.name || 'Resume.pdf', m.bytes);
        if (d) { embeddedId = d.id; toParent({ type: 'opened', name: d.name, pages: d.pages.length }); }
      } catch (e) {
        toast(e.message, { type: 'error' });
      } finally {
        openingEmbedded = false;
        repaint();
      }
    });
    toParent({ type: 'ready' });
  }
  try {
    const r = await engineReady;
    engineUp = true;
    toParent({ type: 'engine', ms: r.ms });
  } catch (e) {
    toParent({ type: 'failed', error: e.message });
    repaint();
    return;
  } finally {
    offStage();
    offProgress();
  }
  repaint();
  renderStatus();
  try {
    const state = await api.get('/api/state');
    store.settings = state.settings || {};
    store.word = false;
    store.seq = state.seq || 0;
  } catch { /* the editor works without them */ }
  api.get('/api/signatures').then((r) => { store.sigs = r.items; }).catch(() => {});
  api.get('/api/fonts').then((r) => { store.fonts = r.families; }).catch(() => {});
  window.addEventListener('beforeunload', (e) => {
    if (embedded) return;  // ResuTailor asks before it closes the editor
    if (document.body.dataset.busy === '1' || store.order.some((id) => store.docs.get(id)?.info.dirty)) { e.preventDefault(); e.returnValue = ''; }
  });
}

boot();

// expose a tiny surface for automated UI tests
window.folio = { store, V, bus, api, setTool, save, refreshUI, closeMenu, docTools, engine: { ready: engineReady, status: engineStatus } };

// Thin client for Folio's API. In the browser the "server" is Folio's own engine running
// in a worker (engine.js) — the same routes and answers, no network.
import { ready, request, json } from './engine.js';

export class ApiError extends Error {
  constructor(msg, status, data) { super(msg); this.status = status; this.data = data; }
}

async function call(method, path, body, raw = false) {
  await ready.catch(() => { throw new ApiError('Folio’s engine could not start in this browser.', 0); });
  const res = await request(method, path, raw ? { raw: body } : { body });
  const data = json(res);
  if (res.status >= 400 || (data && data.error)) throw new ApiError((data && data.error) || `HTTP ${res.status}`, res.status, data);
  return data;
}

/** A route that answers with a file: { bytes, type, name, meta }. */
async function file(path, body = {}) {
  await ready;
  const res = await request('POST', path, { body });
  if (res.status >= 400 || res.ctype.startsWith('application/json')) {
    const data = json(res);
    if (res.status < 400 && !data.error) return { json: data };
    throw new ApiError(data.error || `HTTP ${res.status}`, res.status, data);
  }
  return { bytes: res.body, type: res.ctype, name: (res.meta && res.meta.name) || 'download', meta: res.meta || {} };
}

/** Files picked in the page, staged where the engine's routes can read them by path. */
async function stage(fileList) {
  await ready;
  const files = await Promise.all([...fileList].map(async (f) => ({ name: f.name, data: await f.arrayBuffer() })));
  const res = await request('POST', '/api/web/stage', { body: {}, files });
  const data = json(res);
  if (res.status >= 400 || data.error) throw new ApiError(data.error || `HTTP ${res.status}`, res.status, data);
  return data.paths;
}

export const api = {
  get: (p) => call('GET', p),
  post: (p, b = {}) => call('POST', p, b),
  upload: (p, bytes) => call('POST', p, bytes, true),
  file,
  stage,
};

export const docUrl = (id, rest = '') => `/api/doc/${id}${rest}`;

// Right-hand panel: what the current tool does, its options, and properties of the
// selected thing. Falls back to a document overview.
import { $, h, icon, toast, swatches, seg, COLORS, HL_COLORS, fmtBytes } from './util.js';
import { api } from './api.js';
import { store, bus, activeDoc, run, saveOpts, setMarkupKind } from './state.js';
import { V } from './viewer.js';
import { armPlacement, updateSelected, deleteSelected, duplicateSelected, setEditorStyle, currentTextStyle, openTextEditor, familyStack } from './tools.js';
import { openSignatureDialog } from './signature.js';
import { docTools } from './dialogs.js';

const root = $('#inspector');

const TOOL_INFO = {
  select: ['select', 'Select', 'Click things you added to move, resize or restyle them. Select text to copy, highlight or redact it. Double-click any line of text to edit it.'],
  edittext: ['edittext', 'Edit text', 'Click any line to change it. Folio re-sets your words in the document’s own font, size and colour. Enter saves the line, Esc cancels, Tab moves to the next line.'],
  addtext: ['addtext', 'Add text', 'Click anywhere on a page and type. Great for filling forms that have no fields. Click outside the box when you’re done.'],
  sign: ['sign', 'Sign', 'Pick a saved signature, then click where it goes. Signatures are kept in this browser only.'],
  image: ['image', 'Image', 'Choose a picture, then click where it goes. Drag the corners to resize.'],
  draw: ['draw', 'Draw', 'Draw freehand on the page. Press Done (or switch tools) to finish the drawing.'],
  shape: ['shape', 'Shapes', 'Drag on the page to draw. Hold Shift for squares, circles and straight angles.'],
  mark: ['mark', 'Marks', 'Click to drop a check mark, cross or dot — handy for paper-style forms.'],
  whiteout: ['whiteout', 'Whiteout', 'Drag a box to cover something. It hides it visually; the content is still underneath. To remove it for real, use Erase.'],
  erase: ['erase', 'Erase', 'Drag a box: text, images and graphics inside it are removed from the file. The page background shows through.'],
  redact: ['redact', 'Redact', 'Drag a box to black out and permanently remove what’s under it. Use “Redact by search” for things like SSNs or emails across the whole file.'],
  highlight: ['highlight', 'Highlight', 'Select text with the mouse to mark it.'],
  note: ['note', 'Comment', 'Click on a page to pin a comment.'],
  place: ['sign', 'Place', 'Click on the page to place it. Esc to cancel.'],
};

let fontsReq = null;
function fonts() {
  if (store.fonts) return Promise.resolve(store.fonts);
  if (!fontsReq) fontsReq = api.get('/api/fonts').then((r) => { store.fonts = r.families; return r.families; }).catch(() => { fontsReq = null; return []; });
  return fontsReq;
}
const FAVORITES = ['Arial', 'Calibri', 'Aptos', 'Times New Roman', 'Cambria', 'Georgia', 'Segoe UI', 'Verdana', 'Garamond', 'Helvetica', 'Courier New', 'Consolas'];

export function initInspector() {
  for (const ev of ['tool', 'selection', 'active', 'editor', 'report', 'sigs']) bus.on(ev, () => render());
  bus.on('docs', () => { if (!store.selection && !currentTextStyle()) renderSoon(); });
  render();
}

let t = null;
function renderSoon() { clearTimeout(t); t = setTimeout(render, 60); }

function section(title, ...kids) { return h('div.insp-section', title ? h('h3', title) : null, ...kids); }
function row(label, ...kids) { return h('div.row', h('label', label), ...kids); }

export function render() {
  const doc = activeDoc();
  if (!doc) { root.replaceChildren(); return; }
  const out = [];
  const tool = store.tool;
  const sel = store.selection;
  const info = TOOL_INFO[tool];
  if (info && tool !== 'select') {
    out.push(h('div.insp-section', h('h2', { style: { display: 'flex', alignItems: 'center', gap: '8px' } }, icon(info[0]), info[1]), h('p', info[2])));
  }
  const edStyle = currentTextStyle();
  if (edStyle) out.push(textStyleSection(edStyle, 'editor'));
  else if (sel && sel.kind === 'object') out.push(...objectSections(sel));
  else if (sel && sel.kind === 'annot') out.push(annotSection(sel));
  else if (tool === 'addtext') out.push(textStyleSection(store.opts.text, 'defaults'));
  else if (tool === 'draw') out.push(drawSection(store.opts.draw, (p) => { Object.assign(store.opts.draw, p); saveOpts(); }));
  else if (tool === 'shape') out.push(shapeSection(store.opts.shape, (p) => { Object.assign(store.opts.shape, p); saveOpts(); }, true));
  else if (tool === 'highlight') out.push(highlightSection());
  else if (tool === 'mark') out.push(markSection());
  else if (tool === 'whiteout') out.push(section('Colour', swatches(['#ffffff', '#f5f5f0', '#000000', '#e9ecef', '#fff8e1'], store.opts.whiteout.color, (c) => { store.opts.whiteout.color = c; saveOpts(); })));
  else if (tool === 'redact') out.push(redactSection(doc));
  else if (tool === 'sign') out.push(signSection());
  else if (tool === 'image') out.push(imageSection());
  else if (tool === 'edittext') out.push(editTextSection(doc));
  if (tool === 'select' && !sel && !edStyle) out.push(...overviewSections(doc));
  root.replaceChildren(...out);
}

// ------------------------------------------------------------------ text style
function fontPicker(value, onPick) {
  const wrap = h('div.font-pick');
  const inp = h('input.input', { value, spellcheck: false, 'aria-label': 'Font' });
  inp.style.fontFamily = familyStack(value);
  let list = null;
  const close = () => { if (list) { list.remove(); list = null; } };
  const open = async () => {
    const fams = await fonts();
    close();
    const q = inp.value.trim().toLowerCase();
    const showAll = q === value.toLowerCase();
    let items = fams.filter((f) => showAll || f.family.toLowerCase().includes(q));
    const fav = FAVORITES.map((n) => fams.find((f) => f.family === n)).filter(Boolean);
    if (showAll) items = [...fav, ...items.filter((f) => !FAVORITES.includes(f.family))];
    list = h('div.font-list', { role: 'listbox' }, items.slice(0, 400).map((f) => h('div', {
      class: f.family === value ? 'on' : '', style: { fontFamily: familyStack(f.family) },
      title: f.family,
      on: { pointerdown: (e) => { e.preventDefault(); inp.value = f.family; inp.style.fontFamily = familyStack(f.family); close(); onPick(f.family); } },
    }, f.family)));
    if (!items.length) list.appendChild(h('div', { style: { color: 'var(--text-3)' } }, 'No matching fonts'));
    wrap.appendChild(list);
  };
  inp.addEventListener('focus', () => { inp.select(); open(); });
  inp.addEventListener('input', open);
  inp.addEventListener('blur', () => setTimeout(() => { close(); if (inp.value !== value) inp.value = value; }, 120));
  inp.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && list && list.firstChild) { e.preventDefault(); list.firstChild.dispatchEvent(new PointerEvent('pointerdown')); }
    if (e.key === 'Escape') { inp.blur(); }
  });
  wrap.appendChild(inp);
  return wrap;
}

function textStyleSection(st, mode) {
  const apply = (patch) => {
    if (mode === 'editor') { setEditorStyle(patch); Object.assign(store.opts.text, patch); saveOpts(); render(); return; }
    if (mode === 'object') {
      const s = store.selection.data;
      const font = { family: patch.family ?? s.font.family, bold: patch.bold ?? s.font.bold, italic: patch.italic ?? s.font.italic };
      const changes = { font };
      for (const k of ['size', 'color', 'align']) if (k in patch) changes[k] = patch[k];
      updateSelected(changes);
      return;
    }
    Object.assign(store.opts.text, patch);
    saveOpts();
    render();
  };
  const size = h('input.input.num', { type: 'number', min: 4, max: 200, step: 0.5, value: st.size });
  size.addEventListener('change', () => { const v = parseFloat(size.value); if (v > 0) apply({ size: v }); });
  return section(mode === 'object' ? 'Text' : 'Text style',
    h('div.row.stack', fontPicker(st.family, (family) => apply({ family }))),
    h('div.row', size, h('span.muted', 'pt'), h('div.spacer'),
      h('div.seg', h('button', { class: st.bold ? 'on' : '', title: 'Bold', style: { fontWeight: 700 }, on: { click: () => apply({ bold: !st.bold }) } }, 'B'),
        h('button', { class: st.italic ? 'on' : '', title: 'Italic', style: { fontStyle: 'italic', fontFamily: 'Georgia, serif' }, on: { click: () => apply({ italic: !st.italic }) } }, 'I'))),
    h('div.row', seg([{ value: 'left', icon: 'alignl', title: 'Align left' }, { value: 'center', icon: 'alignc', title: 'Centre' }, { value: 'right', icon: 'alignr', title: 'Align right' }], st.align || 'left', (align) => apply({ align }))),
    h('div.row.stack', h('label', 'Colour'), swatches(COLORS, st.color, (color) => apply({ color }))),
  );
}

// ------------------------------------------------------------------ selected object
function objectSections(sel) {
  const o = sel.data;
  const out = [];
  const head = { text: 'Text box', image: o.sig ? 'Signature' : 'Image', rect: 'Rectangle', ellipse: 'Ellipse', line: 'Line', arrow: 'Arrow',
    ink: 'Drawing', check: 'Check mark', cross: 'Cross', dot: 'Dot', whiteout: 'Whiteout' }[o.type] || 'Object';
  const [x0, y0, x1, y1] = o.rect;
  out.push(h('div.insp-section', h('h2', head), h('p.hint', `${Math.round(x1 - x0)} × ${Math.round(y1 - y0)} pt · drag to move, handles to resize, arrow keys to nudge`)));
  if (o.type === 'text') {
    out.push(textStyleSection({ family: o.font.family, bold: o.font.bold, italic: o.font.italic, size: o.size, color: o.color, align: o.align }, 'object'));
  } else if (['rect', 'ellipse', 'line', 'arrow'].includes(o.type)) {
    out.push(shapeSection({ kind: o.type, stroke: o.stroke, fill: o.fill, width: o.lw }, (p) => {
      const ch = {};
      if ('stroke' in p) ch.stroke = p.stroke || null;
      if ('fill' in p) ch.fill = p.fill || null;
      if ('width' in p) ch.lw = p.width;
      updateSelected(ch);
    }, false));
  } else if (o.type === 'ink') {
    out.push(drawSection({ color: o.stroke, width: o.lw }, (p) => updateSelected({ ...(p.color ? { stroke: p.color } : {}), ...(p.width ? { lw: p.width } : {}) })));
  } else if (['check', 'cross', 'dot'].includes(o.type)) {
    out.push(section('Colour', swatches(COLORS, o.stroke || '#000000', (c) => updateSelected({ stroke: c }))));
  } else if (o.type === 'whiteout') {
    out.push(section('Colour', swatches(['#ffffff', '#f5f5f0', '#000000', '#e9ecef', '#fff8e1'], o.fill || '#ffffff', (c) => updateSelected({ fill: c }))));
  }
  const pe = V.pes[sel.n];
  out.push(section(null, h('div.row', { style: { flexWrap: 'wrap', marginBottom: 0 } },
    o.type === 'text' ? h('button.btn', { on: { click: () => openTextEditor(pe, { obj: o }) } }, icon('addtext'), 'Edit text') : null,
    h('button.btn', { title: 'Ctrl+D', on: { click: () => duplicateSelected() } }, icon('dup'), 'Duplicate'),
    h('button.btn.danger', { title: 'Delete', on: { click: () => deleteSelected() } }, icon('trash'), 'Delete'))));
  return out;
}

function annotSection(sel) {
  const a = sel.data;
  const names = { text: 'Comment', highlight: 'Highlight', underline: 'Underline', strikeout: 'Strike-out', squiggly: 'Squiggle', freetext: 'Text comment', ink: 'Ink', square: 'Box', circle: 'Circle', line: 'Line', stamp: 'Stamp' };
  const kids = [h('h2', names[a.kind] || 'Annotation')];
  if (a.kind === 'text' || a.kind === 'freetext' || a.content) {
    const ta = h('textarea.input', { rows: 5, placeholder: 'Comment text' });
    ta.value = a.content || '';
    ta.addEventListener('change', async () => {
      try { await run(V.doc, `/page/${sel.n}/annot/${a.xref}`, { content: ta.value }); toast('Comment saved', { type: 'ok', ms: 1200 }); }
      catch (e) { toast(e.message, { type: 'error' }); }
    });
    kids.push(h('div.row.stack', ta));
  }
  if (a.author) kids.push(h('p.hint', `By ${a.author}`));
  kids.push(h('div.row', h('button.btn.danger', { on: { click: () => deleteSelected() } }, icon('trash'), 'Delete')));
  return h('div.insp-section', ...kids);
}

// ------------------------------------------------------------------ tool option sections
function drawSection(o, apply) {
  const w = h('input', { type: 'range', min: 0.5, max: 12, step: 0.5, value: o.width, style: { flex: 1 } });
  const lab = h('span.muted', `${o.width} pt`);
  w.addEventListener('input', () => { lab.textContent = `${w.value} pt`; });
  w.addEventListener('change', () => apply({ width: parseFloat(w.value) }));
  return section('Pen', h('div.row.stack', h('label', 'Colour'), swatches(COLORS, o.color, (c) => apply({ color: c }))), row('Width', w, lab));
}

function shapeSection(o, apply, withKind) {
  const w = h('input', { type: 'range', min: 0.5, max: 12, step: 0.5, value: o.width || 1.5, style: { flex: 1 } });
  const lab = h('span.muted', `${o.width || 1.5} pt`);
  w.addEventListener('input', () => { lab.textContent = `${w.value} pt`; });
  w.addEventListener('change', () => apply({ width: parseFloat(w.value) }));
  const noneSw = (val, key) => h('button.sw', { class: !val ? 'on' : '', title: 'None', style: { background: 'linear-gradient(135deg, #fff 45%, #e5484d 45%, #e5484d 55%, #fff 55%)' }, on: { click: () => apply({ [key]: '' }) } });
  const kinds = [{ value: 'rect', icon: 'rect', title: 'Rectangle' }, { value: 'ellipse', icon: 'ellipse', title: 'Ellipse' }, { value: 'line', icon: 'line', title: 'Line' }, { value: 'arrow', icon: 'arrow', title: 'Arrow' }];
  const lineLike = o.kind === 'line' || o.kind === 'arrow';
  const strokeRow = h('div.swatches', swatches(COLORS, o.stroke || '', (c) => apply({ stroke: c })), lineLike ? null : noneSw(o.stroke, 'stroke'));
  const fillRow = lineLike ? null : h('div.swatches', swatches(COLORS, o.fill || '', (c) => apply({ fill: c })), noneSw(o.fill, 'fill'));
  return section('Shape',
    withKind ? h('div.row', seg(kinds, o.kind, (kind) => { apply({ kind }); render(); })) : null,
    h('div.row.stack', h('label', 'Outline'), strokeRow),
    fillRow ? h('div.row.stack', h('label', 'Fill'), fillRow) : null,
    row('Width', w, lab));
}

function highlightSection() {
  const o = store.opts.highlight;
  const set = (p) => { Object.assign(o, p); saveOpts(); render(); };
  return section('Style',
    h('div.row', seg([{ value: 'highlight', label: 'Highlight' }, { value: 'underline', icon: 'underline', title: 'Underline' }, { value: 'strike', icon: 'strike', title: 'Strike out' }], o.kind, (kind) => { setMarkupKind(kind); render(); })),
    h('div.row.stack', h('label', 'Colour'), swatches(o.kind === 'highlight' ? HL_COLORS : COLORS, o.color, (color) => set({ color }))));
}

function markSection() {
  const o = store.opts.mark;
  const set = (p) => { Object.assign(o, p); saveOpts(); render(); };
  const size = h('input', { type: 'range', min: 6, max: 40, step: 1, value: o.size, style: { flex: 1 } });
  const lab = h('span.muted', `${o.size} pt`);
  size.addEventListener('input', () => { lab.textContent = `${size.value} pt`; });
  size.addEventListener('change', () => set({ size: parseFloat(size.value) }));
  return section('Mark',
    h('div.row', seg([{ value: 'check', icon: 'check', title: 'Check mark' }, { value: 'cross', icon: 'cross', title: 'Cross' }, { value: 'dot', icon: 'dot', title: 'Dot' }], o.kind, (kind) => set({ kind }))),
    row('Size', size, lab),
    h('div.row.stack', h('label', 'Colour'), swatches(COLORS, o.color, (color) => set({ color }))));
}

function redactSection(doc) {
  return section('Options',
    h('div.row.stack', h('label', 'Box colour'), swatches(['#000000', '#3d3f46', '#ffffff'], store.opts.redact.color, (c) => { store.opts.redact.color = c; saveOpts(); }, { custom: false })),
    h('button.btn', { on: { click: () => docTools.redactSearch(doc) } }, icon('find'), 'Redact by search…'),
    h('p.hint', { style: { marginTop: '10px' } }, 'Redaction removes the underlying text and image pixels — it can’t be recovered from the saved file.'));
}

function signSection() {
  const box = h('div.sig-grid');
  const draw = () => {
    box.replaceChildren(
      ...store.sigs.map((s) => h('div.sig-card', { title: s.kind === 'initials' ? 'Initials — click, then click on the page' : 'Click, then click on the page', on: { click: () => {
        const img = new Image();
        img.onload = () => armPlacement({ kind: 'signature', sigKind: s.kind, id: s.id, url: s.url, w: img.naturalWidth, h: img.naturalHeight });
        img.src = s.url;
      } } }, h('img', { src: s.url, alt: s.kind }), h('button.del', { title: 'Delete', on: { click: async (e) => {
        e.stopPropagation();
        const r = await api.post(`/api/signatures/${s.id}/delete`);
        store.sigs = r.items; draw();
      } } }, icon('close', 'sm')))),
      h('div.sig-card.sig-add', { on: { click: () => openSignatureDialog('signature') } }, icon('plus'), 'New signature'),
      h('div.sig-card.sig-add', { on: { click: () => openSignatureDialog('initials') } }, icon('plus'), 'New initials'),
    );
  };
  draw();
  return section('Your signatures', box, h('p.hint', { style: { marginTop: '10px' } }, 'This is a visual signature, like signing on paper. Saved signatures stay in this browser.'));
}

function imageSection() {
  const inp = h('input', { type: 'file', accept: 'image/*', hidden: true });
  inp.addEventListener('change', () => {
    const f = inp.files[0];
    if (!f) return;
    const rd = new FileReader();
    rd.onload = () => {
      const img = new Image();
      img.onload = () => {
        // the engine reads PNG and JPEG; anything else the browser can show (WebP, GIF,
        // AVIF, BMP…) goes in as PNG
        let url = rd.result;
        if (!/^data:image\/(png|jpe?g);/i.test(url)) {
          const c = document.createElement('canvas');
          c.width = img.naturalWidth;
          c.height = img.naturalHeight;
          c.getContext('2d').drawImage(img, 0, 0);
          url = c.toDataURL('image/png');
        }
        armPlacement({ kind: 'image', dataUrl: url, url, w: img.naturalWidth, h: img.naturalHeight });
      };
      img.onerror = () => toast('That file isn’t an image Folio can read.', { type: 'error' });
      img.src = rd.result;
    };
    rd.readAsDataURL(f);
  });
  return section(null, inp, h('button.btn.primary', { on: { click: () => inp.click() } }, icon('upload'), 'Choose image…'),
    h('p.hint', { style: { marginTop: '10px' } }, 'PNG with transparency works best for logos and stamps.'));
}

function editTextSection(doc) {
  const kids = [];
  const tog = h('label', { style: { display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer' } },
    h('input', { type: 'checkbox', checked: document.body.classList.contains('show-lines'), on: { change: (e) => document.body.classList.toggle('show-lines', e.target.checked) } }),
    'Outline all editable text');
  kids.push(tog);
  if (doc.lastReport && doc.lastReport.fonts && doc.lastReport.fonts.length) kids.push(fontReport(doc.lastReport));
  return section('Options', ...kids);
}

function fontReport(rep) {
  return h('div', { style: { marginTop: '12px' } }, h('h3', 'Fonts in your last edit'),
    h('div.font-report', rep.fonts.map((f) => h('div.fr', h('span.badge', { class: f.quality === 'exact' ? 'ok' : 'warn' }, f.quality === 'exact' ? 'exact' : 'similar'),
      h('span', f.used)))));
}

// ------------------------------------------------------------------ document overview
function overviewSections(doc) {
  const out = [];
  const info = doc.info;
  const sizeEl = h('span.muted', info.file_size != null && !info.dirty ? fmtBytes(info.file_size) : '');
  out.push(h('div.insp-section',
    h('h2', { style: { wordBreak: 'break-word' } }, info.name),
    h('p.hint', 'Edited in this browser — the file is never uploaded.'),
    h('div.row', { style: { marginBottom: 0, gap: '12px' } }, h('span', `${info.pages.length} page${info.pages.length === 1 ? '' : 's'}`), sizeEl,
      info.protected ? h('span.badge.ok', { title: 'Saved with a password' }, 'Password') : null,
      h('div.spacer'), info.dirty ? h('span.badge.warn', 'Unsaved') : h('span.badge.ok', 'Saved'))));
  if (info.forms) {
    const tog = h('input', { type: 'checkbox', checked: !document.body.classList.contains('hide-fields'), on: { change: (e) => document.body.classList.toggle('hide-fields', !e.target.checked) } });
    out.push(section('Form',
      h('p', 'This PDF has fillable fields — click a field on the page and type. Tab moves to the next field.'),
      h('label', { style: { display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '10px', cursor: 'pointer' } }, tog, 'Highlight fields'),
      h('button.btn', { title: 'Turn the filled fields into regular page content', on: { click: () => docTools.flatten(doc) } }, icon('layers'), 'Flatten form…')));
  }
  if (doc.lastReport && doc.lastReport.fonts && doc.lastReport.fonts.length) out.push(section(null, fontReport(doc.lastReport)));
  const qa = (ic, label, fn) => h('div.list-item', { on: { click: fn } }, icon(ic, 'sm'), h('span.grow', label));
  out.push(section('Quick actions', h('div.list',
    qa('compress', 'Compress…', () => docTools.compress(doc)),
    qa('merge', 'Merge with other files…', () => docTools.insertFile(doc, doc.pages.length)),
    qa('split', 'Split or extract pages…', () => docTools.split(doc)),
    qa('lock', info.protected ? 'Change or remove password…' : 'Protect with password…', () => docTools.protect(doc)),
    qa('hash', 'Add page numbers…', () => docTools.pageNumbers(doc)),
  )));
  out.push(section(null, h('p.hint', 'Tip: ', h('span.kbd', 'Ctrl'), ' + scroll zooms. ', h('span.kbd', 'Ctrl+F'), ' finds text, ', h('span.kbd', 'Ctrl+H'), ' replaces it across the document.')));
  return out;
}

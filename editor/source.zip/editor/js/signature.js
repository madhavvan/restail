// Create signatures / initials: draw, type or upload. Output is a trimmed transparent PNG.
import { h, icon, toast, modal } from './util.js';
import { api } from './api.js';
import { store, bus } from './state.js';
// typed signatures: handwriting fonts that come with the editor (a browser can't list
// the fonts installed on the computer) — SIL Open Font License
import '@fontsource/dancing-script/400.css';
import '@fontsource/great-vibes/400.css';
import '@fontsource/caveat/400.css';
import '@fontsource/allura/400.css';

const SCRIPT_FONTS = ['Dancing Script', 'Great Vibes', 'Allura', 'Caveat'];
const INKS = ['#111111', '#1b2f8a', '#0b5d3b'];

function trim(canvas, pad = 6) {
  const ctx = canvas.getContext('2d');
  const { width: w, height: hgt } = canvas;
  const d = ctx.getImageData(0, 0, w, hgt).data;
  let x0 = w; let y0 = hgt; let x1 = -1; let y1 = -1;
  for (let y = 0; y < hgt; y++) {
    for (let x = 0; x < w; x++) {
      if (d[(y * w + x) * 4 + 3] > 8) { if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; }
    }
  }
  if (x1 < 0) return null;
  x0 = Math.max(0, x0 - pad); y0 = Math.max(0, y0 - pad); x1 = Math.min(w - 1, x1 + pad); y1 = Math.min(hgt - 1, y1 + pad);
  const out = document.createElement('canvas');
  out.width = x1 - x0 + 1;
  out.height = y1 - y0 + 1;
  out.getContext('2d').drawImage(canvas, x0, y0, out.width, out.height, 0, 0, out.width, out.height);
  return out;
}

function drawPane(state) {
  const canvas = document.createElement('canvas');
  const pad = h('div.sig-pad', canvas, h('div.baseline'), h('div.x', '×'));
  let ctx; let scale = 1;
  let pts = [];
  let drawing = false;
  let lastW = 0;
  const setup = () => {
    // layout size, not getBoundingClientRect: the dialog may still be in its opening
    // scale animation, which would make the bitmap slightly too small for the pad
    scale = 2;
    canvas.width = Math.max(10, pad.clientWidth * scale);
    canvas.height = Math.max(10, pad.clientHeight * scale);
    ctx = canvas.getContext('2d');
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
  };
  requestAnimationFrame(setup);
  const pos = (e) => {
    const r = canvas.getBoundingClientRect();
    return { x: (e.clientX - r.left) * (canvas.width / r.width), y: (e.clientY - r.top) * (canvas.height / r.height), t: e.timeStamp };
  };
  canvas.addEventListener('pointerdown', (e) => {
    if (!ctx) setup();
    canvas.setPointerCapture(e.pointerId);
    drawing = true;
    pts = [pos(e)];
    lastW = 5;
    state.dirty = true;
    ctx.fillStyle = state.ink;
    ctx.beginPath();
    ctx.arc(pts[0].x, pts[0].y, lastW / 2, 0, Math.PI * 2);
    ctx.fill();
  });
  canvas.addEventListener('pointermove', (e) => {
    if (!drawing) return;
    const evs = e.getCoalescedEvents ? e.getCoalescedEvents() : [e];
    for (const ce of evs) {
      const p = pos(ce);
      const a = pts[pts.length - 1];
      const dist = Math.hypot(p.x - a.x, p.y - a.y);
      if (dist < 1.5) continue;
      const v = dist / Math.max(1, p.t - a.t);
      const w = Math.max(2.2, Math.min(7, 7.5 - v * 1.6));
      lastW = lastW * 0.7 + w * 0.3;
      ctx.strokeStyle = state.ink;
      ctx.lineWidth = lastW;
      ctx.beginPath();
      if (pts.length > 1) {
        const b = pts[pts.length - 2];
        ctx.moveTo((a.x + b.x) / 2, (a.y + b.y) / 2);
        ctx.quadraticCurveTo(a.x, a.y, (a.x + p.x) / 2, (a.y + p.y) / 2);
      } else {
        ctx.moveTo(a.x, a.y);
        ctx.lineTo(p.x, p.y);
      }
      ctx.stroke();
      pts.push(p);
    }
  });
  const end = () => { drawing = false; };
  canvas.addEventListener('pointerup', end);
  canvas.addEventListener('pointercancel', end);
  state.clear = () => { if (ctx) ctx.clearRect(0, 0, canvas.width, canvas.height); state.dirty = false; };
  state.exportDraw = () => (state.dirty ? trim(canvas, 8) : null);
  return pad;
}

function typePane(state, kind) {
  const fonts = [...SCRIPT_FONTS];
  for (const f of fonts) document.fonts.load(`48px "${f}"`).catch(() => {});  // ready before the signature is drawn
  state.font = state.font && fonts.includes(state.font) ? state.font : fonts[0];
  const inp = h('input.input', { placeholder: kind === 'initials' ? 'Your initials' : 'Type your name', value: state.typed || '', spellcheck: false });
  const prev = h('div.sig-type-preview');
  const grid = h('div.sig-fonts');
  const draw = () => {
    prev.textContent = inp.value || (kind === 'initials' ? 'AB' : 'Your Name');
    prev.style.fontFamily = `"${state.font}", cursive`;
    prev.style.color = state.ink;
    prev.style.opacity = inp.value ? '1' : '.35';
    grid.replaceChildren(...fonts.map((f) => h('button', { class: f === state.font ? 'on' : '', style: { fontFamily: `"${f}", cursive` }, on: { click: () => { state.font = f; draw(); } } }, inp.value || (kind === 'initials' ? 'AB' : 'Your Name'))));
  };
  inp.addEventListener('input', () => { state.typed = inp.value; draw(); });
  draw();
  state.exportType = () => {
    const text = inp.value.trim();
    if (!text) return null;
    const c = document.createElement('canvas');
    const ctx = c.getContext('2d');
    const size = 140;
    ctx.font = `${size}px "${state.font}", cursive`;
    const w = Math.ceil(ctx.measureText(text).width + size);
    c.width = w;
    c.height = Math.ceil(size * 1.9);
    const ctx2 = c.getContext('2d');
    ctx2.font = `${size}px "${state.font}", cursive`;
    ctx2.fillStyle = state.ink;
    ctx2.textBaseline = 'middle';
    ctx2.fillText(text, size / 2, c.height / 2);
    return trim(c, 10);
  };
  return h('div', inp, h('div', { style: { height: '10px' } }), prev, grid);
}

function uploadPane(state) {
  const inp = h('input', { type: 'file', accept: 'image/*', hidden: true });
  const prev = h('div.sig-type-preview', { style: { fontSize: '13px', color: '#777' } }, 'No image chosen');
  const keepColor = h('input', { type: 'checkbox' });
  let src = null;
  const process = () => {
    if (!src) return;
    const maxW = 1400;
    const s = Math.min(1, maxW / src.width);
    const c = document.createElement('canvas');
    c.width = Math.round(src.width * s);
    c.height = Math.round(src.height * s);
    const ctx = c.getContext('2d');
    ctx.drawImage(src, 0, 0, c.width, c.height);
    const img = ctx.getImageData(0, 0, c.width, c.height);
    const d = img.data;
    // estimate paper brightness from the brightest 10% of pixels
    const lums = [];
    for (let i = 0; i < d.length; i += 4 * 16) lums.push(0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2]);
    lums.sort((a, b) => a - b);
    const paper = lums[Math.floor(lums.length * 0.9)] || 255;
    const hi = paper - 18;
    const lo = Math.max(0, paper - 110);
    const ink = state.ink;
    const ir = parseInt(ink.slice(1, 3), 16); const ig = parseInt(ink.slice(3, 5), 16); const ib = parseInt(ink.slice(5, 7), 16);
    for (let i = 0; i < d.length; i += 4) {
      const lum = 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2];
      const a = lum >= hi ? 0 : lum <= lo ? 255 : Math.round(255 * (hi - lum) / (hi - lo));
      if (!keepColor.checked) { d[i] = ir; d[i + 1] = ig; d[i + 2] = ib; }
      d[i + 3] = Math.min(d[i + 3], a);
    }
    ctx.putImageData(img, 0, 0);
    state.uploaded = trim(c, 8);
    prev.replaceChildren();
    if (state.uploaded) {
      const im = new Image();
      im.src = state.uploaded.toDataURL('image/png');
      im.style.maxWidth = '100%';
      im.style.maxHeight = '110px';
      prev.appendChild(im);
    } else prev.textContent = 'Couldn’t find a signature in that image.';
  };
  inp.addEventListener('change', () => {
    const f = inp.files[0];
    if (!f) return;
    const url = URL.createObjectURL(f);
    const im = new Image();
    im.onload = () => { src = im; process(); };
    im.onerror = () => toast('That file isn’t an image Folio can read.', { type: 'error' });
    im.src = url;
  });
  keepColor.addEventListener('change', process);
  state.reprocess = process;
  state.exportUpload = () => state.uploaded || null;
  return h('div',
    h('button.btn', { on: { click: () => inp.click() } }, icon('upload'), 'Choose a photo or scan…'), inp,
    h('div', { style: { height: '10px' } }), prev,
    h('label', { style: { display: 'flex', alignItems: 'center', gap: '8px', marginTop: '10px', color: 'var(--text-2)' } }, keepColor, 'Keep original ink colour'),
    h('p.hint', { style: { marginTop: '6px' } }, 'Sign on white paper, take a photo, and Folio removes the paper.'));
}

export async function openSignatureDialog(kind = 'signature') {
  if (!store.fonts) { try { store.fonts = (await api.get('/api/fonts')).families; } catch { store.fonts = []; } }
  const state = { mode: 'draw', ink: INKS[0], dirty: false };
  const body = h('div');
  const tabs = h('div.sig-tabs');
  const inkRow = h('div.ink-colors');
  const panes = {};
  const show = (mode) => {
    state.mode = mode;
    tabs.replaceChildren(...[['draw', 'Draw'], ['type', 'Type'], ['upload', 'Upload']].map(([m, l]) => h('button.btn', { class: m === mode ? 'primary' : 'ghost', on: { click: () => show(m) } }, l)));
    if (!panes[mode]) panes[mode] = mode === 'draw' ? drawPane(state) : mode === 'type' ? typePane(state, kind) : uploadPane(state);
    content.replaceChildren(panes[mode]);
    inkRow.replaceChildren(...[h('span.muted', 'Ink'), ...INKS.map((c) => h('button.sw', { class: c === state.ink ? 'on' : '', style: { background: c }, on: { click: () => {
      state.ink = c;
      if (state.mode === 'type') { panes.type = null; show('type'); } else if (state.mode === 'upload' && state.reprocess) { state.reprocess(); show('upload'); } else show(mode);
    } } })), h('div.spacer'), mode === 'draw' ? h('button.btn.ghost', { on: { click: () => state.clear && state.clear() } }, 'Clear') : null].filter(Boolean));
  };
  const content = h('div');
  body.append(tabs, content, inkRow);
  show('draw');
  const res = await modal({
    title: kind === 'initials' ? 'Create initials' : 'Create signature',
    body,
    wide: true,
    buttons: [
      { label: 'Cancel', value: null },
      { label: 'Save', primary: true, run: async () => {
        const c = state.mode === 'draw' ? state.exportDraw() : state.mode === 'type' ? state.exportType() : state.exportUpload();
        if (!c) { toast(state.mode === 'type' ? 'Type something first.' : state.mode === 'draw' ? 'Draw your signature first.' : 'Choose an image first.'); return false; }
        const r = await api.post('/api/signatures', { png: c.toDataURL('image/png'), kind });
        store.sigs = r.items;
        bus.emit('sigs');
        return r.items.find((s) => s.id === r.id);
      } },
    ],
  });
  if (res) bus.emit('sig-created', res);
  return res;
}

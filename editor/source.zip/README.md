# Folio in the browser: complete source

This archive is the complete corresponding source of the PDF editor served at
https://madhavvan.github.io/restail/editor/ and embedded in ResuTailor.ai. It is free software
under the GNU Affero General Public License v3.0 or later (editor/LICENSE), because it is built
on PyMuPDF and MuPDF (Artifex Software, AGPL-3.0).

Build (Node 20 or later):

    npm install
    npx vite build      # dist/: serve it at a site root; the editor is at /editor/

The build downloads the PyMuPDF, fontTools and Pillow wheels of the pinned Pyodide release from
Pyodide's CDN and checks each against the SHA-256 in that release's pyodide-lock.json
(scripts/editor-runtime.mjs). editor/README.md explains how the pieces fit together.

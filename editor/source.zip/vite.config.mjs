// Standalone build of Folio in the browser: the PDF editor ResuTailor.ai embeds.
//   npm install && npx vite build   ->  dist/   (serve it at a site root; the editor is /editor/)
//   npx vite                         ->  http://localhost:5173/editor/
import { defineConfig } from 'vite';
import editorRuntime from './scripts/editor-runtime.mjs';

export default defineConfig({
  base: '/',
  plugins: [editorRuntime()],
  worker: { format: 'es' },
  build: { rollupOptions: { input: { editor: 'editor/index.html' } } },
});

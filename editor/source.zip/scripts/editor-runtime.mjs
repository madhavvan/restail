// Vite plugin: the files the PDF editor's engine needs at run time, served in dev and
// emitted into the build under editor-runtime/.
//
//   pyodide-<version>/   Pyodide (npm package `pyodide`, pinned) + the PyMuPDF, fontTools
//                        and Pillow wheels from the same Pyodide release, downloaded once,
//                        checked against the SHA-256 in that release's lock file, cached in
//                        node_modules/.cache.
//   fonts-<hash>.zip     metric-compatible open fonts as TrueType (the @fontsource WOFF
//                        files, unwrapped): what the editor writes new letters in when a
//                        PDF's embedded font lacks them.
//   folio-<hash>.zip     Folio's Python (editor/py): the engine and its web adapter.
//
// It also emits editor/source.zip: the editor's complete source (AGPL), linked from the editor.
//
// The page imports `virtual:editor-runtime` for these paths and their sizes.
import { createHash } from 'node:crypto';
import { createReadStream, existsSync, mkdirSync, readFileSync, readdirSync, statSync, writeFileSync } from 'node:fs';
import { dirname, join, relative, resolve } from 'node:path';
import { inflateSync } from 'node:zlib';
import { fileURLToPath } from 'node:url';
import JSZip from 'jszip';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const VIRTUAL = 'virtual:editor-runtime';
const RESOLVED = `\0${VIRTUAL}`;
const PREFIX = 'editor-runtime/';
const PACKAGES = ['pymupdf', 'fonttools'];   // loaded at start
const LAZY_PACKAGES = ['pillow'];            // loaded on first image import
const CORE = ['pyodide.mjs', 'pyodide.asm.js', 'pyodide.asm.wasm', 'python_stdlib.zip', 'pyodide-lock.json'];
const FONT_FAMILIES = ['carlito', 'caladea', 'arimo', 'tinos', 'cousine', 'gelasio'];
const FONT_STYLES = ['400-normal', '400-italic', '700-normal', '700-italic'];

const sha256 = (buf) => createHash('sha256').update(buf).digest('hex');
const MIME = {
  '.mjs': 'text/javascript', '.js': 'text/javascript', '.wasm': 'application/wasm', '.json': 'application/json',
  '.zip': 'application/zip', '.whl': 'application/zip',
};

// ------------------------------------------------------------------ WOFF 1.0 → TrueType
/** Unwrap a WOFF 1.0 file into the SFNT (TrueType/OpenType) it carries. */
export function woffToSfnt(woff) {
  const d = new DataView(woff.buffer, woff.byteOffset, woff.byteLength);
  if (d.getUint32(0) !== 0x774f4646) throw new Error('not a WOFF 1.0 file');
  const flavor = d.getUint32(4);
  const numTables = d.getUint16(12);
  const tables = [];
  for (let i = 0; i < numTables; i++) {
    const o = 44 + i * 20;
    const tag = String.fromCharCode(woff[o], woff[o + 1], woff[o + 2], woff[o + 3]);
    const offset = d.getUint32(o + 4);
    const compLength = d.getUint32(o + 8);
    const origLength = d.getUint32(o + 12);
    const raw = woff.subarray(offset, offset + compLength);
    const data = compLength < origLength ? inflateSync(raw) : Buffer.from(raw);
    if (data.length !== origLength) throw new Error(`WOFF table ${tag}: ${data.length} bytes, expected ${origLength}`);
    tables.push({ tag, data });
  }
  tables.sort((a, b) => (a.tag < b.tag ? -1 : a.tag > b.tag ? 1 : 0));
  const pad4 = (n) => (n + 3) & ~3;
  let size = 12 + 16 * numTables;
  for (const t of tables) size += pad4(t.data.length);
  const out = Buffer.alloc(size);
  let es = 0;
  while ((1 << (es + 1)) <= numTables) es++;
  out.writeUInt32BE(flavor, 0);
  out.writeUInt16BE(numTables, 4);
  out.writeUInt16BE(16 << es, 6);
  out.writeUInt16BE(es, 8);
  out.writeUInt16BE(numTables * 16 - (16 << es), 10);
  const checksum = (buf) => {
    let sum = 0;
    for (let i = 0; i < buf.length; i += 4) {
      sum = (sum + ((buf[i] << 24) | ((buf[i + 1] ?? 0) << 16) | ((buf[i + 2] ?? 0) << 8) | (buf[i + 3] ?? 0))) >>> 0;
    }
    return sum;
  };
  let at = 12 + 16 * numTables;
  let headAt = -1;
  tables.forEach((t, i) => {
    const data = Buffer.from(t.data);
    if (t.tag === 'head') { data.writeUInt32BE(0, 8); headAt = at; }  // checkSumAdjustment, recomputed below
    const r = 12 + i * 16;
    out.write(t.tag, r, 'latin1');
    out.writeUInt32BE(checksum(data), r + 4);
    out.writeUInt32BE(at, r + 8);
    out.writeUInt32BE(data.length, r + 12);
    data.copy(out, at);
    at += pad4(data.length);
  });
  if (headAt >= 0) out.writeUInt32BE((0xb1b0afba - checksum(out)) >>> 0, headAt + 8);
  return out;
}

// ------------------------------------------------------------------ assets
function pyodideInfo() {
  const dir = join(ROOT, 'node_modules', 'pyodide');
  const version = JSON.parse(readFileSync(join(dir, 'package.json'), 'utf8')).version;
  const lock = JSON.parse(readFileSync(join(dir, 'pyodide-lock.json'), 'utf8'));
  const wanted = new Set();
  const add = (name) => {
    const p = lock.packages[name];
    if (!p) throw new Error(`Pyodide ${version} has no package "${name}"`);
    if (wanted.has(name)) return;
    wanted.add(name);
    for (const dep of p.depends || []) add(dep);
  };
  [...PACKAGES, ...LAZY_PACKAGES].forEach(add);
  const wheels = [...wanted].map((n) => ({ name: n, file: lock.packages[n].file_name, sha256: lock.packages[n].sha256 }));
  return { dir, version, wheels };
}

async function ensureWheel(cacheDir, version, w, log) {
  const path = join(cacheDir, w.file);
  if (existsSync(path) && sha256(readFileSync(path)) === w.sha256) return path;
  const url = `https://cdn.jsdelivr.net/pyodide/v${version}/full/${w.file}`;
  log(`downloading ${w.file}`);
  let res;
  try { res = await fetch(url); } catch (e) {
    throw new Error(`Couldn't download ${url} (${e.cause?.code || e.message}). On a network that intercepts TLS, set NODE_EXTRA_CA_CERTS.`);
  }
  if (!res.ok) throw new Error(`Couldn't download ${url}: HTTP ${res.status}`);
  const buf = Buffer.from(await res.arrayBuffer());
  const got = sha256(buf);
  if (got !== w.sha256) throw new Error(`${w.file}: SHA-256 ${got} doesn't match Pyodide's lock (${w.sha256})`);
  mkdirSync(cacheDir, { recursive: true });
  writeFileSync(path, buf);
  return path;
}

async function buildFontsZip() {
  const zip = new JSZip();
  for (const fam of FONT_FAMILIES) {
    for (const st of FONT_STYLES) {
      const src = join(ROOT, 'node_modules', '@fontsource', fam, 'files', `${fam}-latin-${st}.woff`);
      zip.file(`${fam}-${st}.ttf`, woffToSfnt(readFileSync(src)), { date: new Date(0) });
    }
  }
  return zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE', compressionOptions: { level: 9 } });
}

function walk(dir) {
  const out = [];
  for (const name of readdirSync(dir).sort()) {
    if (name === '__pycache__') continue;
    const p = join(dir, name);
    if (statSync(p).isDirectory()) out.push(...walk(p));
    else if (name.endsWith('.py')) out.push(p);
  }
  return out;
}

async function buildFolioZip() {
  const base = join(ROOT, 'editor', 'py');
  const zip = new JSZip();
  // fixed dates and no implicit folder entries: the same sources always give the same
  // zip (and file name), so a deploy that didn't change the editor doesn't re-download it
  for (const p of walk(base)) zip.file(relative(base, p).split('\\').join('/'), readFileSync(p), { date: new Date(0), createFolders: false });
  return zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE', compressionOptions: { level: 9 } });
}

// ------------------------------------------------------------------ the editor's source (AGPL)
// The editor is built on PyMuPDF (AGPL-3.0), so everyone who uses it is offered its complete
// source: editor/, this plugin and a standalone build, served as editor/source.zip and linked
// from inside the editor. Nothing else of the site is in it.
export const SOURCE_ZIP = 'editor/source.zip';
const EDITOR_PACKAGES = ['pyodide', 'jszip', 'vite', ...['allura', 'arimo', 'caladea', 'carlito', 'caveat', 'cousine', 'dancing-script', 'gelasio', 'great-vibes', 'tinos'].map((f) => `@fontsource/${f}`)];
const STANDALONE_VITE = `// Standalone build of Folio in the browser: the PDF editor ResuTailor.ai embeds.
//   npm install && npx vite build   ->  dist/   (serve it at a site root; the editor is /editor/)
//   npx vite                         ->  http://localhost:5173/editor/
import { defineConfig } from 'vite';
import editorRuntime from './scripts/editor-runtime.mjs';

export default defineConfig({
  base: '/',
  plugins: [editorRuntime()],
  worker: { format: 'es' },
  build: { rollupOptions: { input: { editor: 'editor/index.html' } } },
});
`;
const SOURCE_README = `# Folio in the browser: complete source

This archive is the complete corresponding source of the PDF editor served at
https://madhavvan.github.io/restail/editor/ and embedded in ResuTailor.ai. It is free software
under the GNU Affero General Public License v3.0 or later (editor/LICENSE), because it is built
on PyMuPDF and MuPDF (Artifex Software, AGPL-3.0).

Build (Node 20 or later):

    npm install
    npx vite build      # dist/: serve it at a site root; the editor is at /editor/

The build downloads the PyMuPDF, fontTools and Pillow wheels of the pinned Pyodide release from
Pyodide's CDN and checks each against the SHA-256 in that release's pyodide-lock.json
(scripts/editor-runtime.mjs). editor/README.md explains how the pieces fit together.
`;

function walkAll(dir) {
  const out = [];
  for (const name of readdirSync(dir).sort()) {
    if (name === '__pycache__' || name.endsWith('.pyc')) continue;
    const p = join(dir, name);
    if (statSync(p).isDirectory()) out.push(...walkAll(p));
    else out.push(p);
  }
  return out;
}

async function buildSourceZip() {
  const pkg = JSON.parse(readFileSync(join(ROOT, 'package.json'), 'utf8'));
  const all = { ...pkg.dependencies, ...pkg.devDependencies };
  const devDependencies = Object.fromEntries(EDITOR_PACKAGES.filter((n) => all[n]).map((n) => [n, all[n]]));
  const zip = new JSZip();
  const add = (name, data) => zip.file(name, data, { date: new Date(0), createFolders: false });
  for (const p of walkAll(join(ROOT, 'editor'))) add(relative(ROOT, p).split('\\').join('/'), readFileSync(p));
  add('scripts/editor-runtime.mjs', readFileSync(fileURLToPath(import.meta.url)));
  add('package.json', `${JSON.stringify({ name: 'folio-web', private: true, type: 'module', license: 'AGPL-3.0-or-later', scripts: { dev: 'vite', build: 'vite build' }, devDependencies }, null, 2)}\n`);
  add('vite.config.mjs', STANDALONE_VITE);
  add('README.md', SOURCE_README);
  return zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE', compressionOptions: { level: 9 } });
}

/** Every runtime file: { path under editor-runtime/ → { file?: disk path, data?: Buffer } }. */
async function collect(log) {
  const info = pyodideInfo();
  const cacheDir = join(ROOT, 'node_modules', '.cache', 'editor-runtime', info.version);
  const pdir = `pyodide-${info.version}/`;
  const files = new Map();
  for (const f of CORE) files.set(pdir + f, { file: join(info.dir, f) });
  for (const w of info.wheels) files.set(pdir + w.file, { file: await ensureWheel(cacheDir, info.version, w, log) });
  const fonts = await buildFontsZip();
  const folio = await buildFolioZip();
  const fontsName = `fonts-${sha256(fonts).slice(0, 10)}.zip`;
  const folioName = `folio-${sha256(folio).slice(0, 10)}.zip`;
  files.set(fontsName, { data: fonts });
  files.set(folioName, { data: folio });
  const sizeOf = (e) => (e.data ? e.data.length : statSync(e.file).size);
  // what the page shows download progress against: the big files of a first visit
  const sizes = {};
  for (const [k, e] of files) {
    const name = k.split('/').pop();
    if (/\.(wasm|whl|zip)$/.test(name) && !LAZY_PACKAGES.some((n) => name.startsWith(`${n}-`))) sizes[name] = sizeOf(e);
  }
  const manifest = { pyodide: PREFIX + pdir, folio: PREFIX + folioName, fonts: PREFIX + fontsName, sizes, version: info.version };
  return { files, manifest };
}

// ------------------------------------------------------------------ pdf.js data
// pdf.js fetches these only when a document needs them: character maps (CJK
// fonts), the standard fonts a PDF may name without embedding, ICC profiles and
// the image decoders (JPEG 2000, JBIG2). Served under pdfjs/; the page imports
// `virtual:pdfjs-assets` for the base URLs.
const PDFJS_VIRTUAL = 'virtual:pdfjs-assets';
const PDFJS_DIRS = ['cmaps', 'standard_fonts', 'wasm', 'iccs'];

export function pdfjsAssets() {
  const src = join(ROOT, 'node_modules', 'pdfjs-dist');
  let isBuild = false;
  let base = '/';
  const files = () => {
    const out = new Map();
    for (const d of PDFJS_DIRS) {
      const dir = join(src, d);
      if (!existsSync(dir)) continue;
      for (const name of readdirSync(dir)) {
        const p = join(dir, name);
        if (statSync(p).isFile()) out.set(`pdfjs/${d}/${name}`, p);
      }
    }
    return out;
  };
  return {
    name: 'pdfjs-assets',
    configResolved(cfg) { isBuild = cfg.command === 'build'; base = cfg.base || '/'; },
    resolveId(id) { return id === PDFJS_VIRTUAL ? `\0${PDFJS_VIRTUAL}` : null; },
    load(id) {
      if (id !== `\0${PDFJS_VIRTUAL}`) return null;
      const version = JSON.parse(readFileSync(join(src, 'package.json'), 'utf8')).version;
      return `export default ${JSON.stringify(Object.fromEntries(PDFJS_DIRS.map((d) => [d, `pdfjs/${d}/`])))}; export const version = ${JSON.stringify(version)};`;
    },
    configureServer(server) {
      const map = files();
      server.middlewares.use((req, res, next) => {
        const url = (req.url || '').split('?')[0];
        if (!url.startsWith(base)) return next();
        const file = map.get(decodeURIComponent(url.slice(base.length)));
        if (!file) return next();
        const ext = file.slice(file.lastIndexOf('.'));
        res.setHeader('Content-Type', MIME[ext] || 'application/octet-stream');
        createReadStream(file).pipe(res);
      });
    },
    generateBundle() {
      if (!isBuild) return;
      for (const [k, p] of files()) this.emitFile({ type: 'asset', fileName: k, source: readFileSync(p) });
    },
  };
}

export default function editorRuntime() {
  let state = null;          // Promise<{ files, manifest }>
  let isBuild = false;
  let base = '/';
  const log = (msg) => console.log(`[editor-runtime] ${msg}`);
  const get = () => (state ??= collect(log));
  return {
    name: 'editor-runtime',
    configResolved(cfg) { isBuild = cfg.command === 'build'; base = cfg.base || '/'; },
    resolveId(id) { return id === VIRTUAL ? RESOLVED : null; },
    async load(id) {
      if (id !== RESOLVED) return null;
      const { manifest } = await get();
      return `export default ${JSON.stringify(manifest)};`;
    },
    configureServer(server) {
      // Folio's Python changes while developing: rebuild the zip and reload the page.
      server.watcher.add(join(ROOT, 'editor', 'py'));
      server.watcher.on('change', (p) => {
        if (!p.endsWith('.py') || !p.startsWith(join(ROOT, 'editor', 'py'))) return;
        state = null;
        const mod = server.moduleGraph.getModuleById(RESOLVED);
        if (mod) server.moduleGraph.invalidateModule(mod);
        server.ws.send({ type: 'full-reload' });
      });
      server.middlewares.use(async (req, res, next) => {
        const url = (req.url || '').split('?')[0];
        if (url === `${base}${SOURCE_ZIP}`) {
          try {
            res.setHeader('Content-Type', 'application/zip');
            res.end(await buildSourceZip());
          } catch (e) {
            res.statusCode = 500;
            res.end(String(e?.message ?? e));
          }
          return;
        }
        const at = url.indexOf(`/${PREFIX}`);
        if (at < 0 || !url.startsWith(base)) return next();
        try {
          const { files } = await get();
          const entry = files.get(decodeURIComponent(url.slice(at + PREFIX.length + 1)));
          if (!entry) return next();
          const ext = url.slice(url.lastIndexOf('.'));
          res.setHeader('Content-Type', MIME[ext] || 'application/octet-stream');
          res.setHeader('Cache-Control', 'no-cache');
          if (entry.data) { res.end(entry.data); return; }
          res.setHeader('Content-Length', String(statSync(entry.file).size));
          createReadStream(entry.file).pipe(res);
        } catch (e) {
          res.statusCode = 500;
          res.end(String(e?.message ?? e));
        }
      });
    },
    async generateBundle() {
      if (!isBuild) return;
      const { files } = await get();
      for (const [k, e] of files) {
        this.emitFile({ type: 'asset', fileName: PREFIX + k, source: e.data ?? readFileSync(e.file) });
      }
      this.emitFile({ type: 'asset', fileName: SOURCE_ZIP, source: await buildSourceZip() });
    },
  };
}
